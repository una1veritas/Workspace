/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2004-5 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
** Establishes a connection with emulation code in the BrandyTerminal
** application.
**
** This file should be added to Brandy when compiling the textonly.c
** and textgraph.c versions for use with BrandyTerminal for Mac OS X.
*/

#include "btermchannel.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdarg.h>
#include "semaphore.h"
#include "sys/mman.h"

static const int num_shared_ints = 12;

static sem_t * querySemaphore = (sem_t*)SEM_FAILED;
static sem_t * resultSemaphore = (sem_t*)SEM_FAILED;
static int sharedMemoryFD = -1;
static volatile int *sharedMemory = MAP_FAILED;
static int screenMemoryFD = -1;

static void openSemaphore()
{
    char name[256];
    int completed = 0;

    do
    {
        sprintf(name, "%s/btermrequest", ttyname(STDOUT_FILENO));
        querySemaphore = sem_open(name, 0);
        if (querySemaphore == (sem_t*)SEM_FAILED) break;

        sprintf(name, "%s/btermresult", ttyname(STDOUT_FILENO));
        resultSemaphore = sem_open(name, 0);
        if (resultSemaphore == (sem_t*)SEM_FAILED) break;

        sprintf(name, "%s/btermshare", ttyname(STDOUT_FILENO));
        sharedMemoryFD = shm_open(name, O_RDWR);
        if (sharedMemoryFD == -1) break;

        sharedMemory = mmap(0, num_shared_ints * sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, sharedMemoryFD, 0);
        if (sharedMemory == MAP_FAILED) break;

        completed = 1;
    }
    while (0);

    if (!completed)
    {
        static const char * nferr = "host program not detected.";
        const char * message = nferr;

        if (errno != ENOENT)
        {
            message = strerror(errno);
        }

        fprintf(stderr, "BrandyTerminal conio support error: %s\n", message);
        fflush(stderr);
        exit(1);
    }
}


void btc_getcursorxy(int *px, int *py)
{
    if (querySemaphore == (sem_t*)SEM_FAILED)
    {
        openSemaphore();
    }

    //Lock query semaphore until host locks result semaphore in response
    sharedMemory[0] = 0;
    sem_wait(querySemaphore);
    while (1)
    {
        if (sem_trywait(resultSemaphore) == 0)
        {
            sem_post(resultSemaphore);
        }
        else if (errno == EAGAIN)
        {
            break;
        }
    }
    if (px) *px = sharedMemory[1];
    if (py) *py = sharedMemory[2];
    sem_post(querySemaphore);
}


void btc_getterminaldimensions(int *width, int *height)
{
    if (querySemaphore == (sem_t*)SEM_FAILED)
    {
        openSemaphore();
    }

    //Lock query semaphore until host locks result semaphore in response
    sharedMemory[0] = 1;
    sem_wait(querySemaphore);
    while (1)
    {
        if (sem_trywait(resultSemaphore) == 0)
        {
            sem_post(resultSemaphore);
        }
        else if (errno == EAGAIN)
        {
            break;
        }
    }
    if (width) *width = sharedMemory[1];
    if (height) *height = sharedMemory[2];
    sem_post(querySemaphore);
}


int btc_setdisplaymode(int width, int height)
{
	int result;
        int widthR, heightR, depthR;

	if (screenMemoryFD != -1)
	{
		close(screenMemoryFD);
		screenMemoryFD = -1;
	}

	if (querySemaphore == (sem_t*)SEM_FAILED)
    {
        openSemaphore();
    }
    //Lock query semaphore until host locks result semaphore in response
    sharedMemory[0] = 2;
    sharedMemory[1] = width;
    sharedMemory[2] = height;
    sharedMemory[3] = 8;
    sem_wait(querySemaphore);
    while (1)
    {
        if (sem_trywait(resultSemaphore) == 0)
        {
            sem_post(resultSemaphore);
        }
        else if (errno == EAGAIN)
        {
            break;
        }
    }
    result = sharedMemory[0];
    widthR = sharedMemory[1];
    heightR = sharedMemory[2];
    depthR = sharedMemory[3];
    sem_post(querySemaphore);

	if (result)
	{
		char name[256];

		sprintf(name, "%s/btermscreen", ttyname(STDOUT_FILENO));
        screenMemoryFD = shm_open(name, O_RDWR);
	}
	else
	{
                if (widthR != width || heightR != height || depthR != 8)
                {
                    fprintf(stderr, "BrandyTerminal compiled with a different graphics display format (%dx%dx%d instead of %dx%dx%d)\n", widthR, heightR, depthR, width, height, 8);
                    fflush(stderr);
                }
        
		screenMemoryFD = -1;
	}

	return screenMemoryFD;
}


void btc_restoredisplaymode()
{
	if (screenMemoryFD != -1)
	{
		close(screenMemoryFD);
		screenMemoryFD = -1;
	}

	if (querySemaphore == (sem_t*)SEM_FAILED)
    {
        openSemaphore();
    }

    //Lock query semaphore until host locks result semaphore in response
    sharedMemory[0] = 3;
    sem_wait(querySemaphore);
    while (1)
    {
        if (sem_trywait(resultSemaphore) == 0)
        {
            sem_post(resultSemaphore);
        }
        else if (errno == EAGAIN)
        {
            break;
        }
    }
    sem_post(querySemaphore);
}
