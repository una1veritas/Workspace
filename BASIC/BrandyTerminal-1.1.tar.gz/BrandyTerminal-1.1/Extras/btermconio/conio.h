/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
** The textonly.c and textgraph.c versions of Brandy expect the DOS
** conio library.
**
** This file should be added to Brandy when compiling either of these
** versions for use with BrandyTerminal for Mac OS X.
*/

enum
{
    BLACK = 0,
    LIGHTRED,
    LIGHTGREEN,
    YELLOW,
    LIGHTBLUE,
    LIGHTMAGENTA,
    LIGHTCYAN,
    WHITE,
    DARKGRAY,
    RED,
    GREEN,
    BROWN,
    BLUE,
    MAGENTA,
    CYAN,
    LIGHTGRAY,

    _NORMALCURSOR = 0,
    _SOLIDCURSOR
};

struct text_info
{
    int screenwidth;
    int screenheight;
};

int wherex();
int wherey();
void putch(char c);
void movetext(int left, int top, int right, int bottom, int left2, int top2);
void gotoxy(int x, int y);
void _setcursortype(int type);
void clrscr();
void textcolor(int c);
void textbackground(int c);
void gettextinfo(struct text_info * i);
