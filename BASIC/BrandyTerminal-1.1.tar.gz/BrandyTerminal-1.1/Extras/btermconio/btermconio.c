/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
** The textonly.c and textgraph.c versions of Brandy expect the DOS
** conio library.
**
** This file should be added to Brandy when compiling either of these
** versions for use with BrandyTerminal for Mac OS X.
*/

#include "btermchannel.h"
#include "conio.h"

#include <stdio.h>

int wherex()
{
    int x;

    btc_getcursorxy(&x, NULL);
    return x+1;
}
int wherey()
{
    int y;

    btc_getcursorxy(NULL, &y);
    return y+1;
}
void putch(char c)
{
    putchar(c);
    fflush(stdout);
}
void movetext(int left, int top, int bottom, int right, int left2, int top2)
{
    printf("\x1C%.2X%.2X%.2X%.2X%.2X%.2X", left-1, top-1, bottom-1, right-1, left2-1, top2-1);
    fflush(stdout);
}
void gotoxy(int x, int y)
{
    printf("\033[%d;%dH", y, x);
    fflush(stdout);
}
void _setcursortype(int type)
{
}
void clrscr()
{
    printf("\033[;H\033[2J");
    fflush(stdout);
}
void textcolor(int c)
{
    printf("\x11%.2X", c&15);
    fflush(stdout);
}
void textbackground(int c)
{
    printf("\x11%.2X", 128+(c&15));
    fflush(stdout);
}
void gettextinfo(struct text_info * i)
{
    btc_getterminaldimensions(&i->screenwidth, &i->screenheight);
}
