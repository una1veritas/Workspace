/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2004-5 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
** The textgraph.c version of Brandy expects the JLib library.
**
** This file should be added to Brandy when compiling the textgraph.c
** version for use with BrandyTerminal for Mac OS X.
**
** It is based on JLib.h from version 1.8 of Jon Griffiths' JLib.
*/

//Screen size

#include "btermres.h"

//Built-in types

#define UBYTE	unsigned char
#define BYTE	signed char
#define USHORT	unsigned short int
#define SHORT	short int
#define ULONG	unsigned long
#define LONG	long

//Opaque buffer record type

typedef struct buffer_rec_struct buffer_rec;

//Buffer functions

#define	BR	buffer_rec

	BR *buff_init(int width, int height);
	BR *buff_free(BR * buff);
	void buff_set_clip_region(BR *buff, int x1, int y1, int x2, int y2);
	void buff_reset_clip_region(BR *buff);

	void buff_fill(BR * buff, UBYTE col);
	void buff_fillNC(BR * buff, UBYTE col);

	void buff_blit_buff_to(BR * dbuff, int dbfx, int dbfy,
		BR * sbuff, int sbx1, int sby1, int sbx2, int sby2);

	void buff_blit_buff_toNC(BR * dbuff, int dbfx, int dbfy,
		BR * sbuff, int sbx1, int sby1, int sbx2, int sby2);

	void buff_draw_point(BR * buff, int x, int y, UBYTE c);
	UBYTE buff_get_point(BR * buff, int x, int y);
	void buff_draw_pointNC(BR * buff, int x, int y, UBYTE c);
	UBYTE buff_get_pointNC(BR * buff, int x, int y);

	void buff_draw_rect(BR * buff, int x1, int y1, int x2, int y2, UBYTE c);
	void buff_draw_rectNC(BR * buff, int x1, int y1, int x2, int y2, UBYTE c);

	void buff_draw_line(BR * buff, int x, int y, int x2, int y2, UBYTE c);
	void buff_draw_lineNC(BR * buff, int x, int y, int x2, int y2, UBYTE c);

	void buff_draw_h_lineNC(BR * buff, int x1, int y1, int x2, UBYTE c);

	void buff_draw_ellipse(BR * buff, int x0, int y0, int a, int b, UBYTE c);

	void buff_filled_ellipse(BR * buff, int x0, int y0, int a, int b, UBYTE c);

	void buff_filled_triangle(BR * buff, int x1, int y1, int x2, int y2, int x3, int y3, UBYTE col);

	void buff_scale_buff_toNC(BR * dest, int dx1, int dy1, int dx2, int dy2,
		BR * src, int x1, int y1, int x2, int y2);


//Screen functions

	int screen_set_video_mode(void);
	void screen_restore_video_mode(void);
	void screen_fill(UBYTE col);

	void screen_put_pal(UBYTE col, UBYTE red, UBYTE green, UBYTE blue);
	void screen_block_set_pal(UBYTE * pal);

	void screen_blit_buff_to(int x, int y, BR * src, int x1, int y1, int x2, int y2);
	void screen_blit_buff_toNC(int x, int y, BR * src, int x1, int y1, int x2, int y2);
	void screen_blit_fs_buffer(BR * src);

	void screen_set_app_title(char *title);

//Palette functions

	UBYTE *pal_init(void);
	void pal_free(UBYTE * pal);
