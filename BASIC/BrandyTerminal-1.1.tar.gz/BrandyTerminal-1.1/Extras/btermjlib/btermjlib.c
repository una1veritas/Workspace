/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2004-5 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
** The textgraph.c version of Brandy expect the JLIB graphics library.
**
** This file should be added to Brandy when compiling the textgraph.c
** version for use with BrandyTerminal for Mac OS X.
**
** It simulates a selection of JLib v1.8 function calls, drawing into
** a frame buffer allocated by BrandyTerminal.
*/

#include "jlib.h"
#include "btermjlib.h"
#include "btermchannel.h"

#include <Carbon/Carbon.h>
#include <stdio.h>
#include "sys/mman.h"

/*********************************************************************************
 * JLib simulation variables
 *********************************************************************************/

static btjlScreenBuffer *screenBuffer = MAP_FAILED;
static GWorldPtr screenGWorld = NULL;

static CTabHandle greyColourTable = NULL;
static RgnHandle tempRgn, tempRgn2;


/*********************************************************************************
 * Colour mapping subroutines
 *
 * A greyscale colour table is used to establish a fixed 1-to-1 relationship
 * between frame buffer pixel values and RGBColors passed to QuickDraw functions.
 *
 * An entirely different, modifiable colour table is used to display the image
 * in the frame buffer.
 *********************************************************************************/

static void setupGreyColourTable()
{
	if (!greyColourTable)
	{
		int i;
		greyColourTable = GetCTable(40);

		if (greyColourTable)
		{
			CTabChanged(greyColourTable);
			for (i=0; i<256; ++i)
			{
				(*greyColourTable)->ctTable[i].rgb.red = i<<8;
				(*greyColourTable)->ctTable[i].rgb.green = i<<8;
				(*greyColourTable)->ctTable[i].rgb.blue = i<<8;
			}
		}
	}
}

static inline void initRGBColor(RGBColor *c, unsigned int v)
{
	c->red = v<<8;
	c->green = v<<8;
	c->blue = v<<8;
}

/*********************************************************************************
 * Number sorting subroutines
 *********************************************************************************/

static inline void orderIncreasing2(int *a, int *b)
{
        if (*b < *a)
        {
            int tmp = *a;
            *a = *b;
            *b = tmp;
        }
}


/*********************************************************************************
 * Clipping region subroutines - used in no clip (NC) functions
 *********************************************************************************/

static void PutClipInRgnRemoving(BR * buff, RgnHandle rgn)
{
        GWorldPtr gworld = (GWorldPtr)buff;
        CGrafPtr savePort;
        GDHandle saveHandle;
        Rect r;
    
        GetGWorld(&savePort, &saveHandle);
        SetGWorld((CGrafPtr)gworld, NULL);

        GetClip(rgn);
        GetPortBounds((CGrafPtr)gworld, &r);
        ClipRect(&r);

        SetGWorld(savePort, saveHandle);
}

static void GetClipFromRgn(BR * buff, RgnHandle rgn)
{
        GWorldPtr gworld = (GWorldPtr)buff;
        CGrafPtr savePort;
        GDHandle saveHandle;
    
        GetGWorld(&savePort, &saveHandle);
        SetGWorld((CGrafPtr)gworld, NULL);

        SetClip(rgn);

        SetGWorld(savePort, saveHandle);
}


/*********************************************************************************
 * Point set interface
 *
 * Used to sort a list of points by increasing Y then increasing X order,
 * in preparation for rasterisation.
 *********************************************************************************/

typedef struct
{
	int X;
	int Y;

} sPoint;

static void pointSet_set2FromCoordinates(sPoint *set, int x1, int y1, int x2, int y2);
static void pointSet_set3FromCoordinates(sPoint *set, int x1, int y1, int x2, int y2, int x3, int y3);

static void pointSet_xIncreasingSort2(sPoint *set);
static void pointSet_yDecreasingSort2(sPoint *set);
static void pointSet_yDecreasingSort3(sPoint *set);


/*********************************************************************************
 * Rasteriser interface
 *
 * Used for nothing more complicated than filled triangles.
 *
 * Triangles are convex, so only 2 intersections are possible with a given scanline.
 * Hence 2 paths are traced to find these intersections.
 * 2 segments are sufficient to create a path linking 3 points.
 *
 * Points forming a path must be supplied in order.
 *  For horizontal scanlines the order is bottom-to-top (maximum Y to minimum Y).
 *  For vertical scanlines the order is left-to-right (minimum X to maximum X).
 *
 * These orderings reflect the difference between the bottom-up environment being
 * simulated and the actual drawing environment which is top-down.
 *
 *********************************************************************************/

enum
{
	MAX_PATHS = 2,
	MAX_SEGMENTS_PER_PATH = 2,

	//Flags to control transforming of coordinates into the first octant (X and Y both >= 0, X >= Y) and back again
	OCTANT_TRANS_NO_TRANSFORM = 0,
	OCTANT_TRANS_Y_FIRST = 1,
	OCTANT_TRANS_INVERT_FIRST = 2,
	OCTANT_TRANS_INVERT_SECOND = 4
};

typedef struct
{
	sPoint start;
	sPoint end;

	//Coordinate transformation so interpolation is carried out in the positive XY quadrant
	int transform;
	sPoint span_transformed;

	//Interpolation parameters
	unsigned int gradient;
	unsigned int position;
	unsigned int sum;

} sSegment;

typedef struct
{
	int segmentCount;
	sSegment segments[MAX_SEGMENTS_PER_PATH];

} sPath;

typedef struct
{
	sPath paths[MAX_PATHS];
	int transform;
	sPoint start;
	unsigned int position;
	unsigned int span_transformed;

} sRasteriser;

typedef struct
{
	int line;
	int start;
	int end;

} sScanLineSegment;

static void rasteriser_clear(sRasteriser *rasteriser);
static void rasteriser_set1SegmentPath(sRasteriser *rasteriser, int pathIndex,
				sPoint beginning, sPoint end);
static void rasteriser_set2SegmentPath(sRasteriser *rasteriser, int pathIndex,
				sPoint beginning, sPoint middle, sPoint end);

static void rasteriser_setupInterpolationAlongPositiveX(sRasteriser *rasteriser);
static void rasteriser_setupInterpolationAlongNegativeY(sRasteriser *rasteriser);

static void rasteriser_clipInterpolation(sRasteriser *rasteriser, Rect limit);
static int rasteriser_getSegment0ScanPoint(sRasteriser *rasteriser, sPoint *point);
static int rasteriser_getScanLine(sRasteriser *rasteriser, sScanLineSegment *scanSegment);

/*********************************************************************************
 * Public JLib simulation functions
 *********************************************************************************/


BR *buff_init(int width, int height)
{
	GWorldPtr gworld = NULL;
	Rect r = { 0, 0, height, width };

	setupGreyColourTable();

	if (!tempRgn)
	{
		tempRgn = NewRgn();
	}
        if (!tempRgn2)
	{
		tempRgn2 = NewRgn();
	}

	NewGWorld(&gworld, 8, &r, greyColourTable, NULL, 0);

	return (BR*)gworld;
}

BR *buff_free(BR * buff)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;

		DisposeGWorld(gworld);
	}

	return NULL;
}

void buff_set_clip_region(BR *buff, int x1, int y1, int x2, int y2)
{
        orderIncreasing2( &x1, &x2 );
        orderIncreasing2( &y1, &y2 );
	++x2; ++y2;

	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		Rect r;

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		SetRect(&r, x1, y1, x2, y2);
		ClipRect(&r);

		SetGWorld(savePort, saveHandle);
	}
}

void buff_reset_clip_region(BR *buff)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		Rect r;

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		GetPortBounds((CGrafPtr)gworld, &r);
		ClipRect(&r);

		SetGWorld(savePort, saveHandle);
	}
}

void buff_fill(BR * buff, UBYTE col)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		Rect r;
		RGBColor rgbc;

		initRGBColor(&rgbc, col);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		GetPortBounds((CGrafPtr)gworld, &r);
		RGBForeColor(&rgbc);
		PaintRect(&r);

		SetGWorld(savePort, saveHandle);
	}
}

void buff_fillNC(BR * buff, UBYTE col)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		Rect r;
		RGBColor rgbc;

		initRGBColor(&rgbc, col);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		GetClip(tempRgn);
		GetPortBounds((CGrafPtr)gworld, &r);
		ClipRect(&r);
		RGBForeColor(&rgbc);
		PaintRect(&r);
		SetClip(tempRgn);

		SetGWorld(savePort, saveHandle);
	}
}

void buff_blit_buff_to(BR * dbuff, int dbfx, int dbfy,
	BR * sbuff, int sbx1, int sby1, int sbx2, int sby2)
{
        orderIncreasing2( &sbx1, &sbx2 );
        orderIncreasing2( &sby1, &sby2 );
	++sbx2; ++sby2;

	if (dbuff && sbuff)
	{
		Rect r1 = { sby1, sbx1, sby2, sbx2 };
		Rect r2 = { dbfy, dbfx, dbfy + (sby2-sby1), dbfx + (sbx2-sbx1) };

		RectRgn(tempRgn, &r1);
		SectRegionWithPortClipRegion((CGrafPtr)sbuff, tempRgn);
		
		OffsetRgn(tempRgn, sbx1 - dbfx, sby1 - dbfy);
		SectRegionWithPortClipRegion((CGrafPtr)dbuff, tempRgn);

		CopyBits(GetPortBitMapForCopyBits((CGrafPtr)sbuff),
			GetPortBitMapForCopyBits((CGrafPtr)dbuff),
			&r1, &r2, srcCopy, tempRgn);
	}
}

void buff_blit_buff_toNC(BR * dbuff, int dbfx, int dbfy,
	BR * sbuff, int sbx1, int sby1, int sbx2, int sby2)
{
        orderIncreasing2( &sbx1, &sbx2 );
        orderIncreasing2( &sby1, &sby2 );
	++sbx2; ++sby2;

	if (dbuff && sbuff)
	{
		Rect r1 = { sby1, sbx1, sby2, sbx2 };
		Rect r2 = { dbfy, dbfx, dbfy + (sby2-sby1), dbfx + (sbx2-sbx1) };

                PutClipInRgnRemoving( sbuff, tempRgn );
                PutClipInRgnRemoving( dbuff, tempRgn2 );

                CopyBits(GetPortBitMapForCopyBits((CGrafPtr)sbuff),
			GetPortBitMapForCopyBits((CGrafPtr)dbuff),
			&r1, &r2, srcCopy, NULL);

                GetClipFromRgn( sbuff, tempRgn );
                GetClipFromRgn( dbuff, tempRgn2 );
	}
}

void buff_draw_point(BR * buff, int x, int y, UBYTE c)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		RGBColor rgbc;
		Point pt = { y, x };

		initRGBColor(&rgbc, c);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		GetClip(tempRgn);

		if (PtInRgn(pt, tempRgn))
		{
			SetCPixel(x, y, &rgbc);
		}

		SetGWorld(savePort, saveHandle);
	}
}

UBYTE buff_get_point(BR * buff, int x, int y)
{
	UBYTE result = 0;

	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		RGBColor rgbc;
		Point pt = { y, x };

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		GetClip(tempRgn);

		if (PtInRgn(pt, tempRgn))
		{
			GetCPixel(x, y, &rgbc);
			result = (rgbc.red>>8);
		}

		SetGWorld(savePort, saveHandle);
	}

	return result;
}

void buff_draw_pointNC(BR * buff, int x, int y, UBYTE c)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		RGBColor rgbc;
                Rect r;

		initRGBColor(&rgbc, c);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

                GetClip(tempRgn);
		GetPortBounds((CGrafPtr)gworld, &r);
		ClipRect(&r);
		SetCPixel(x, y, &rgbc);
                SetClip(tempRgn);

		SetGWorld(savePort, saveHandle);
	}
}

UBYTE buff_get_pointNC(BR * buff, int x, int y)
{
	UBYTE result = 0;

	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		RGBColor rgbc;
                Rect r;

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

                GetClip(tempRgn);
		GetPortBounds((CGrafPtr)gworld, &r);
		ClipRect(&r);
		GetCPixel(x, y, &rgbc);
		result = (rgbc.red>>8);
                SetClip(tempRgn);

		SetGWorld(savePort, saveHandle);
	}

	return result;
}

void buff_draw_rect(BR * buff, int x1, int y1, int x2, int y2, UBYTE c)
{
        orderIncreasing2( &x1, &x2 );
        orderIncreasing2( &y1, &y2 );
	++x2; ++y2;

	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		Rect r2 = { y1, x1, y2, x2 };
		RGBColor rgbc;

		initRGBColor(&rgbc, c);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		RGBForeColor(&rgbc);
		PaintRect(&r2);

		SetGWorld(savePort, saveHandle);
	}
}

void buff_draw_rectNC(BR * buff, int x1, int y1, int x2, int y2, UBYTE c)
{
        orderIncreasing2( &x1, &x2 );
        orderIncreasing2( &y1, &y2 );
	++x2; ++y2;

	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		Rect r, r2 = { y1, x1, y2, x2 };
		RGBColor rgbc;

		initRGBColor(&rgbc, c);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		GetClip(tempRgn);
		GetPortBounds((CGrafPtr)gworld, &r);
		ClipRect(&r);
		RGBForeColor(&rgbc);
		PaintRect(&r2);
		SetClip(tempRgn);

		SetGWorld(savePort, saveHandle);
	}
}


static void drawLine(int x, int y, int x2, int y2, Rect limit)
{
	int dx = x2 - x;
	int dy = y2 - y;
	int adx = dx < 0 ? -dx : dx;
	int ady = dy < 0 ? -dy : dy;

	sRasteriser rasteriser;
	sPoint points[2];
	sPoint scanPoint; 

	rasteriser_clear(&rasteriser);

	pointSet_set2FromCoordinates(points, x, y, x2, y2);

	if (adx > ady)
	{
		//Interpolate along X axis
		pointSet_xIncreasingSort2(points);
		rasteriser_set1SegmentPath(&rasteriser, 0, points[0], points[1]);
		rasteriser_setupInterpolationAlongPositiveX(&rasteriser);
	}
	else
	{
		//Interpolate along Y axis
		pointSet_yDecreasingSort2(points);
		rasteriser_set1SegmentPath(&rasteriser, 0, points[0], points[1]);
		rasteriser_setupInterpolationAlongNegativeY(&rasteriser);
	}

	rasteriser_clipInterpolation(&rasteriser, limit);

	while (rasteriser_getSegment0ScanPoint(&rasteriser, &scanPoint))
	{
		MoveTo(scanPoint.X, scanPoint.Y);
		LineTo(scanPoint.X, scanPoint.Y);
	}
}

void buff_draw_line(BR * buff, int x, int y, int x2, int y2, UBYTE c)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		RGBColor rgbc;
		Rect r;

		initRGBColor(&rgbc, c);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);
		GetPortBounds((CGrafPtr)gworld, &r);

		RGBForeColor(&rgbc);
		//MoveTo(x, y);
		//LineTo(x2, y2);
		drawLine(x, y, x2, y2, r);

		SetGWorld(savePort, saveHandle);
	}
}

void buff_draw_lineNC(BR * buff, int x, int y, int x2, int y2, UBYTE c)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		RGBColor rgbc;
		Rect r;

		initRGBColor(&rgbc, c);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		GetClip(tempRgn);
		GetPortBounds((CGrafPtr)gworld, &r);
		ClipRect(&r);

		RGBForeColor(&rgbc);
		//MoveTo(x, y);
		//LineTo(x2, y2);
		drawLine(x, y, x2, y2, r);

		SetClip(tempRgn);

		SetGWorld(savePort, saveHandle);
	}
}

void buff_draw_h_lineNC(BR * buff, int x1, int y1, int x2, UBYTE c)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		RGBColor rgbc;
		Rect r;

		initRGBColor(&rgbc, c);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		GetClip(tempRgn);
		GetPortBounds((CGrafPtr)gworld, &r);
		ClipRect(&r);

		RGBForeColor(&rgbc);
		MoveTo(x1, y1);
		LineTo(x2, y1);

		SetClip(tempRgn);

		SetGWorld(savePort, saveHandle);
	}
}

void buff_draw_ellipse(BR * buff, int x0, int y0, int a, int b, UBYTE c)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		Rect r2 = { y0 - b, x0 - a, y0 + b + 1, x0 + a + 1 };
		RGBColor rgbc;

		initRGBColor(&rgbc, c);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		RGBForeColor(&rgbc);
		FrameOval(&r2);

		SetGWorld(savePort, saveHandle);
	}
}

void buff_filled_ellipse(BR * buff, int x0, int y0, int a, int b, UBYTE c)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		Rect r2 = { y0 - b, x0 - a, y0 + b + 1, x0 + a + 1 };
		RGBColor rgbc;

		initRGBColor(&rgbc, c);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);

		RGBForeColor(&rgbc);
		PaintOval(&r2);

		SetGWorld(savePort, saveHandle);
	}
}


void buff_filled_triangle(BR * buff, int x1, int y1, int x2, int y2, int x3, int y3, UBYTE col)
{
	if (buff)
	{
		GWorldPtr gworld = (GWorldPtr)buff;
		CGrafPtr savePort;
		GDHandle saveHandle;
		RGBColor rgbc;
		Rect r;

		sRasteriser rasteriser;
		sPoint points[3];
		sScanLineSegment scanSegment;

		initRGBColor(&rgbc, col);
		rasteriser_clear(&rasteriser);

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)gworld, NULL);
		GetPortBounds((CGrafPtr)gworld, &r);

		RGBForeColor(&rgbc);

		//Sort the supplied points
		pointSet_set3FromCoordinates(points, x1, y1, x2, y2, x3, y3);
		pointSet_yDecreasingSort3(points);

		//Identify line segments for rasterisation
		if (points[0].Y != points[1].Y)
		{
			//1 point on lowest scanline
			rasteriser_set1SegmentPath(&rasteriser, 0, points[0], points[2]);

			if (points[1].Y != points[2].Y)
			{
				//1 point on highest scanline
				rasteriser_set2SegmentPath(&rasteriser, 1, points[0], points[1], points[2]);
			}
			else
			{
				//2 points on highest scanline
				rasteriser_set1SegmentPath(&rasteriser, 1, points[0], points[1]);
			}
		}
		else
		{
			//2 or more points on lowest scanline
			rasteriser_set1SegmentPath(&rasteriser, 0, points[0], points[2]);
			rasteriser_set1SegmentPath(&rasteriser, 1, points[1], points[2]);
		}

		rasteriser_setupInterpolationAlongNegativeY(&rasteriser);
		rasteriser_clipInterpolation(&rasteriser, r);

		while (rasteriser_getScanLine(&rasteriser, &scanSegment))
		{
			MoveTo(scanSegment.start, scanSegment.line);
			LineTo(scanSegment.end, scanSegment.line);
		}

		SetGWorld(savePort, saveHandle);
	}
}

void buff_scale_buff_toNC(BR * dest, int dx1, int dy1, int dx2, int dy2,
	BR * src, int x1, int y1, int x2, int y2)
{
        orderIncreasing2( &dx1, &dx2 );
        orderIncreasing2( &dy1, &dy2 );
	++dx2; ++dy2;
        orderIncreasing2( &x1, &x2 );
        orderIncreasing2( &y1, &y2 );
	++x2; ++y2;

	if (dest && src)
	{
		Rect r1 = { y1, x1, y2, x2 };
		Rect r2 = { dy1, dx1, dy2, dx2 };

                PutClipInRgnRemoving( src, tempRgn );
                PutClipInRgnRemoving( dest, tempRgn2 );

		CopyBits(GetPortBitMapForCopyBits((CGrafPtr)src),
			GetPortBitMapForCopyBits((CGrafPtr)dest),
			&r1, &r2, srcCopy, NULL);

                GetClipFromRgn( src, tempRgn );
                GetClipFromRgn( dest, tempRgn2 );
	}
}


//Screen functions

int screen_set_video_mode(void)
{
	int screenFD;

	setupGreyColourTable();

	if (screenBuffer != MAP_FAILED)
	{
		if (screenGWorld != NULL)
		{
			DisposeGWorld(screenGWorld);
			screenGWorld = NULL;
		}

		munmap(screenBuffer, sizeof(btjlScreenBuffer));
		screenBuffer = MAP_FAILED;
	}

	screenFD = btc_setdisplaymode(SCREEN_WIDTH, SCREEN_HEIGHT);

	if (screenFD != -1)
	{
		screenBuffer = (btjlScreenBuffer*)mmap(0, sizeof(btjlScreenBuffer), PROT_READ | PROT_WRITE, MAP_SHARED, screenFD, 0);
        if (screenBuffer == MAP_FAILED) return FALSE;
	}

	if (screenBuffer != MAP_FAILED)
	{
		Rect r = { 0, 0, BTJL_SCREEN_HEIGHT, BTJL_SCREEN_WIDTH };
	
		NewGWorldFromPtr(&screenGWorld, 8, &r, greyColourTable, NULL, 0, screenBuffer->pixels, BTJL_SCREEN_WIDTH);
	}

	return (screenBuffer != MAP_FAILED);
}

void screen_restore_video_mode(void)
{
	if (screenBuffer != MAP_FAILED)
	{
		if (screenGWorld != NULL)
		{
			DisposeGWorld(screenGWorld);
			screenGWorld = NULL;
		}

		munmap(screenBuffer, sizeof(btjlScreenBuffer));
		screenBuffer = MAP_FAILED;
	}

	btc_restoredisplaymode();
}

void screen_fill(UBYTE col)
{
	unsigned int fill = col;
	fill |= fill<<8;
	fill |= fill<<16;

	if (screenBuffer != MAP_FAILED)
	{
		unsigned int *p = (unsigned int*)screenBuffer->pixels;
		unsigned int n = sizeof(screenBuffer->pixels)>>2;

		for ( ; n>0; --n)
		{
			*(p++) = fill;
		}

		screenBuffer->state |= BTJL_PIXEL_CHANGE;
	}
}

void screen_put_pal(UBYTE col, UBYTE red, UBYTE green, UBYTE blue)
{
	if (screenBuffer != MAP_FAILED)
	{
		unsigned int index = col * 3;

		screenBuffer->palette[index] = red;
		screenBuffer->palette[++index] = green;
		screenBuffer->palette[++index] = blue;
		screenBuffer->state |= BTJL_PALETTE_CHANGE;
	}
}

void screen_block_set_pal(UBYTE * pal)
{
	if (screenBuffer != MAP_FAILED)
	{
		unsigned int index = 0;

		for (index=0; index<3*256; ++index)
		{
			screenBuffer->palette[index] = pal[index];
		}

		screenBuffer->state |= BTJL_PALETTE_CHANGE;
	}
}

void screen_blit_buff_to(int x, int y, BR * src, int x1, int y1, int x2, int y2)
{
        orderIncreasing2( &x1, &x2 );
        orderIncreasing2( &y1, &y2 );
	++x2; ++y2;

	if (screenGWorld && src)
	{
                CGrafPtr savePort;
		GDHandle saveHandle;

		Rect r1 = { y1, x1, y2, x2 };
		Rect r2 = { y, x, y + y2 - y1, x + x2 - x1 };

                GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)screenGWorld, NULL);

		RectRgn(tempRgn, &r1);
		SectRegionWithPortClipRegion((CGrafPtr)src, tempRgn);
		
		OffsetRgn(tempRgn, x1 - x, y1 - y);

		CopyBits(GetPortBitMapForCopyBits((CGrafPtr)src),
			GetPortBitMapForCopyBits(screenGWorld),
			&r1, &r2, srcCopy, tempRgn);

                SetGWorld(savePort, saveHandle);

		screenBuffer->state |= BTJL_PIXEL_CHANGE;
	}
}

void screen_blit_buff_toNC(int x, int y, BR * src, int x1, int y1, int x2, int y2)
{
        orderIncreasing2( &x1, &x2 );
        orderIncreasing2( &y1, &y2 );
	++x2; ++y2;

	if (screenGWorld && src)
	{
		CGrafPtr savePort;
		GDHandle saveHandle;
	
		Rect r1 = { y1, x1, y2, x2 };
		Rect r2 = { y, x, y + y2 - y1, x + x2 - x1 };

		GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)screenGWorld, NULL);

                PutClipInRgnRemoving( src, tempRgn );

		CopyBits(GetPortBitMapForCopyBits((CGrafPtr)src),
			GetPortBitMapForCopyBits(screenGWorld),
			&r1, &r2, srcCopy, NULL);

                GetClipFromRgn( src, tempRgn );

		SetGWorld(savePort, saveHandle);

		screenBuffer->state |= BTJL_PIXEL_CHANGE;
	}
}

void screen_blit_fs_buffer(BR * src)
{
	if (screenGWorld && src)
	{
                CGrafPtr savePort;
		GDHandle saveHandle;

		Rect r = { 0, 0, BTJL_SCREEN_HEIGHT, BTJL_SCREEN_WIDTH };

                GetGWorld(&savePort, &saveHandle);
		SetGWorld((CGrafPtr)screenGWorld, NULL);

		CopyBits(GetPortBitMapForCopyBits((CGrafPtr)src),
			GetPortBitMapForCopyBits(screenGWorld),
			&r, &r, srcCopy, NULL);

                SetGWorld(savePort, saveHandle);

		screenBuffer->state |= BTJL_PIXEL_CHANGE;
	}
}

void screen_set_app_title(char *title) {}

//Palette functions

UBYTE *pal_init(void)
{
	UBYTE *block = malloc(3*256);

	if (block)
	{
		unsigned int i;

		for (i=0; i<3*256; ++i)
		{
			block[i] = 0;
		}
	}
	return block;
}

void pal_free(UBYTE * pal)
{
	if (pal)
	{
		free(pal);
	}
}



/*********************************************************************************
 * PointSet implementation
 *
 * See notes attached to 'PointSet interface'
 *********************************************************************************/

void pointSet_set2FromCoordinates(sPoint *set, int x1, int y1, int x2, int y2)
{
	set[0].X = x1;
	set[0].Y = y1;
	set[1].X = x2;
	set[1].Y = y2;
}

void pointSet_set3FromCoordinates(sPoint *set, int x1, int y1, int x2, int y2, int x3, int y3)
{
	set[0].X = x1;
	set[0].Y = y1;
	set[1].X = x2;
	set[1].Y = y2;
	set[2].X = x3;
	set[2].Y = y3;
}


static void pointSet_xIncreasingSort2(sPoint *set)
{
	sPoint tmp;

	if (set[0].X > set[1].X)
	{
		tmp = set[0];
		set[0] = set[1];
		set[1] = tmp;
	}
}


static void pointSet_yDecreasingSort2(sPoint *set)
{
	sPoint tmp;

	if (set[0].Y < set[1].Y)
	{
		tmp = set[0];
		set[0] = set[1];
		set[1] = tmp;
	}
}

static void pointSet_yDecreasingSort3(sPoint *set)
{
	sPoint tmp;

	//Sort last 2 points into order
	pointSet_yDecreasingSort2(set + 1);

	//Sort first point with last 2 points
	if (set[0].Y < set[2].Y)
	{
		tmp = set[0];
		set[0] = set[1];
		set[1] = set[2];
		set[2] = tmp;
	}
	else if (set[0].Y < set[1].Y)
	{
		tmp = set[0];
		set[0] = set[1];
		set[1] = tmp;
	}
}


/*********************************************************************************
 * Rasteriser implementation
 *
 * See notes attached to 'Rasteriser interface' 
 *********************************************************************************/

void rasteriser_clear(sRasteriser *rasteriser)
{
	int i;

	for (i=0; i<MAX_PATHS; ++i)
	{
		rasteriser->paths[i].segmentCount = 0;
	}
}


static void rasteriser_set1SegmentPath(sRasteriser *rasteriser, int pathIndex,
				sPoint beginning, sPoint end)
{
	if (pathIndex >= 0 && pathIndex < MAX_PATHS)
	{
		sPath *path = rasteriser->paths + pathIndex;

		path->segments[0].start = beginning;
		path->segments[0].end = end;
		path->segmentCount = 1;
	}
}

static void rasteriser_set2SegmentPath(sRasteriser *rasteriser, int pathIndex,
				sPoint beginning, sPoint middle, sPoint end)
{
	if (pathIndex >= 0 && pathIndex < MAX_PATHS)
	{
		sPath *path = rasteriser->paths + pathIndex;

		path->segments[0].start = beginning;
		path->segments[0].end = middle;
		path->segments[1].start = middle;
		path->segments[1].end = end;
		path->segmentCount = 2;
	}
}


static sPoint rasteriser_transformCoordinates(sPoint c, int transform)
{
	if ((transform & OCTANT_TRANS_Y_FIRST) != 0)
	{
		int tmp = c.X;
		c.X = c.Y;
		c.Y = tmp;
	}
	if ((transform & OCTANT_TRANS_INVERT_FIRST) != 0)
	{
		c.X = -c.X;
	}
	if ((transform & OCTANT_TRANS_INVERT_SECOND) != 0)
	{
		c.Y = -c.Y;
	}
	return c;
}


static sPoint rasteriser_untransformCoordinates(sPoint c, int transform)
{
	if ((transform & OCTANT_TRANS_INVERT_SECOND) != 0)
	{
		c.Y = -c.Y;
	}
	if ((transform & OCTANT_TRANS_INVERT_FIRST) != 0)
	{
		c.X = -c.X;
	}
	if ((transform & OCTANT_TRANS_Y_FIRST) != 0)
	{
		int tmp = c.X;
		c.X = c.Y;
		c.Y = tmp;
	}
	return c;
}


static void rasteriser_initSegmentInterpolation(sSegment *segment, int transform)
{
	sPoint p;
	const unsigned int balanceFrac = 0x7FFF;
	unsigned int span_tX, span_tY;

	segment->transform = transform;

	p.X = segment->end.X - segment->start.X;
	p.Y = segment->end.Y - segment->start.Y;

	p = rasteriser_transformCoordinates(p, transform);
	segment->span_transformed = p;
	span_tX = (unsigned int)p.X;
	span_tY = (unsigned int)p.Y;

	if (span_tX > 0)
	{
		segment->gradient = (span_tY<<16)/span_tX;
	}
	else
	{
		//Avoiding divide-by-zero. Gradient value doesn't matter in this case.
		segment->gradient = 0;
	}
	segment->position = 0;
	segment->sum = balanceFrac;
}


static void rasteriser_setupInterpolationWithTransform(sRasteriser *rasteriser, int baseTransform)
{
	sPath *path;
	int i, j;

	//Set up interpolation for all line segments
	for (j=0, path = rasteriser->paths; j<MAX_PATHS; ++j, ++path)
	{
		sSegment *segment;

		for (i=0, segment = path->segments; i<path->segmentCount; ++i, ++segment)
		{
			int decreases, transform;

			//Check whether the base transform's dependent variable increases or decreases in this segment
			if ((baseTransform & OCTANT_TRANS_Y_FIRST) != 0)
			{
				decreases = segment->end.X < segment->start.X;
			}
			else
			{
				decreases = segment->end.Y < segment->start.Y;
			}

			if (decreases)
			{
				transform = baseTransform | OCTANT_TRANS_INVERT_SECOND;
			}
			else
			{
				transform = baseTransform & ~OCTANT_TRANS_INVERT_SECOND;
			}

			//Set up interpolation for this segment
			rasteriser_initSegmentInterpolation(segment, transform);
		}
	}

	//Read rasterisation range from 1st path
	rasteriser->transform = baseTransform;
	rasteriser->start.X = 0;
	rasteriser->start.Y = 0;
	rasteriser->position = 0;
	rasteriser->span_transformed = 0;

	path = rasteriser->paths;

	if (path->segmentCount > 0)
	{
		sSegment *segment = path->segments;

		rasteriser->start = segment->start;

		for (i=0; i<path->segmentCount; ++i, ++segment)
		{
			rasteriser->span_transformed += segment->span_transformed.X;
		}
	}
}


static void rasteriser_setupInterpolationAlongPositiveX(sRasteriser *rasteriser)
{
	rasteriser_setupInterpolationWithTransform(rasteriser, OCTANT_TRANS_NO_TRANSFORM);
}


static void rasteriser_setupInterpolationAlongNegativeY(sRasteriser *rasteriser)
{
	rasteriser_setupInterpolationWithTransform(rasteriser, OCTANT_TRANS_Y_FIRST | OCTANT_TRANS_INVERT_FIRST);
}


static void rasteriser_skip(sRasteriser *rasteriser, int nlines)
{
	sPath *path;
	int i, j;

	//Skip specified number of lines along all paths
	for (j=0, path = rasteriser->paths; j<MAX_PATHS; ++j, ++path)
	{
		sSegment *segment;
		int n = nlines;

		for (i=0, segment = path->segments; i<path->segmentCount; ++i, ++segment)
		{
			if (segment->position + n <= segment->span_transformed.X)
			{
				segment->sum += n * segment->gradient;
				segment->position += n;
				break;
			}
			else
			{
				int d = segment->span_transformed.X - segment->position;
			
				if (d >= 0)
				{
					segment->sum += d * segment->gradient;
					segment->position = segment->span_transformed.X + 1;
					n -= d;
				}
			}
		}
	}

	rasteriser->position += nlines;
}


static void rasteriser_clipInterpolation(sRasteriser *rasteriser, Rect limit)
{
	sPoint limit0, limit1, start_transformed;
	int transform = rasteriser->transform;
	int tmp;
	int difference;

	limit0.X = limit.left;
	limit0.Y = limit.top;
	limit1.X = limit.right-1;
	limit1.Y = limit.bottom-1;

	limit0 = rasteriser_transformCoordinates(limit0, transform);
	limit1 = rasteriser_transformCoordinates(limit1, transform);
	start_transformed = rasteriser_transformCoordinates(rasteriser->start, transform);

	if (limit0.X > limit1.X)
	{
		tmp = limit0.X;
		limit0.X = limit1.X;
		limit1.X = tmp;
	}
	if (limit0.Y > limit1.Y)
	{
		tmp = limit0.Y;
		limit0.Y = limit1.Y;
		limit1.Y = tmp;
	}

	if ((difference = start_transformed.X + rasteriser->span_transformed - limit1.X) > 0)
	{
		//Clip end against limit
		if (rasteriser->span_transformed >= difference)
		{
			rasteriser->span_transformed -= difference;
		}
		else
		{
			//No visible scanlines
			rasteriser->span_transformed = 0;
			rasteriser->position = 1;
		}
	}

	if ((difference = limit0.X - start_transformed.X) > 0)
	{
		//Clip start against limit
		rasteriser_skip(rasteriser, difference);

		start_transformed.X = limit0.X;
	}
}


static int rasteriser_getSegment0ScanPoint(sRasteriser *rasteriser, sPoint *point)
{
	if (rasteriser->position <= rasteriser->span_transformed)
	{
		sPath *path = rasteriser->paths;

		++rasteriser->position;

		if (path->segmentCount > 0)
		{
			sSegment *segment = path->segments;
			sPoint c;

			c.X = segment->position;
			c.Y = (int)(segment->sum>>16);

			c = rasteriser_untransformCoordinates(c, segment->transform);

			point->X = segment->start.X + c.X;
			point->Y = segment->start.Y + c.Y;

			segment->sum += segment->gradient;
			++segment->position;
			return 1;
		}
	}

	return 0;
}


static int rasteriser_getScanLine(sRasteriser *rasteriser, sScanLineSegment *scanSegment)
{
	sScanLineSegment s;
	int started = 0;

	if (rasteriser->position <= rasteriser->span_transformed)
	{
		sPath *path;
		int i, j;

		++rasteriser->position;

		//Read a point from each path and advance by one line
		for (j=0, path = rasteriser->paths; j<MAX_PATHS; ++j, ++path)
		{
			sSegment *segment;

			for (i=0, segment = path->segments; i<path->segmentCount; ++i, ++segment)
			{
				if (segment->position <= segment->span_transformed.X)
				{
					sPoint c;

					c.X = segment->position;
					c.Y = (int)(segment->sum>>16);

					c = rasteriser_untransformCoordinates(c, segment->transform);

					c.X += segment->start.X;
					c.Y += segment->start.Y;

					if ((rasteriser->transform & OCTANT_TRANS_Y_FIRST) != 0)
					{
						int tmp = c.X;
						c.X = c.Y;
						c.Y = tmp;
					}
					
				
					if (started)
					{
						if (c.Y < s.start)
						{
							s.start = c.Y;
						}
						if (c.Y > s.end)
						{
							s.end = c.Y;
						}
					}
					else
					{
						s.line = c.X;
						s.start = c.Y;
						s.end = c.Y;
						started = 1;
					}

					segment->sum += segment->gradient;
					++segment->position;

					if (segment->position <= segment->span_transformed.X)
					{
						break;
					}
				}
			}
		}
	}

	if (started)
	{
		*scanSegment = s;
		return 1;
	}

	return 0;
}
