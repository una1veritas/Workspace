/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2004-5 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
** The textgraph.c version of Brandy expects the JLIB graphics library.
**
** This file should be added to Brandy when compiling the textgraph.c
** version for use with BrandyTerminal for Mac OS X.
**
** It declares the format of a screen buffer in memory shared with
** BrandyTerminal.
** BrandyTerminal periodically checks the state field.
** If a change flag is set, BrandyTerminal displays the buffer contents
** and resets the flag.
**
*/

#include "btermres.h"

enum
{
	BTJL_PIXEL_CHANGE = 1,
	BTJL_PALETTE_CHANGE = 2,

	BTJL_SCREEN_WIDTH = SCREEN_WIDTH,
	BTJL_SCREEN_HEIGHT = SCREEN_HEIGHT
};


typedef struct btjlScreenBufferStruct
{
	unsigned char pixels[BTJL_SCREEN_WIDTH * BTJL_SCREEN_HEIGHT];
	unsigned char palette[3 * 256];
	unsigned int state;

} btjlScreenBuffer;
