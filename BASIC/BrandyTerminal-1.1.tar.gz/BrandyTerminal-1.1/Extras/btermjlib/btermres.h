
#ifndef SCREEN_WIDTH
#define SCREEN_WIDTH	640
#endif

#ifndef SCREEN_HEIGHT
#define SCREEN_HEIGHT   480
#endif
