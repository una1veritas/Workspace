/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002, 2004 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the implementation of the BackChannel class.
**
**	The btermconio addition to Brandy uses the back channel to
**	enquire after the cursor position.
**
**	Requests via the back channel are passed on to the terminal
**	window's OutputInterpreter instance.
*/

#import "BackChannel.h"

#import <unistd.h>
#import <sys/mman.h>
#import <sys/stat.h>
#import <sys/shm.h>
#import "btermjlib.h"

static const int permissions = S_IRUSR | S_IWUSR;
static const int num_shared_ints = 4;

@interface BackChannel (PrivateMethods)
- (id)initForDeviceName:(NSString *)name;
- (void)resetChannel;
- (const char *)requestName;
- (const char *)resultName;
- (const char *)shareName;
- (BOOL)openRequest;
- (BOOL)openResult;
- (BOOL)openShare;
@end

@implementation BackChannel

+ (BackChannel *)channelForDeviceName:(NSString *)name
{
    return [[[self alloc] initForDeviceName:name] autorelease];
}

- (id)initForDeviceName:(NSString *)name
{
    if (self = [super init])
    {
        deviceName = [name copy];
        [self resetChannel];

        if (!([self openRequest] && [self openResult] && [self openShare]))
        {
            NSString *message = [NSString localizedStringWithFormat:NSLocalizedString(@"%s.\nConio support won't be active for this session.", @""), strerror(errno)];

            NSRunAlertPanel(NSLocalizedString(@"Semaphore error",@""), message, NSLocalizedString(@"OK", @""), nil, nil);

            [self close];
            self = nil;
        }
    }
    return self;
}

- (const char *)requestName
{
    return [[deviceName stringByAppendingString:@"/btermrequest"] cString];
}

- (const char *)resultName
{
    return [[deviceName stringByAppendingString:@"/btermresult"] cString];
}

- (const char *)shareName
{
    return [[deviceName stringByAppendingString:@"/btermshare"] cString];
}

- (const char *)screenName
{
    return [[deviceName stringByAppendingString:@"/btermscreen"] cString];
}

- (void)resetChannel
{
    requestSemaphore = resultSemaphore = (sem_t*)SEM_FAILED;
    sharedMemoryFD = -1;
    sharedMemory = MAP_FAILED;
	screenMemoryFD = -1;
	screenMemory = MAP_FAILED;

    sem_unlink([self requestName]);
    sem_unlink([self resultName]);
    shm_unlink([self shareName]);
	shm_unlink([self screenName]);
}

- (BOOL)openRequest
{
    requestSemaphore = sem_open([self requestName], O_CREAT, permissions, 1);
    return requestSemaphore != (sem_t*)SEM_FAILED;
}

- (BOOL)openResult
{
    resultSemaphore = sem_open([self resultName], O_CREAT, permissions, 1);
    return resultSemaphore != (sem_t*)SEM_FAILED;
}

- (BOOL)openShare
{
    sharedMemoryFD = shm_open([self shareName], O_RDWR | O_CREAT, permissions);
    if (sharedMemoryFD == -1) return NO;

    if (ftruncate(sharedMemoryFD, num_shared_ints * sizeof(int)) == -1) return NO;

    sharedMemory = mmap(0, num_shared_ints * sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, sharedMemoryFD, 0);
    return sharedMemory != MAP_FAILED;
}

- (BOOL)openScreen
{
	screenMemoryFD = shm_open([self screenName], O_RDWR | O_CREAT, permissions);
    if (screenMemoryFD == -1) return NO;

    if (ftruncate(screenMemoryFD, sizeof(btjlScreenBuffer)) == -1) return NO;

    screenMemory = (btjlScreenBuffer*)mmap(0, sizeof(btjlScreenBuffer), PROT_READ | PROT_WRITE, MAP_SHARED, screenMemoryFD, 0);
    return screenMemory != MAP_FAILED;
}

- (void)closeScreen
{
	if (screenMemory != MAP_FAILED) munmap(screenMemory, sizeof(btjlScreenBuffer));
	if (screenMemoryFD != -1) close(screenMemoryFD);

	screenMemoryFD = -1;
	screenMemory = MAP_FAILED;

	shm_unlink([self screenName]);
}

- (btjlScreenBuffer*)screen
{
	return screenMemory;
}

- (void)close
{
	if (screenMemory != MAP_FAILED) munmap(screenMemory, sizeof(btjlScreenBuffer));
	if (screenMemoryFD != -1) close(screenMemoryFD);
    if (sharedMemory != MAP_FAILED) munmap(sharedMemory, num_shared_ints * sizeof(int));
    if (sharedMemoryFD != -1) close(sharedMemoryFD);
    if (requestSemaphore != (sem_t*)SEM_FAILED) sem_close(requestSemaphore);
    if (resultSemaphore != (sem_t*)SEM_FAILED) sem_close(resultSemaphore);
    [self resetChannel];
    [self autorelease];
}

- (void)poll:(id)handler document:(MyDocument *)document
{
    if (sem_trywait(requestSemaphore) == 0)
    {
        sem_post(requestSemaphore);
    }
    else if (errno == EAGAIN)
    {
        //Locked query semaphore indicates that a query is being made
        if ([handler respondsToSelector:@selector(backChannelRequest:document:)])
        {
            [handler backChannelRequest:self document:document];
        }
        //Lock result semaphore until client unlocks query semaphore in response
        sem_wait(resultSemaphore);
        sem_wait(requestSemaphore);
        sem_post(resultSemaphore);
        sem_post(requestSemaphore);
    }

	if (screenMemory != MAP_FAILED && screenMemory->state)
	{
		if ([handler respondsToSelector:@selector(screenUpdateRequest:document:)])
		{
			[handler screenUpdateRequest:self document:document];
		}
	}
}

- (int)getInt:(int)index
{
    if (index >= 0 && index < num_shared_ints)
    {
        return sharedMemory[index];
    }
    return 0;
}

- (void)setInt:(int)index value:(int)value
{
    if (index >= 0 && index < num_shared_ints)
    {
        sharedMemory[index] = value;
    }
}

@end
