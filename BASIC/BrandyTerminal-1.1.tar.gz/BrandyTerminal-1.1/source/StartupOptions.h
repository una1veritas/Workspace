/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002, 2004-5 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the interface for the StartupOptions class.
**
**	The class records the options used to start a Brandy session.
**	It also provides a dialog box allowing the user to specify
**  these options.
*/

#import <Cocoa/Cocoa.h>
#import <sys/ttycom.h>

@interface StartupOptions : NSObject {
	NSDictionary *defaultTerminalOptions;
}

+ (StartupOptions*)currentOptions;
+ (void)showDialog;

- (void)setWorkingDirectory:(NSString *)string;
- (void)setCmdlineOptions:(NSString *)string;
- (void)setFontFamily:(NSString *)string;

- (NSString *)workingDirectory;
- (NSString *)cmdlineOptions;
- (NSString *)fontFamily;

- (NSString *)defaultFontFamily;

- (void)setRows:(int)n;
- (void)setColumns:(int)n;
- (void)setFontSize:(float)n;

- (int)rows;
- (int)columns;
- (float)fontSize;

- (int)defaultRows;
- (int)defaultColumns;
- (float)defaultFontSize;

@end
