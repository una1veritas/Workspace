/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002, 2004-5 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the implementation of the MyDocument class.
**
**	The MyDocument class groups the objects involved in
**	opening and maintaining a Brandy session.
**
**	In response to the TerminalWindowController, it displays the
**	Startup Options panel.
**
**	When the panel is dismissed, it creates an instance of the
**	Child class to launch and monitor an instance of the Brandy
**	interpreter.
**
**	While the session is open, the MyDocument object periodically
**	polls its TerminalIO and BackChannel objects for output
**	from the child process.
*/

#import "MyDocument.h"

#import <sys/wait.h>
#import <stdlib.h>
#import "TerminalWindowController.h"
#import "StartupOptions.h"
#import "Child.h"
#import "TerminalIO.h"
#import "BackChannel.h"
#import "OutputInterpreter.h"
#import "btermjlib.h"

#import <curses.h>



@interface MyDocument (PrivateMethods)
- (void)openIO;
- (void)closeIO;

- (NSString *)translateCharacter:(unichar)c modifiers:(unsigned int)flags;
@end

@implementation MyDocument

- (void)close
{
    [interpreter release];
    interpreter = nil;

    [child_process kill];
    child_process = nil;

    [self closeIO];
    [super close];
}

- (void)makeWindowControllers
{
    [self addWindowController:[[[TerminalWindowController alloc] init] autorelease]];
}

- (NSData *)dataRepresentationOfType:(NSString *)aType
{
    // Insert code here to write your document from the given data.  You can also choose to override -fileWrapperRepresentationOfType: or -writeToFile:ofType: instead.
    return nil;
}

- (BOOL)loadDataRepresentation:(NSData *)data ofType:(NSString *)aType
{
    // Insert code here to read your document from the given data.  You can also choose to override -loadFileWrapperRepresentation:ofType: or -readFromFile:ofType: instead.
    return YES;
}

- (void)updateChangeCount:(NSDocumentChangeType)changeType
{
    //Saving not supported - so disable change count
}

- (void)interpreterReady:(OutputInterpreter *)theInterpreter
{
	StartupOptions *options = [StartupOptions currentOptions];
	TerminalWindowController *controller = [self terminalWindowController];

	window = [controller window];
    interpreter = theInterpreter;

	//Try starting a child process to run Brandy
	child_process = [[Child childWithOptions:options winsize:[controller winsize] delegate:self] retain];

	//If a child process started, open streams for I/O
	if (child_process)
	{
		[self openIO];
		[window setTitle:[NSString localizedStringWithFormat:NSLocalizedString(@"Brandy (%@)", @""), [child_process ptyname]]];
	}

	//Cancel out the retain, so that the Child object will dealloc when it drops out
	//of the active Child list
	[child_process release];
}

- (int)childSetEnv:(Child *)child
{
	putenv("TERM_PROGRAM=Brandy_Terminal");
    putenv("TERM=xterm-color");
    return 0;
}

- (void)childTerminated:(Child *)child
{
    [io synchronise:interpreter];
    [self closeIO];

    [interpreter outputString:[child exitStatusString]];

    child_process = nil;
    [window setTitle:NSLocalizedString(@"(Closed)", @"")];
}

- (void)openIO
{
    io = [[TerminalIO terminalIOWithFD:[child_process ptyFileDescriptor]] retain];
    backChannel = [[BackChannel channelForDeviceName:[child_process ptyname]] retain];
    updateTimer = [NSTimer scheduledTimerWithTimeInterval:0.03f target:self selector:@selector(update:) userInfo:nil repeats:YES];
}

- (void)closeIO
{
    [io release];
    io = nil;

    [backChannel close];
    backChannel = nil;

    [updateTimer invalidate];
    updateTimer = nil;

    [interpreter resetAttributes];
}

- (void)update:(NSTimer *)timer
{
    [backChannel poll:interpreter document:self];
    [io pollOutput:interpreter];
    [child_process poll];
}

- (FILE *)inputStream
{
    return [io inputStream];
}

- (TerminalIO *)io
{
    return io;
}

- (BOOL)validateMenuItem:(NSMenuItem *)item
{
    if ([item action] == @selector(clearScrollback:))
    {
        return [interpreter scrollbackNotEmpty];
    }
    return [super validateMenuItem:item];
}

- (void)clearScrollback:(int)sender
{
    [interpreter clearScrollback];
}


- (NSString *)translateCharacter:(unichar)c modifiers:(unsigned int)flags
{
    switch (c)
    {
    case 127: //delete/backspace
        return @"\x08";
    case NSUpArrowFunctionKey:
        return @"\x1B[A";
    case NSDownArrowFunctionKey:
        return @"\x1B[B";
    case NSLeftArrowFunctionKey:
        return @"\x1B[D";
    case NSRightArrowFunctionKey:
        return @"\x1B[C";
    case NSF1FunctionKey:
        return flags & NSShiftKeyMask?@"\x1B[23~":@"\x1B[11~";
    case NSF2FunctionKey:
        return flags & NSShiftKeyMask?@"\x1B[24~":@"\x1B[12~";
    case NSF3FunctionKey:
        return flags & NSShiftKeyMask?@"\x1B[25~":@"\x1B[13~";
    case NSF4FunctionKey:
        return flags & NSShiftKeyMask?@"\x1B[26~":@"\x1B[14~";
    case NSF5FunctionKey:
        return flags & NSShiftKeyMask?@"\x1B[28~":@"\x1B[15~";
    case NSF6FunctionKey:
        return flags & NSShiftKeyMask?@"\x1B[29~":@"\x1B[17~";
    case NSF7FunctionKey:
        return flags & NSShiftKeyMask?@"\x1B[31~":@"\x1B[18~";
    case NSF8FunctionKey:
        return flags & NSShiftKeyMask?@"\x1B[32~":@"\x1B[19~";
    case NSF9FunctionKey:
        return flags & NSShiftKeyMask?@"\x1B[33~":@"\x1B[20~";
    case NSF10FunctionKey:
        return flags & NSShiftKeyMask?@"\x1B[34~":@"\x1B[21~";
    case NSF11FunctionKey:
        return @"\x1B[23~";
    case NSF12FunctionKey:
        return @"\x1B[24~";
    case NSInsertFunctionKey:
        return @"\x1B[2~";
    case NSDeleteFunctionKey:
        return @"\x1B[3~";
    case NSHomeFunctionKey:
        return @"\x1B[1~";
    case NSEndFunctionKey:
        return @"\x1B[4~";
    case NSPageUpFunctionKey:
        return @"\x1B[5~";
    case NSPageDownFunctionKey:
        return @"\x1B[6~";
    default:
        return [NSString stringWithCharacters:&c length:1];
    }
}


- (void)keyDown:(NSEvent *)theEvent
{
    FILE *stream = [self inputStream];
    NSString *characters = [theEvent characters];
    unsigned int flags = [theEvent modifierFlags];
    int i, length = [characters length];

    if (stream)
    {
        for (i=0; i<length; i++)
        {
            unichar c = [characters characterAtIndex:i];

            if (c == 27)
            {
                [self interrupt:self];
            }
            else
            {
                NSString *string = [self translateCharacter:c modifiers:flags];
                fputs([string cString], stream);
            }
        }
    }
}

- (void)insertText:(id)aString
{
    FILE *stream = [self inputStream];
    NSString *characters = (NSString *)aString;
    int i, length = [characters length];

    if (stream)
    {
        for (i=0; i<length; i++)
        {
            NSString *string = [self translateCharacter:[characters characterAtIndex:i] modifiers:0];

            fputs([string cString], stream);
        }
    }
}


- (IBAction)interrupt:(id)sender
{
    FILE *stream = [self inputStream];

    if (stream)
    {
        clock_t start = clock();

        fputc(3, stream);
        while (clock()-start < CLOCKS_PER_SEC/5);
        fputc(0, stream);
    }
}


- (void)paste:(id)sender
{
    NSPasteboard *pb = [NSPasteboard generalPasteboard];

    if ([NSStringPboardType isEqualToString:[pb availableTypeFromArray:[NSArray arrayWithObject:NSStringPboardType]]])
    {
        NSString *string = [pb stringForType:NSStringPboardType];

        [self insertText:string];
    }
}


- (void)jlibSimulationRequest:(BackChannel *)channel
{
	switch ([channel getInt:0])
	{
	case 2:
		//setdisplaymode
		{
                    int reqWidth, reqHeight, reqDepth;

                    reqWidth = [channel getInt:1];
                    reqHeight = [channel getInt:2];
                    reqDepth = [channel getInt:3];

                    [channel setInt:0 value:0];

                    if (reqWidth == BTJL_SCREEN_WIDTH && reqHeight == BTJL_SCREEN_HEIGHT
                        && reqDepth == 8)
                    {

			if ([channel openScreen])
			{
				btjlScreenBuffer *sb = [channel screen];
				size_t size = sizeof(*sb);

				memset((char*)sb, 0, size);

				[[self terminalWindowController] switchToGraphicsViewScreen:sb];
                                [channel setInt:0 value:1];
			}
                    }
                    else
                    {
                        [channel setInt:1 value:BTJL_SCREEN_WIDTH];
                        [channel setInt:2 value:BTJL_SCREEN_HEIGHT];
                        [channel setInt:3 value:8];
                    }
		}
		break;

	case 3:
		//restoredisplaymode
		[[self terminalWindowController] switchToTerminalView];
		[channel closeScreen];
		
		break;

	default:
		fprintf(stdout, "Unrecognised jlib simulation request %d\n", [channel getInt:0]);
		fflush(stdout);
		break;
	}
}


- (void)screenUpdateRequest:(BackChannel *)channel
{
	[[self terminalWindowController] updateScreen];
}


- (TerminalWindowController*)terminalWindowController
{
	NSArray *controllers = [self windowControllers];
	int i;

	for (i=0; i<[controllers count]; ++i)
	{
		NSObject *c = [controllers objectAtIndex:i];

		if ([c isMemberOfClass:[TerminalWindowController class]])
		{
			return (TerminalWindowController*)c;
		}
	}

	return NULL;
}

@end
