/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002, 2004-5 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the implementation of the StartupOptions class.
**
**  It also contains private classes for managing an options dialog
**  box and associated preferences.
*/

#import "StartupOptions.h"

#import "OutputInterpreter.h"
#import "AppDelegate.h"

@interface StartupOptionController : NSObject
{
    IBOutlet NSWindow * window;
	IBOutlet NSComboBox * workingDirectory;
    IBOutlet NSTextField * commandLine;
	IBOutlet NSTextField * rowsTextField;
	IBOutlet NSTextField * columnsTextField;
	IBOutlet NSPopUpButton * fontFamilyPopup;
	IBOutlet NSPopUpButton * fontSizePopup;
	IBOutlet NSTextField * boldWarningTextField;
	IBOutlet NSScrollView * sampleTextScrollView;
	NSView * warningSuperview;
	NSArray * fontList;
    StartupOptions * options;
}
- (void)showWindow;
@end

static StartupOptionController *singleStartupOptionController = NULL;
static StartupOptions *singleCurrentStartupOptions = NULL;

@interface StartupOptions (PrivateMethods)
+ (StartupOptions*)currentOptions;
+ (NSArray*)fontFamilyList;

- (id)init;
- (NSDictionary*)terminalOptions;
- (NSMutableDictionary*)mutableCopyOfTerminalOptions;
- (void)setTerminalOptions:(NSDictionary*)terminalOptions;
- (NSArray*)workingDirectoryHistory;
@end

@implementation StartupOptions

+ (StartupOptions*)currentOptions
{
	if (singleCurrentStartupOptions == NULL)
	{
		//Create the single option set, which will take user default values
		singleCurrentStartupOptions = [[StartupOptions alloc] init];
	}

	return singleCurrentStartupOptions;
}

+ (NSArray*)fontFamilyList
{
	NSFontManager *fm = [NSFontManager sharedFontManager];
	NSArray *fontFamilies = [fm availableFontFamilies];
	int i, familyCount = [fontFamilies count];
	NSMutableArray *filteredFamilies = [NSMutableArray arrayWithCapacity:familyCount];

	for (i=0; i<familyCount; ++i)
	{
		NSString *familyName = [fontFamilies objectAtIndex:i];

		if ([OutputInterpreter isSuitableFontFamily:familyName])
		{
			[filteredFamilies addObject:familyName];
		}
	}
	[filteredFamilies sortUsingSelector:@selector(compare:)];

	return filteredFamilies;
}

+ (void)showDialog
{
	if (singleStartupOptionController == NULL)
	{
		singleStartupOptionController = [[StartupOptionController alloc] init];
	}

	[singleStartupOptionController showWindow];
}

- (id)init
{
    if (self = [super init])
    {
		//Register application default option values
		NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
		NSDictionary *appDefaults;
		NSString *directoryPath = [NSString stringWithString:[[NSFileManager defaultManager] currentDirectoryPath]];
		NSArray *directoryList;
		NSFont *font = [NSFont userFixedPitchFontOfSize:-1.0];

		directoryList = [NSArray arrayWithObject:directoryPath];

		defaultTerminalOptions = [NSDictionary dictionaryWithObjectsAndKeys:
			[NSNumber numberWithInt:80], @"Columns",
			[NSNumber numberWithInt:32], @"Rows",
			[font familyName], @"FontFamily",
			[NSNumber numberWithInt:[font pointSize]], @"FontPointSize",
			nil
		];

		appDefaults = [NSDictionary dictionaryWithObjectsAndKeys:
			directoryList, @"WorkingDirectoryHistory",
			@"", @"CommandLineParameters",
			defaultTerminalOptions, @"TerminalOptions",
			nil
		];

		[defaults registerDefaults:appDefaults];
    }
    return self;
}

- (oneway void)dealloc
{
    [defaultTerminalOptions release];
    [super dealloc];
}

- (void)setWorkingDirectory:(NSString *)string
{
    //Place named directory at head of list
	NSArray *existingList = [[NSUserDefaults standardUserDefaults] arrayForKey:@"WorkingDirectoryHistory"];
	NSMutableArray *newList;
	const int lengthLimit = 8;
	int i, count;

	count = [existingList count];

	newList = [NSMutableArray arrayWithCapacity:lengthLimit];
	[newList addObject:string];

	for (i=0; i<count; ++i)
	{
		NSString *s = [existingList objectAtIndex:i];

		if ([s compare:string] != NSOrderedSame)
		{
			[newList addObject:s];

			if ([newList count] == lengthLimit)
			{
				break;
			}
		}
	}

	[[NSUserDefaults standardUserDefaults] setObject:newList forKey:@"WorkingDirectoryHistory"];
}

- (void)setCmdlineOptions:(NSString *)string
{
	[[NSUserDefaults standardUserDefaults] setObject:[string copy] forKey:@"CommandLineParameters"];
}

- (void)setFontFamily:(NSString *)string
{
	NSMutableDictionary *terminalOptions = [self mutableCopyOfTerminalOptions];

	[terminalOptions setObject:[string copy] forKey:@"FontFamily"];

	[self setTerminalOptions:terminalOptions];
}

- (NSString *)workingDirectory
{
    NSArray *list = [[NSUserDefaults standardUserDefaults] arrayForKey:@"WorkingDirectoryHistory"];

	if ([list count] > 0)
	{
		return [list objectAtIndex:0];
	}
	else
	{
		return @"";
	}
}

- (NSArray *)workingDirectoryHistory
{
	return [[NSUserDefaults standardUserDefaults] arrayForKey:@"WorkingDirectoryHistory"];
}

- (NSString *)cmdlineOptions
{
    return [[NSUserDefaults standardUserDefaults] objectForKey:@"CommandLineParameters"];
}

- (NSString *)fontFamily
{
	return [[self terminalOptions] objectForKey:@"FontFamily"];
}

- (NSString *)defaultFontFamily
{
	return [defaultTerminalOptions objectForKey:@"FontFamily"];
}

- (void)setRows:(int)n
{
	NSMutableDictionary *terminalOptions = [self mutableCopyOfTerminalOptions];

	[terminalOptions setObject:[NSNumber numberWithInt:n] forKey:@"Rows"];

	[self setTerminalOptions:terminalOptions];
}

- (void)setColumns:(int)n
{
	NSMutableDictionary *terminalOptions = [self mutableCopyOfTerminalOptions];

	[terminalOptions setObject:[NSNumber numberWithInt:n] forKey:@"Columns"];

	[self setTerminalOptions:terminalOptions];
}

- (void)setFontSize:(float)n
{
	NSMutableDictionary *terminalOptions = [self mutableCopyOfTerminalOptions];

	[terminalOptions setObject:[NSNumber numberWithInt:n] forKey:@"FontPointSize"];

	[self setTerminalOptions:terminalOptions];
}

- (int)rows
{
	NSDictionary *options = [self terminalOptions];

	return [[options objectForKey:@"Rows"] intValue];
}

- (int)columns
{
	NSDictionary *options = [self terminalOptions];

	return [[options objectForKey:@"Columns"] intValue];
}

- (float)fontSize
{
	NSDictionary *options = [self terminalOptions];

	return [[options objectForKey:@"FontPointSize"] floatValue];
}

- (int)defaultRows
{
	return [[defaultTerminalOptions objectForKey:@"Rows"] intValue];
}

- (int)defaultColumns
{
	return [[defaultTerminalOptions objectForKey:@"Columns"] intValue];
}

- (float)defaultFontSize
{
	return [[defaultTerminalOptions objectForKey:@"FontPointSize"] floatValue];
}

- (NSDictionary*)terminalOptions
{
	return [[NSUserDefaults standardUserDefaults] dictionaryForKey:@"TerminalOptions"];
}

- (NSMutableDictionary*)mutableCopyOfTerminalOptions
{
	NSDictionary *d = [[NSUserDefaults standardUserDefaults] dictionaryForKey:@"TerminalOptions"];
	NSMutableDictionary *md = [NSMutableDictionary dictionaryWithCapacity:[d count]];

	[md addEntriesFromDictionary:d];

	return md;
}

- (void)setTerminalOptions:(NSDictionary*)terminalOptions
{
	[[NSUserDefaults standardUserDefaults] setObject: terminalOptions forKey:@"TerminalOptions"];
}

@end

@interface StartupOptionController (PrivateMethods)
- (NSString*)fontSizeString:(float)fontSize;
- (NSString*)selectedFontFamily;
- (float)selectedFontSize;
- (IBAction)browseForWD:(id)sender;
- (IBAction)restoreTerminalDefaults:(id)sender;
- (IBAction)start:(id)sender;
- (IBAction)cancel:(id)sender;
- (IBAction)updateFontSample:(id)sender;
- (BOOL)control:(NSControl *)control isValidObject:(id)object;
- (void)copyOptionsOut;
- (void)copyOptionsBack;
@end

static const float selectableFontSizes[] = {
	8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 36, 48, 72
};

@implementation StartupOptionController

- (id)init
{
    if (self = [super init])
    {
		options = [StartupOptions currentOptions];
		[NSBundle loadNibNamed:@"StartupOptions" owner:self];
    }
    return self;
}

- (void)awakeFromNib
{
	warningSuperview = [[boldWarningTextField retain] superview];
}

- (oneway void)dealloc
{
	[boldWarningTextField release];
	[fontList release];
	[options release];
	[super dealloc];
}

- (void)showWindow
{
	if (![window isVisible])
	{
		NSMutableArray *fontSizeNames;
		int i, fontSizeCount;

		[fontList autorelease];
		fontList = [[StartupOptions fontFamilyList] retain];

		[fontFamilyPopup removeAllItems];
		[fontFamilyPopup addItemsWithTitles:fontList];

		fontSizeCount = sizeof(selectableFontSizes)/sizeof(selectableFontSizes[0]);
		fontSizeNames = [NSMutableArray arrayWithCapacity:fontSizeCount];

		for (i=0; i<fontSizeCount; ++i)
		{
			[fontSizeNames addObject:[self fontSizeString:selectableFontSizes[i]]];
		}

		[fontSizePopup removeAllItems];
		[fontSizePopup addItemsWithTitles:fontSizeNames];

		[self copyOptionsOut];
		[window makeFirstResponder:window];
	}

	[window makeKeyAndOrderFront:self];
}

- (IBAction)browseForWD:(id)sender
{
    NSOpenPanel *openPanel = [NSOpenPanel openPanel];

    [openPanel setCanChooseDirectories:YES];
    [openPanel setCanChooseFiles:NO];
    [openPanel setAllowsMultipleSelection:NO];

    if ([openPanel runModalForDirectory:[workingDirectory stringValue] file:nil types:nil] == NSOKButton)
    {
        [workingDirectory setStringValue:[[openPanel filenames] objectAtIndex:0]];
    }
}

- (IBAction)restoreTerminalDefaults:(id)sender
{
	[rowsTextField abortEditing];
	[columnsTextField abortEditing];

	[rowsTextField setIntValue:[options defaultRows]];
	[columnsTextField setIntValue:[options defaultColumns]];

	[fontFamilyPopup selectItemWithTitle:[options defaultFontFamily]];
	if ([fontFamilyPopup indexOfSelectedItem] < 0)
	{
		[fontFamilyPopup selectItemAtIndex:0];
	}

	[fontSizePopup selectItemWithTitle:[self fontSizeString:[options defaultFontSize]]];
	if ([fontSizePopup indexOfSelectedItem] < 0)
	{
		[fontSizePopup selectItemAtIndex:0];
	}

	[self updateFontSample:self];
}

- (IBAction)start:(id)sender
{
	if ([window makeFirstResponder:window])
	{
		[self copyOptionsBack];
		[window orderOut:self];

		[[[NSApplication sharedApplication] delegate] optionsSpecifiedForNewDocument];
	}
}

- (IBAction)cancel:(id)sender
{
	[rowsTextField abortEditing];
	[columnsTextField abortEditing];

    [window orderOut:self];
}

- (BOOL)control:(NSControl *)control isValidObject:(id)object
{
	if (control == rowsTextField || control == columnsTextField)
	{
		const int lowLimit = 4, highLimit = 160;
		NSScanner *scanner;
		int value;
		
		if (![object isKindOfClass:[NSString class]])
		{
			return NO;
		}

		scanner = [NSScanner scannerWithString:object];

		if (![scanner scanInt:&value] || ![scanner isAtEnd]
			|| value < lowLimit || value > highLimit)
		{
			NSString *rangeString = [NSString stringWithFormat:@"Value must be between %d and %d (inclusive).",
				lowLimit, highLimit];

			NSRunAlertPanel(@"Value out of range", 
                rangeString, NULL, NULL, NULL);
            return NO;

		}
	}

	return YES;
}

- (NSString*)fontSizeString:(float)fontSize
{
	return [NSString localizedStringWithFormat:@"%.0f", fontSize];
}

- (NSString*)selectedFontFamily
{
	int selectedIndex = [fontFamilyPopup indexOfSelectedItem];

	return [fontList objectAtIndex:selectedIndex];
}

- (float)selectedFontSize
{
	int selectedIndex = [fontSizePopup indexOfSelectedItem];

	return selectableFontSizes[selectedIndex];
}

- (IBAction)updateWorkingDirectoryHistory:(id)sender
{
	[workingDirectory removeAllItems];
	[workingDirectory addItemsWithObjectValues:[options workingDirectoryHistory]];
}

- (IBAction)updateFontSample:(id)sender
{
	NSString *familyName = [self selectedFontFamily];
	float fontSize = [self selectedFontSize];

	NSFont *regularFont = [OutputInterpreter regularFontFromFamily:familyName size:fontSize];
	NSFont *boldFont = [OutputInterpreter suitableBoldFontFromFamily:familyName size:fontSize];

	NSTextView *textView = [sampleTextScrollView documentView];
	NSTextStorage *textStorage = [textView textStorage];
	NSArray *words = [textStorage words];
	NSColor *foregroundColor = [textStorage foregroundColor];
	NSMutableAttributedString *astring = [[[NSMutableAttributedString alloc] init] autorelease];

	NSDictionary *spaceAttributes = [NSDictionary dictionaryWithObject:regularFont forKey:NSFontAttributeName];
	NSAttributedString *spaceastring = [[[NSAttributedString alloc] initWithString:@" " attributes:spaceAttributes] autorelease];

	NSRange range;
	int i, count;

	count = [words count];

	for (i=0; i<count; ++i)
	{
		NSString *word = [[words objectAtIndex:i] string];
		NSMutableAttributedString *wordastring = [[[NSMutableAttributedString alloc] initWithString:word] autorelease];

		range = NSMakeRange(0, [wordastring length]);

		if (i == 1)
		{
			if (boldFont == regularFont)
			{
				if ([boldWarningTextField superview] == nil)
				{
					[warningSuperview addSubview:boldWarningTextField];
				}
			}
			else
			{
				if ([boldWarningTextField superview] != nil)
				{
					[boldWarningTextField removeFromSuperview];
				}
			}

			[wordastring addAttribute:NSFontAttributeName value:boldFont range:range];
		}
		else
		{
			[wordastring addAttribute:NSFontAttributeName value:regularFont range:range];

			if (i == 2)
			{
				[wordastring addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInt:1] range:range];
			}
		}

		if (i > 0)
		{
			[astring appendAttributedString:spaceastring];
		}
		[astring appendAttributedString:wordastring];
	}

	range = NSMakeRange(0, [astring length]);

	[astring addAttribute:NSForegroundColorAttributeName value:foregroundColor range:range];
	[textStorage setAttributedString:astring];
}


- (void)copyOptionsOut
{
    [workingDirectory setStringValue:[options workingDirectory]];
	[workingDirectory removeAllItems];
	[workingDirectory addItemsWithObjectValues:[options workingDirectoryHistory]];
    [commandLine setStringValue:[options cmdlineOptions]];

	[rowsTextField setIntValue:[options rows]];
	[columnsTextField setIntValue:[options columns]];

	[fontFamilyPopup selectItemWithTitle:[options fontFamily]];
	if ([fontFamilyPopup indexOfSelectedItem] < 0)
	{
		[fontFamilyPopup selectItemAtIndex:0];
	}

	[fontSizePopup selectItemWithTitle:[self fontSizeString:[options fontSize]]];
	if ([fontSizePopup indexOfSelectedItem] < 0)
	{
		[fontSizePopup selectItemAtIndex:0];
	}

	[self updateFontSample:self];
}

- (void)copyOptionsBack
{
    [options setWorkingDirectory:[workingDirectory stringValue]];
    [options setCmdlineOptions:[commandLine stringValue]];

	[options setRows:[rowsTextField intValue]];
	[options setColumns:[columnsTextField intValue]];
	[options setFontFamily:[self selectedFontFamily]];
	[options setFontSize:[self selectedFontSize]];
}

@end
