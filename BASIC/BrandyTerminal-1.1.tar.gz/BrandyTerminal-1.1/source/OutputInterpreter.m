/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002, 2004 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the interface for the OutputInterpreter class.
**
**	The OutputInterpreter class controls the text that appears in
**	the terminal window.
**
**	It is mostly driven by a child process' stdout, but also displays
**	the exit status message.
**
**	Control sequences for vt100 are prefered, to simplify support for
**	command line tools.
**
**	Other sequences cover changes in text and background colour and
**	soft scrolling for text windows.
**
**	The class also deals with cursor position queries.
**
**	These features of BrandyTerminal are only accessible to a
**	textonly or textgraph build of Brandy that includes the
**	btermconio source files.
*/

#import "OutputInterpreter.h"

#import "BackChannel.h"
#import "MyDocument.h"
#import "TerminalIO.h"
#import "StartupOptions.h"
#import "ColourSet.h"

@interface OutputInterpreter (PrivateMethods)
+ (BOOL)fontContainsMonospacedRomanCharacters:(NSFont *)font;
+ (NSFont*)regularFontFromFamily:(NSString*)familyName;
+ (NSFont*)boldFontFromFamily:(NSString*)familyName;
+ (BOOL)isFontFixedWidth:(NSFont *)font;
- (id)initForView:(NSTextView *)theView options:(StartupOptions *)options;
- (void)initLineStrings;
- (void)updateLineStrings;
- (void)clear;
- (void)newlineAbove;
- (void)newlineBelow;
- (void)scrollTextDown;
- (void)scrollTextUp;
- (void)eraseDisplayR1:(int)r1 C1:(int)c1 R2:(int)r2 C2:(int)c2;
- (void)formFeed;
- (void)moveTextFromLeft:(int)left1 top:(int)top1 right:(int)right1 bottom:(int)bottom1 toLeft:(int)left2 top:(int)top2;
- (NSRange)rangeForScreenStart;
- (NSRange)rangeForScreenEnd;
- (NSRange)rangeForCharacterAtX:(int)x Y:(int)y;
- (void)showCursor;
- (void)hideCursor;
- (void)addToSequence:(unichar)c;
- (void)processES;
- (void)processCS;
- (void)extractParam1:(int*)p1;
- (void)extractParam1:(int*)p1 param2:(int*)p2;
@end

@implementation OutputInterpreter

+ (OutputInterpreter *)interpreterForView:(NSTextView *)theView options:(StartupOptions *)options
{
    return [[[self alloc] initForView:theView options:options] autorelease];
}

+ (BOOL)fontContainsMonospacedRomanCharacters:(NSFont *)font
{
	NSTextStorage *ts = [[[NSTextStorage alloc] init] autorelease];
	NSDictionary *fontDict = [NSDictionary dictionaryWithObject:font forKey:NSFontAttributeName];
	NSAttributedString *testLetter = [[[NSAttributedString alloc] initWithString:@"a" attributes:fontDict] autorelease];
	NSFont *fontOut;

	NSMutableString *cs = [NSMutableString stringWithCapacity:1];
	float baseWidth;
	int i;

	[ts beginEditing];
	[ts setAttributedString:testLetter];
	[ts endEditing];

	fontOut = [ts attribute:NSFontAttributeName atIndex:0 effectiveRange:NULL];

	if (fontOut != font)
	{
		return NO;
	}

	baseWidth = [font widthOfString:@" "];

	for (i=32; i<127; ++i)
	{
		[cs setString:@""];
		[cs appendFormat:@"%c", i];

		if (baseWidth != [font widthOfString:cs])
		{
			return NO;
		}
	}

	return YES;
}

+ (NSFont*)regularFontFromFamily:(NSString*)familyName size:(float)size
{
	NSFontManager *fm = [NSFontManager sharedFontManager];
	NSFontTraitMask traitMask = NSUnboldFontMask | NSUnitalicFontMask | NSFixedPitchFontMask;
	NSFont *font = [fm fontWithFamily:familyName traits:traitMask weight:5.0f size:size];

	if (font != nil && ![self fontContainsMonospacedRomanCharacters:font])
	{
		return nil;
	}

	return font;
}

+ (NSFont*)boldFontFromFamily:(NSString*)familyName size:(float)size
{
	NSFontManager *fm = [NSFontManager sharedFontManager];
	NSFontTraitMask traitMask = NSBoldFontMask | NSUnitalicFontMask | NSFixedPitchFontMask;
	NSFont *font = [fm fontWithFamily:familyName traits:traitMask weight:5.0f size:size];

	if (font != nil && ![self fontContainsMonospacedRomanCharacters:font])
	{
		return nil;
	}

	return font;
}

+ (BOOL)isSuitableFontFamily:(NSString*)familyName
{
	NSFont *regularFont = [self regularFontFromFamily:familyName size:72.0f];

	return regularFont != nil;
}

+ (NSFont*)suitableBoldFontFromFamily:(NSString*)familyName size:(float)size
{
	NSFont *regularFont = [self regularFontFromFamily:familyName size:size];
	NSFont *boldFont = [self boldFontFromFamily:familyName size:size];

	if (boldFont == nil)
	{
		return regularFont;
	}

	if ([boldFont defaultLineHeightForFont] != [regularFont defaultLineHeightForFont])
	{
		return regularFont;
	}

	if ([boldFont widthOfString:@" "] != [regularFont widthOfString:@" "])
	{
		return regularFont;
	}

	return boldFont;
}

- (id)initForView:(NSTextView *)theView options:(StartupOptions *)options
{
    if (self = [super init])
    {
		int w = [options columns];
		int h = [options rows];
		float fontSize = [options fontSize];
		NSString *fontFamily = [options fontFamily];

        NSMutableDictionary *initialAttrs = [NSMutableDictionary dictionaryWithCapacity:4];
        NSMutableDictionary *cursorAttrs = [NSMutableDictionary dictionaryWithCapacity:4];

        view = theView;
        storage = [theView textStorage];
        pagewidth = w;
        pageheight = h;

		b_scroll_screen = TRUE;
		scroll_firstline = 0;
		scroll_lastline = h-1;

		theRegularFont = [[OutputInterpreter regularFontFromFamily:fontFamily size:fontSize] retain];
		theBoldFont = [[OutputInterpreter suitableBoldFontFromFamily:fontFamily size:fontSize] retain];

        [initialAttrs setObject:theRegularFont forKey:NSFontAttributeName];
        [initialAttrs setObject:[NSColor whiteColor] forKey:NSForegroundColorAttributeName];
        [initialAttrs setObject:[NSColor blackColor] forKey:NSBackgroundColorAttributeName];

        defaultAttrs = [[NSDictionary dictionaryWithDictionary:initialAttrs] retain];
        currentAttrs = [[NSMutableDictionary dictionaryWithCapacity:4] retain];
        [self resetAttributes];

        [cursorAttrs setDictionary:defaultAttrs];
        [cursorAttrs setObject:[NSColor whiteColor] forKey:NSBackgroundColorAttributeName];
        cursorString = [[NSAttributedString alloc] initWithString:@" " attributes:cursorAttrs];

        [self initLineStrings];
        [self clear];
        [self showCursor];
    }
    return self;
}

- (oneway void)dealloc
{
    [cursorString release];
    [stringUnderCursor release];
    [defaultAttrs release];
    [currentAttrs release];
	[theRegularFont release];
	[theBoldFont release];
}

- (int)columns
{
	return pagewidth;
}

- (int)rows
{
	return pageheight;
}

- (void)resetAttributes
{
    [currentAttrs setDictionary:defaultAttrs];
}

- (void)initLineStrings
{
    NSString *s1 = [NSString string];
    int i;

    for (i=0; i<pagewidth; i++)
    {
        s1 = [s1 stringByAppendingString:@" "];
    }
    emptyLine = [[NSAttributedString alloc] initWithString:s1 attributes:currentAttrs];
    endOfLine = [[NSAttributedString alloc] initWithString:@"\r" attributes:currentAttrs];
}

- (void)updateLineStrings
{
    [emptyLine autorelease];
    [endOfLine autorelease];
    emptyLine = [[NSAttributedString alloc] initWithString:[emptyLine string] attributes:currentAttrs];
    endOfLine = [[NSAttributedString alloc] initWithString:[endOfLine string] attributes:currentAttrs];
}

- (void)clear
{
    int i;

    [storage deleteCharactersInRange:NSMakeRange(0, [storage length])];
    [storage appendAttributedString:emptyLine];

    topOfScreen = 0;
    lineCount = 1;

    for (i=1; i<pageheight; i++)
    {
        [self newlineBelow];
    }

	topOfScreen = 0;
}


- (void)newlineBelow
{
	++topOfScreen;
	[storage appendAttributedString:endOfLine];
	[storage appendAttributedString:emptyLine];
	++lineCount;
}


- (void)scrollTextDown
{
	NSRange lostRange;

	if (b_scroll_screen)
	{
		if (topOfScreen > 0)
		{
			//Scroll the screen up if possible
			--topOfScreen;
			--lineCount;
		}
		else
		{
			//Otherwise insert an empty line at the beginning
			[storage insertAttributedString:endOfLine atIndex:0];
			[storage insertAttributedString:emptyLine atIndex:0];
		}

		lostRange = NSMakeRange(lineCount * (pagewidth+1) - 1, pagewidth + 1);

		[storage deleteCharactersInRange:lostRange];
	}
	else if (scroll_firstline <= scroll_lastline)
	{
		int insertionPt = (topOfScreen+scroll_firstline) * (pagewidth+1);

		[storage insertAttributedString:endOfLine atIndex:insertionPt];
		[storage insertAttributedString:emptyLine atIndex:insertionPt];

		lostRange = NSMakeRange((topOfScreen+scroll_lastline+1) * (pagewidth+1) - 1, pagewidth + 1);

		[storage deleteCharactersInRange:lostRange];
	}
}


- (void)scrollTextUp
{
	if (b_scroll_screen)
	{
		[self newlineBelow];
	}
	else if (scroll_firstline <= scroll_lastline)
	{
		NSRange lostRange;
		int insertionPt = (topOfScreen+scroll_lastline+1) * (pagewidth+1) - 1;

		[storage insertAttributedString:emptyLine atIndex:insertionPt];
		[storage insertAttributedString:endOfLine atIndex:insertionPt];

		lostRange = NSMakeRange((topOfScreen+scroll_firstline) * (pagewidth+1), pagewidth + 1);

		[storage deleteCharactersInRange:lostRange];
	}
}


- (void)eraseDisplayR1:(int)r1 C1:(int)c1 R2:(int)r2 C2:(int)c2
{
    r1 += topOfScreen;
    r2 += topOfScreen;

    for ( ; r1 <= r2; ++r1)
    {
        NSRange colRange = NSMakeRange(c1, pagewidth - c1);
        NSRange destnRange;

        if (r1 == r2)
        {
            colRange.length = c2 + 1 - c1;
        }

        destnRange.location = colRange.location + r1*(pagewidth+1);
        destnRange.length = colRange.length;

        [storage replaceCharactersInRange:destnRange withAttributedString:[emptyLine attributedSubstringFromRange:colRange]];

        c1 = 0;
    }
}

- (void)formFeed
{
    int i;

    for (i=0; i<pageheight; i++)
    {
        [self newlineBelow];
    }
}

- (void)moveTextFromLeft:(int)left1 top:(int)top1 right:(int)right1 bottom:(int)bottom1 toLeft:(int)left2 top:(int)top2
{
    NSMutableAttributedString *buffer = [[[NSMutableAttributedString alloc] init] autorelease];
    NSAttributedString *padleft;
    NSAttributedString *padright;
    NSRange dstColRange;
    NSRange srcColRange;
    int rowcount = 1 + bottom1 - top1;

    srcColRange.location = left1;
    dstColRange.location = left2;
    dstColRange.length = 1 + right1 - left1;

    if (dstColRange.location >= pagewidth)
    {
        return;
    }
    if (dstColRange.location + dstColRange.length > pagewidth)
    {
        dstColRange.length = pagewidth - dstColRange.location;
    }
    if (dstColRange.location < 0)
    {
        srcColRange.location -= dstColRange.location;
        dstColRange.length += dstColRange.location;
        dstColRange.location = 0;
    }

    srcColRange.length = dstColRange.length;

    if (srcColRange.location < 0)
    {
        NSRange padRange = NSMakeRange(0, 0);

        if (srcColRange.location + srcColRange.length < 0)
        {
            padRange.length = srcColRange.length;
            srcColRange.length = 0;
        }
        else
        {
            padRange.length = -srcColRange.location;
            srcColRange.length += srcColRange.location;
        }
        srcColRange.location = 0;
        padleft = [emptyLine attributedSubstringFromRange:padRange];
    }
    else
    {
        padleft = [[[NSAttributedString alloc] initWithString:@""] autorelease];
    }

    if (srcColRange.location + srcColRange.length > pagewidth)
    {
        NSRange padRange = NSMakeRange(0, 0);

        if (srcColRange.location > pagewidth)
        {
            padRange.length = srcColRange.length;
            srcColRange.location = pagewidth;
            srcColRange.length = 0;
        }
        else
        {
            padRange.length = srcColRange.location + srcColRange.length - pagewidth;
            srcColRange.length = pagewidth - srcColRange.location;
        }
        padright = [emptyLine attributedSubstringFromRange:padRange];
    }
    else
    {
        padright = [[[NSAttributedString alloc] initWithString:@""] autorelease];
    }

    if (top2 <= top1)
    {
        //Scan rows from top
        int rownum = (top2 < 0)?0:top2;
        int stoprow = (top2 + rowcount > pageheight)?pageheight:(top2 + rowcount);

        for ( ; rownum<stoprow; ++rownum)
        {
            int srcrow = rownum + top1 - top2;
            NSRange destnRange = [self rangeForCharacterAtX:dstColRange.location Y:rownum];

            destnRange.length = dstColRange.length;
            if (srcrow < 0 || srcrow >= pageheight)
            {
                [buffer setAttributedString:emptyLine];
            }
            else
            {
                NSRange sampleRange = [self rangeForCharacterAtX:srcColRange.location Y:srcrow];

                sampleRange.length = srcColRange.length;
                [buffer setAttributedString:padleft];
                [buffer appendAttributedString:[storage attributedSubstringFromRange:sampleRange]];
                [buffer appendAttributedString:padright];
            }
            [storage replaceCharactersInRange:destnRange withAttributedString:buffer];
        }
    }
    else if (top2 > top1)
    {
        //Scan rows from bottom
        int rownum = ((top2 + rowcount > pageheight)?pageheight:(top2 + rowcount))-1;
        int stoprow = ((top2 < 0)?0:top2)-1;

        for ( ; rownum>stoprow; --rownum)
        {
            int srcrow = rownum + top1 - top2;
            NSRange destnRange = [self rangeForCharacterAtX:dstColRange.location Y:rownum];

            destnRange.length = dstColRange.length;
            if (srcrow < 0 || srcrow >= pageheight)
            {
                [buffer setAttributedString:emptyLine];
            }
            else
            {
                NSRange sampleRange = [self rangeForCharacterAtX:srcColRange.location Y:srcrow];

                sampleRange.length = srcColRange.length;
                [buffer setAttributedString:padleft];
                [buffer appendAttributedString:[storage attributedSubstringFromRange:sampleRange]];
                [buffer appendAttributedString:padright];
            }
            [storage replaceCharactersInRange:destnRange withAttributedString:buffer];
        }
    }
}

- (void)startOfPacket
{
    [storage beginEditing];
    [self hideCursor];
}

- (BOOL)interpretChar:(unichar)c
{
    if (seq_length)
    {
        if (sequence[0] == 033)
        {
            if (c == 033)
            {
                seq_length = 1;
            }
            else
            {
                if ((c >= 040 && c <= 057) || (seq_length == 1 && c == 0133))
                {
                    [self addToSequence:c];
                }
                else if (seq_length > 1 && sequence[1] == 0133)
                {
                    if (c >= 060 && c <= 077)
                    {
                        [self addToSequence:c];
                    }
                    else 
                    {
                        if (c >= 0100 && c <= 0176)
                        {
                            [self addToSequence:c];
                            [self processCS];
                            c = 0;
                        }
                        seq_length = 0;
                    }
                }
                else
                {
                    if (c >= 060 && c <= 0176)
                    {
                        [self addToSequence:c];
                        [self processES];
                        c = 0;
                    }
                    seq_length = 0;
                }
            }
        }
        else if (sequence[0] == 17)
        {
            [self addToSequence:c];

            if (seq_length == 3)
            {
                int colour = ((sequence[1] - (sequence[1]>57 ? 55 : 48))<<4) + (sequence[2] - (sequence[2]>57 ? 55 : 48));
                
                if (colour & 128)
                {
                    [currentAttrs setObject:[ColourSet get:colour&15] forKey:NSBackgroundColorAttributeName];
                }
                else
                {
                    [currentAttrs setObject:[ColourSet get:colour&15] forKey:NSForegroundColorAttributeName];
                }
                [self updateLineStrings];
                c = 0;
                seq_length = 0;
            }
        }
        else if (sequence[0] == 28)
        {
            [self addToSequence:c];

            if (seq_length == 13)
            {
                int left1, top1, right1, bottom1, left2, top2;

                left1 = ((sequence[1] - (sequence[1]>57 ? 55 : 48))<<4) + (sequence[2] - (sequence[2]>57 ? 55 : 48));
                top1 = ((sequence[3] - (sequence[3]>57 ? 55 : 48))<<4) + (sequence[4] - (sequence[4]>57 ? 55 : 48));
                right1 = ((sequence[5] - (sequence[5]>57 ? 55 : 48))<<4) + (sequence[6] - (sequence[6]>57 ? 55 : 48));
                bottom1 = ((sequence[7] - (sequence[7]>57 ? 55 : 48))<<4) + (sequence[8] - (sequence[8]>57 ? 55 : 48));
                left2 = ((sequence[9] - (sequence[9]>57 ? 55 : 48))<<4) + (sequence[10] - (sequence[10]>57 ? 55 : 48));
                top2 = ((sequence[11] - (sequence[11]>57 ? 55 : 48))<<4) + (sequence[12] - (sequence[12]>57 ? 55 : 48));

                [self moveTextFromLeft:left1 top:top1 right:right1 bottom:bottom1 toLeft:left2 top:top2];
                c = 0;
                seq_length = 0;
            }
        }
    }

    if (!seq_length)
    {
        if (c < 32 || c > 126)
        {
            switch (c)
            {
            case 8:
                if (--X < 0)
                {
                    X = pagewidth-1;
                }
                break;
            case 9:
				X = (X + 8) & ~7;
			
                if (++X == pagewidth)
                {
                    X = 0;
                }
				else
				{
					break;
				}
            case 10:
				if (Y == scroll_lastline)
				{
					[self scrollTextUp];
				}
				else if (Y < pageheight)
				{
					++Y;
				}
			    return YES;
            case 11:
				if (Y == scroll_firstline)
				{
					[self scrollTextDown];
				}
				else if (Y > 0)
				{
					--Y;
				}
                return YES;
            case 13:
                X=0;
                break;
            case 17:
            case 27:
            case 28:
                sequence[seq_length++] = c;
                break;
            }
        }
        else
        {
            NSAttributedString *string = [[[NSAttributedString alloc] initWithString:[NSString stringWithCharacters:&c length:1] attributes:currentAttrs] autorelease];
    
            [storage replaceCharactersInRange:[self rangeForCharacterAtX:X Y:Y] withAttributedString:string];
    
            if (++X == pagewidth)
            {
                X=0;
                if (++Y == pageheight)
                {
                    --Y;
                    [self newlineBelow];
                }
                return YES;
            }
        }
    }

    return NO;
}

- (void)endOfPacket
{
    [self showCursor];
    [storage endEditing];
    [view scrollRangeToVisible:[self rangeForScreenStart]];
    [view scrollRangeToVisible:[self rangeForScreenEnd]];
}

- (void)backChannelRequest:(BackChannel *)channel document:(MyDocument *)document
{
    //Finish processing output before handling the query
    [[document io] synchronise:self];

    if ([channel getInt:0] == 0)
    {
        //Cursor position request
        [channel setInt:1 value:X];
        [channel setInt:2 value:Y];
    }
	else if ([channel getInt:0] == 1)
	{
		//Terminal dimensions request
		[channel setInt:1 value:pagewidth];
		[channel setInt:2 value:pageheight];
	}
	else
	{
		//Pass on to document's JLib simulation code
		[document jlibSimulationRequest:channel];
	}
}

- (void)screenUpdateRequest:(BackChannel *)channel document:(MyDocument *)document
{
    [document screenUpdateRequest:channel];
}

- (NSRange)rangeForScreenStart
{
    return [self rangeForCharacterAtX:0 Y:0];
}

- (NSRange)rangeForScreenEnd
{
    return [self rangeForCharacterAtX:pagewidth-1 Y:pageheight-1];
}

- (NSRange)rangeForCharacterAtX:(int)x Y:(int)y
{
    return NSMakeRange((pagewidth+1)*(topOfScreen+y)+x, 1);
}

- (void)showCursor
{
    if (!stringUnderCursor)
    {
        NSRange range = [self rangeForCharacterAtX:X Y:Y];

        stringUnderCursor = [[storage attributedSubstringFromRange:range] copy];
        [storage replaceCharactersInRange:range withAttributedString:cursorString];
    }
}

- (void)hideCursor
{
    if (stringUnderCursor)
    {
        [storage replaceCharactersInRange:[self rangeForCharacterAtX:X Y:Y] withAttributedString:stringUnderCursor];
        [stringUnderCursor release];
        stringUnderCursor = nil;
    }
}

- (void)outputString:(NSString *)string
{
    int i, length = [string length];

    [self startOfPacket];

    for (i=0; i<length; i++)
    {
        [self interpretChar:[string characterAtIndex:i]];
    }

    [self endOfPacket];
}

- (BOOL)scrollbackNotEmpty
{
    return topOfScreen > 0;
}

- (void)clearScrollback
{
    NSRange range = [self rangeForScreenStart];

    [self startOfPacket];
    range.length = range.location;
    range.location = 0;
    [storage deleteCharactersInRange:range];
    topOfScreen = 0;
    lineCount = pageheight;
    [self endOfPacket];
}

- (void)addToSequence:(unichar)c
{
    if (seq_length < 15)
    {
        sequence[seq_length++] = c;
    }
    else
    {
        //Overflow
        seq_length = 0;
    }
}

- (void)processES
{
}

- (void)processCS
{
    int param1, param2;

    sequence[seq_length] = 0;

    switch (sequence[seq_length-1])
    {
    case 'A': //CUU
        param1 = 1;
        [self extractParam1:&param1];
        Y = (Y < param1) ? 0 : (Y - param1);
        break;
    case 'B': //CUD
        param1 = 1;
        [self extractParam1:&param1];
        Y = (Y + param1 >= pageheight) ? (pageheight-1) : (Y + param1);
        break;
    case 'C': //CUF
        param1 = 1;
        [self extractParam1:&param1];
        X = (X + param1 >= pagewidth) ? (pagewidth-1) : (X + param1);
        break;
    case 'D': //CUB
        param1 = 1;
        [self extractParam1:&param1];
        X = (X < param1) ? 0 : (X - param1);
        break;
    case 'H': //CUP
        param1 = param2 = 1;
        [self extractParam1:&param1 param2:&param2];
        X = (param2 > pagewidth)?(pagewidth-1):(param2-1);
        Y = (param1 > pageheight)?(pageheight-1):(param1-1);
        break;
    case 'J': //ED
        param1 = 0;
        [self extractParam1:&param1];
        switch (param1)
        {
        case 0:
            [self eraseDisplayR1:Y C1:X R2:pageheight-1 C2:pagewidth-1];
            break;
        case 1:
            [self eraseDisplayR1:0 C1:0 R2:Y C2:X];
            break;
        case 2:
			[self formFeed];
            //[self eraseDisplayR1:0 C1:0 R2:pageheight-1 C2:pagewidth-1];
            break;
        }
        break;
    case 'K': //EL
        param1 = 0;
        [self extractParam1:&param1];
        switch (param1)
        {
        case 0:
            [self eraseDisplayR1:Y C1:X R2:Y C2:pagewidth-1];
            break;
        case 1:
            [self eraseDisplayR1:Y C1:0 R2:Y C2:X];
            break;
        case 2:
            [self eraseDisplayR1:Y C1:0 R2:Y C2:pagewidth-1];
            break;
        }
        break;
    case 'm': //Character attributes
		{
			char *attrStr = sequence + 2;
		
			//Reset to defaults
			[self resetAttributes];

			//Parse escape string
			while (*attrStr != 'm')
			{
				BOOL reverse = FALSE;
				BOOL conceal = FALSE;
				int attr = 0;
				int c;

				while ((c = *attrStr), c >= '0' && c <= '9')
				{
					attr = attr * 10 + (c - '0');
					++attrStr;
				}

				if (c != 'm') ++attrStr;

				switch (attr)
				{
				case 0: //All attributes off
					{
						[currentAttrs removeObjectForKey:NSUnderlineStyleAttributeName];
						[currentAttrs setObject:theRegularFont forKey:NSFontAttributeName];
						reverse = FALSE;
						conceal = FALSE;
					}
					break;
				case 1: //Bold on
					[currentAttrs setObject:theBoldFont forKey:NSFontAttributeName];
					break;
				case 4: //Underscore on
					[currentAttrs setObject:[NSNumber numberWithInt:1] forKey:NSUnderlineStyleAttributeName];
					break;
				case 7: //Reverse on
					reverse = TRUE;
					break;
				case 8: //Concealed on
					conceal = TRUE;
					break;
				case 30:
					[currentAttrs setObject:[NSColor blackColor] forKey:NSForegroundColorAttributeName];
					break;
				case 31:
					[currentAttrs setObject:[NSColor redColor] forKey:NSForegroundColorAttributeName];
					break;
				case 32:
					[currentAttrs setObject:[NSColor greenColor] forKey:NSForegroundColorAttributeName];
					break;
				case 33:
					[currentAttrs setObject:[NSColor yellowColor] forKey:NSForegroundColorAttributeName];
					break;
				case 34:
					[currentAttrs setObject:[NSColor blueColor] forKey:NSForegroundColorAttributeName];
					break;
				case 35:
					[currentAttrs setObject:[NSColor magentaColor] forKey:NSForegroundColorAttributeName];
					break;
				case 36:
					[currentAttrs setObject:[NSColor cyanColor] forKey:NSForegroundColorAttributeName];
					break;
				case 37:
					[currentAttrs setObject:[NSColor whiteColor] forKey:NSForegroundColorAttributeName];
					break;
				case 40:
					[currentAttrs setObject:[NSColor blackColor] forKey:NSBackgroundColorAttributeName];
					break;
				case 41:
					[currentAttrs setObject:[NSColor redColor] forKey:NSBackgroundColorAttributeName];
					break;
				case 42:
					[currentAttrs setObject:[NSColor greenColor] forKey:NSBackgroundColorAttributeName];
					break;
				case 43:
					[currentAttrs setObject:[NSColor yellowColor] forKey:NSBackgroundColorAttributeName];
					break;
				case 44:
					[currentAttrs setObject:[NSColor blueColor] forKey:NSBackgroundColorAttributeName];
					break;
				case 45:
					[currentAttrs setObject:[NSColor magentaColor] forKey:NSBackgroundColorAttributeName];
					break;
				case 46:
					[currentAttrs setObject:[NSColor cyanColor] forKey:NSBackgroundColorAttributeName];
					break;
				case 47:
					[currentAttrs setObject:[NSColor whiteColor] forKey:NSBackgroundColorAttributeName];
					break;
				default:
					break;
				}

				if (reverse)
				{
					NSColor *b = [currentAttrs objectForKey:NSBackgroundColorAttributeName];
					NSColor *f = [currentAttrs objectForKey:NSForegroundColorAttributeName];
					[currentAttrs setObject:f forKey:NSBackgroundColorAttributeName];
					[currentAttrs setObject:b forKey:NSForegroundColorAttributeName];
				}
				if (conceal)
				{
					NSColor *b = [currentAttrs objectForKey:NSBackgroundColorAttributeName];
					[currentAttrs setObject:b forKey:NSForegroundColorAttributeName];
				}
			}
			[self updateLineStrings];
		}
        break;
	case 'r':
        param1 = param2 = -1;

		[self extractParam1:&param1 param2:&param2];

		if (param1 == -1)
		{
			b_scroll_screen = YES;
		}
		else
		{
			if (param2 == -1 || param2 > pageheight)
			{
				scroll_lastline = (pageheight-1);
			}
			else
			{
				scroll_lastline = (param2-1);
			}

			scroll_firstline = (param1 > pageheight)?(pageheight-1):(param1-1);

			b_scroll_screen = NO;
		}
        break;
	case 'L':
		if (Y == scroll_firstline)
		{
			[self scrollTextDown];
		}
		else if (Y > 0)
		{
			--Y;
		}
		break;
    }
}

- (void)extractParam1:(int*)p1
{
    int r1 = 0;
    char *s = sequence + 2;

    if (*s < 074)
    {
        r1 = atoi(s);
    }

    if (r1) *p1 = r1;
}

- (void)extractParam1:(int*)p1 param2:(int*)p2
{
    int r1 = 0;
    int r2 = 0;
    char *s = sequence + 2;

    if (*s < 074)
    {
        r1 = atoi(s);

        for ( ; s + 1 < sequence + seq_length; ++s)
        {
            if (*s < 060 || *s > 071)
            {
                break;
            }
        }

        if (*s == 073) r2 = atoi(s + 1);
    }

    if (r1) *p1 = r1;
    if (r2) *p2 = r2;
}

@end
