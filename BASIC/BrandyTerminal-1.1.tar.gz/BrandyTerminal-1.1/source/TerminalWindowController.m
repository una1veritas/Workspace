/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002, 2004-5 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the implementation of the
**	TerminalWindowController class.
**
**	The TerminalWindowController class alters the process of
**	displaying a new document window.
**
**	Firstly it replaces the NSTextView from MyDocument.nib with
**	a subclass which handles text input differently.
**
**	It then uses the OutputInterpreter class to create a blank
**	page and resizes the terminal window to fit.
**
**	Finally, it informs the document object when the window is
**	visible so that it can display the 'Start Brandy' panel.
*/

#import "TerminalWindowController.h"

#import "MyDocument.h"
#import "TerminalView.h"
#import "GraphicsView.h"
#import "OutputInterpreter.h"
#import "StartupOptions.h"
#import "AppDelegate.h"
#import "btermjlib.h"

@interface TerminalWindowController (PrivateMethods)
- (void)initTerminalView;
@end

@implementation TerminalWindowController

- (id)init
{
    return [super initWithWindowNibName:@"MyDocument"];
}


- (void)initTerminalView
{
    NSSize scrollViewSize;

    //Substitute a TerminalView object so text input can be intercepted
    terminalView = [TerminalView replacementViewFor:[scrollView documentView]];
    [terminalView setDocument:[self document]];

    interpreter = [[OutputInterpreter interpreterForView:terminalView options:[StartupOptions currentOptions]] retain];

	[terminalView setFrameSize:NSMakeSize(100000, 100000)];
	[terminalView setVerticallyResizable:YES];
	[terminalView sizeToFit];
    [terminalView setHorizontallyResizable:YES];
    [terminalView sizeToFit];

    terminalViewSize = [terminalView frame].size;

    scrollViewSize = [NSScrollView frameSizeForContentSize:terminalViewSize hasHorizontalScroller:[scrollView hasHorizontalScroller] hasVerticalScroller:[scrollView hasVerticalScroller] borderType:[scrollView borderType]];
	[scrollView retain];

    [[self window] setContentSize:scrollViewSize];
}


- (void)windowDidLoad
{
	[self initTerminalView];

        originalContainerView = [scrollView superview];
        containerView = originalContainerView;

	[[self window] setTitle:NSLocalizedString(@"(Unopened)", @"")];
    [[self window] makeFirstResponder:terminalView];

	[[self document] interpreterReady:interpreter];

	[super windowDidLoad];
}


- (oneway void)dealloc
{
	[scrollView autorelease];
	[graphicsView autorelease];

    [super dealloc];
}


- (struct winsize)winsize
{
	struct winsize winsize;

	winsize.ws_col = [interpreter columns];
	winsize.ws_row = [interpreter rows];
	winsize.ws_xpixel = terminalViewSize.width;
	winsize.ws_ypixel = terminalViewSize.height;

	return winsize;
}


- (void)switchToGraphicsViewScreen:(btjlScreenBuffer *)screen
{
	if (!graphicsView)
	{
		NSRect frame;

		frame.origin.x = 0;
		frame.origin.y = 0;
		frame.size.width = BTJL_SCREEN_WIDTH;
		frame.size.height = BTJL_SCREEN_HEIGHT;

		graphicsView = [[GraphicsView alloc] initWithFrame:frame];
                [graphicsView setDocument:[self document]];
	}

	if (graphicsView && ([scrollView superview] != NULL))
	{
		NSSize viewSize;

		[graphicsView setScreen:screen];
		[containerView replaceSubview:scrollView with:graphicsView];

		viewSize = [graphicsView frame].size;
		[[self window] setContentSize:viewSize];

		[[graphicsView window] makeFirstResponder:graphicsView];
	}
}

- (void)switchToTerminalView
{
	if (graphicsView && ([graphicsView superview] != NULL))
	{
		NSSize scrollViewSize;

		[graphicsView setScreen:NULL];

		scrollViewSize = [NSScrollView frameSizeForContentSize:terminalViewSize hasHorizontalScroller:[scrollView hasHorizontalScroller] hasVerticalScroller:[scrollView hasVerticalScroller] borderType:[scrollView borderType]];

		[[self window] setContentSize:scrollViewSize];
		[containerView replaceSubview:graphicsView with:scrollView];

		[[terminalView window] makeFirstResponder:terminalView];
	}
}

- (void)updateScreen
{
	[graphicsView setNeedsDisplay:YES];
}

- (IBAction)toggleFullscreenMode:(id)sender
{
        AppDelegate *appDelegate = [[NSApplication sharedApplication] delegate];

        if ([appDelegate fullscreenController] != nil)
        {
            [appDelegate setFullscreenController:nil];
        }
        else
        {
            [appDelegate setFullscreenController:self];
        }
}

- (void)setContainerView:(NSView *)view
{
    if (view == nil)
    {
        view = originalContainerView;
    }

    if (view != containerView)
    {
        NSView *activeView = nil;

        if ([graphicsView superview] != nil)
        {
            activeView = graphicsView;
        }
        else if ([scrollView superview] != nil)
        {
            activeView = scrollView;
        }

        if (activeView != nil)
        {
            //Remove from old container view
            [activeView removeFromSuperview];

            //Add to new container view
            [view addSubview:activeView];

            [[activeView window] makeFirstResponder:activeView];
            [[activeView window] makeKeyWindow];
        }

        containerView = view;
    }
}

@end
