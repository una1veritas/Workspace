/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the implementation of the TerminalIO class.
**
**	The TerminalIO class opens input and output streams for the
**	pseudoterminal that connects BrandyTerminal to Brandy.
**
**	On request, it checks the output stream and sends characters
**	to an interpreter object which updates the terminal window's text.
*/

#import "TerminalIO.h"

#import <fcntl.h>
#import <termios.h>

@implementation TerminalIO

+ (TerminalIO *)terminalIOWithFD:(int)filedes
{
    return [[[self alloc] initWithFD:filedes] autorelease];
}

- (id)initWithFD:(int)filedes
{
    if (self = [super init])
    {
        inputStream = fdopen(filedes, "w");
        outputStream = fdopen(filedes, "r");
        fcntl(filedes, F_SETFL, fcntl(filedes, F_GETFL) | O_NONBLOCK);
        fd = filedes;
    }
    return self;
}

- (oneway void)dealloc
{
    fclose(inputStream);
    fclose(outputStream);
    [super dealloc];
}

- (FILE *)inputStream
{
    return inputStream;
}

- (void)pollOutput:(id)interpreter
{
    char c;

    if (fread(&c, 1, 1, outputStream) == 1)
    {
        int breaklimit = 4;

        [interpreter startOfPacket];
        do
        {
            if ([interpreter interpretChar:c]) --breaklimit;
        }
        while (breaklimit && fread(&c, 1, 1, outputStream));
        [interpreter endOfPacket];
    }
}

- (void)synchronise:(id)interpreter
{
    char c;

    if (fread(&c, 1, 1, outputStream) == 1)
    {
        [interpreter startOfPacket];
        do
        {
            [interpreter interpretChar:c];
        }
        while (fread(&c, 1, 1, outputStream));
        [interpreter endOfPacket];
    }
}

@end
