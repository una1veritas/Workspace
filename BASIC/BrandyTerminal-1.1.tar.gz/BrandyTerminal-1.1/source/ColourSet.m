/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file defines the colours used by the OutputInterpreter
**	class.
**
**	The ColourSet class returns colours from a single NSColor array,
**	which is initialised when the first request is received.
*/
#import "ColourSet.h"


@interface ColourSet (PrivateMethods)
+ (NSArray *)colours;
+ (NSColor *)darkerColour:(NSColor *)startColour;
@end

@implementation ColourSet

+ (NSArray *)colours
{
    static NSArray * colourset = nil;

    if (!colourset)
    {
        colourset = [NSArray array];
    
        colourset = [colourset arrayByAddingObject:[NSColor blackColor]];
        colourset = [colourset arrayByAddingObject:[NSColor redColor]];
        colourset = [colourset arrayByAddingObject:[NSColor greenColor]];
        colourset = [colourset arrayByAddingObject:[NSColor yellowColor]];
        colourset = [colourset arrayByAddingObject:[NSColor blueColor]];
        colourset = [colourset arrayByAddingObject:[NSColor magentaColor]];
        colourset = [colourset arrayByAddingObject:[NSColor cyanColor]];
        colourset = [colourset arrayByAddingObject:[NSColor whiteColor]];
    
        colourset = [colourset arrayByAddingObject:[NSColor darkGrayColor]];
        colourset = [colourset arrayByAddingObject:[self darkerColour:[NSColor redColor]]];
        colourset = [colourset arrayByAddingObject:[self darkerColour:[NSColor greenColor]]];
        colourset = [colourset arrayByAddingObject:[NSColor brownColor]];
        colourset = [colourset arrayByAddingObject:[self darkerColour:[NSColor blueColor]]];
        colourset = [colourset arrayByAddingObject:[self darkerColour:[NSColor magentaColor]]];
        colourset = [colourset arrayByAddingObject:[self darkerColour:[NSColor cyanColor]]];
        colourset = [colourset arrayByAddingObject:[NSColor lightGrayColor]];
    
        [colourset retain];
    }
    return colourset;
}

+ (NSColor *)darkerColour:(NSColor *)startColour
{
    return [startColour blendedColorWithFraction:0.5f ofColor:[NSColor blackColor]];
}

+ (NSColor *)get:(int)n
{
    return [[self colours] objectAtIndex:n];
}

@end
