/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the interface for the Child class.
**
**	The Child class serves to run the Brandy child process
**	and to notify its delegate of events, such as the termination
**	of the child process.
*/

#import <Foundation/Foundation.h>

@class StartupOptions;

@interface Child : NSObject {
    id delegate;

    pid_t process_id;
    NSString *ptyname;
    int ptyfd;
    int exitStatus;
}

+ (void)initChildList;
+ (void)handleSIGCHLD;
+ (Child *)childWithOptions:(StartupOptions *)options winsize:(struct winsize)winsize delegate:(id)aDelegate;

- (id)initWithOptions:(StartupOptions *)options winsize:(struct winsize)winsize delegate:(id)aDelegate;
- (void)setDelegate:(id)aDelegate;
- (void)poll;

- (NSString *)ptyname;
- (int)ptyFileDescriptor;
- (void)kill;
- (NSString *)exitStatusString;

@end

@interface NSObject (ChildDelegate)
- (int)childSetEnv:(Child *)child;
- (void)childTerminated:(Child *)child;
@end
