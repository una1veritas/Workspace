/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the interface for the OutputInterpreter class.
**
**	The OutputInterpreter class controls the text that appears in
**	the terminal window.
*/

#import <Cocoa/Cocoa.h>

@class StartupOptions;

@interface OutputInterpreter : NSObject {
    NSTextView * view;
    NSTextStorage * storage;
    NSDictionary * defaultAttrs;
    NSMutableDictionary * currentAttrs;
	NSFont *theRegularFont;
	NSFont *theBoldFont;
    NSAttributedString * cursorString;
    NSAttributedString * stringUnderCursor;
    NSAttributedString * emptyLine;
    NSAttributedString * endOfLine;
    int pagewidth, pageheight;
    int last_line;
    int topOfScreen;
    int lineCount;
    int X, Y;
    int seq_length;
    char sequence[16];
	bool b_scroll_screen;
	int scroll_firstline, scroll_lastline;
}
+ (OutputInterpreter *)interpreterForView:(NSTextView *)theStorage options:(StartupOptions *)options;
+ (NSFont*)regularFontFromFamily:(NSString*)familyName size:(float)size;
+ (NSFont*)boldFontFromFamily:(NSString*)familyName size:(float)size;
+ (BOOL)isSuitableFontFamily:(NSString*)familyName;
+ (NSFont*)suitableBoldFontFromFamily:(NSString*)familyName size:(float)size;
- (int)columns;
- (int)rows;
- (void)resetAttributes;
- (void)outputString:(NSString *)string;
- (BOOL)scrollbackNotEmpty;
- (void)clearScrollback;
@end
