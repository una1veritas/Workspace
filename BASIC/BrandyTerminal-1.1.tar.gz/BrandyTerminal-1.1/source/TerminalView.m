/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002, 2005 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the implementation of the TerminalView class.
**
**	The TerminalView class redirects text input to the Brandy process,
**	performing some key translation in doing so.
**
**	It also implements the Interrupt menu command (keyboard
**	shortcuts Command-. and Escape), with a workaround for Brandy's
**	Ctrl-C waits for another keypress problem.
*/

#import "TerminalView.h"

#import <time.h>
#import "MyDocument.h"

@interface TerminalView (PrivateMethods)

- (id)initToReplace:(NSTextView *)view;

@end

@implementation TerminalView

+ (NSTextView *)replacementViewFor:(NSTextView *)view
{
    TerminalView *newView = [[[self alloc] initToReplace:view] autorelease];

    if (newView)
    {
        [[view enclosingScrollView] setDocumentView:newView];
        return newView;
    }
    return view;
}

- (id)initToReplace:(NSTextView *)view
{
    if (self = [super initWithFrame:[view frame]])
    {
        [self setTextColor:[view textColor]];
        [self setBackgroundColor:[view backgroundColor]];
        [self setRichText:NO];
        [self setEditable:NO];
        [[self textStorage] setAttributedString:[view textStorage]];
    }
    return self;
}


- (void)setDocument:(MyDocument *)theDocument
{
        document = theDocument;
}


- (MyDocument *)document
{
	return document;
}


- (void)keyDown:(NSEvent *)theEvent
{
	[[self document] keyDown:theEvent];
}

- (void)insertText:(id)aString
{
	[[self document] insertText:aString];
}

- (IBAction)interrupt:(id)sender
{
	[[self document] interrupt:sender];
}


- (IBAction)paste:(id)sender
{
	[[self document] paste:sender];
}


- (BOOL)validateMenuItem:(NSMenuItem *)anItem
{
    if ([anItem action] == @selector(paste:))
    {
        NSPasteboard *pb = [NSPasteboard generalPasteboard];

        return [[self document] inputStream] && [NSStringPboardType isEqualToString:[pb availableTypeFromArray:[NSArray arrayWithObject:NSStringPboardType]]];
    }
    else if ([anItem action] == @selector(interrupt:))
    {
        return [[self document] inputStream] != NULL;
    }
    else
	{
		return [super validateMenuItem:anItem];
	}
}

@end
