/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2004, 2005 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the implementation of the GraphicsView class.
**
**	The GraphicsView class provides a window-based target for graphical operations.
*/

#import "GraphicsView.h"

#import "MyDocument.h"
#import "btermjlib.h"


@implementation GraphicsView

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
    }
    return self;
}

- (void)drawRect:(NSRect)rect {
    // Drawing code here.
	if (screenBuffer)
	{
		Rect r = { 0, 0, BTJL_SCREEN_HEIGHT, BTJL_SCREEN_WIDTH };
		int i;
	
		if (!colourTable)
		{
			colourTable = GetCTable(40);

			screenBuffer->state |= BTJL_PALETTE_CHANGE;
		}

		if (screenBuffer->state & BTJL_PALETTE_CHANGE)
		{
			int index = 0;

			if (gworld)
			{
				DisposeGWorld(gworld);
				gworld = NULL;
			}

			CTabChanged(colourTable);
			screenBuffer->state &= ~BTJL_PALETTE_CHANGE;
			
			for (i=0; i<256; ++i, index += 3)
			{
				(*colourTable)->ctTable[i].rgb.red = screenBuffer->palette[index]<<8;
				(*colourTable)->ctTable[i].rgb.green = screenBuffer->palette[index+1]<<8;
				(*colourTable)->ctTable[i].rgb.blue = screenBuffer->palette[index+2]<<8;
			}
		}

		if (!gworld)
		{
			NewGWorldFromPtr(&gworld, 8, &r, colourTable, NULL, 0, screenBuffer->pixels, BTJL_SCREEN_WIDTH);
		}

		screenBuffer->state &= ~BTJL_PIXEL_CHANGE;

		CopyBits(GetPortBitMapForCopyBits(gworld),
			GetPortBitMapForCopyBits([self qdPort]),
			&r, &r, srcCopy, NULL);
	}
}

- (void)setScreen:(btjlScreenBuffer *)screen
{
	screenBuffer = screen;
}

- (BOOL)acceptsFirstResponder
{
	return YES;
}


- (oneway void)dealloc
{
    if (colourTable)
	{
		DisposeCTable(colourTable);
		colourTable = NULL;
	}
	if (gworld)
	{
		DisposeGWorld(gworld);
		gworld = NULL;
	}
}


- (void)setDocument:(MyDocument *)theDocument
{
        document = theDocument;
}


- (MyDocument *)document
{
	return document;
}


- (void)keyDown:(NSEvent *)theEvent
{
	[[self document] keyDown:theEvent];
}

- (void)insertText:(id)aString
{
	[[self document] insertText:aString];
}

- (IBAction)interrupt:(id)sender
{
	[[self document] interrupt:sender];
}


- (IBAction)paste:(id)sender
{
	[[self document] paste:sender];
}


- (BOOL)validateMenuItem:(NSMenuItem *)anItem
{
	if ([anItem action] == @selector(paste:))
    {
        NSPasteboard *pb = [NSPasteboard generalPasteboard];

        return [[self document] inputStream] && [NSStringPboardType isEqualToString:[pb availableTypeFromArray:[NSArray arrayWithObject:NSStringPboardType]]];
    }
    else if ([anItem action] == @selector(interrupt:))
    {
        return [[self document] inputStream] != NULL;
    }
	else
	{
		return FALSE;
	}
}


@end
