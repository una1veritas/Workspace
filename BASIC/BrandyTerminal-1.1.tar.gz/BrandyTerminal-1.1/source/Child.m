/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the interface for the Child class.
**
**	The Child class serves to launch and monitor an instance of
**	the Brandy interpreter located in the BrandyTerminal application
**	package.
**
**	The forking of BrandyTerminal in initWithOptions:delegate:
**	confuses the debugger. In particular breakpointing
**	runWithOptions: (which executes in the child process) is
**	problematic.
**
**	It's possible to debug Brandy using an instance of gdb in
**	the terminal window. This change is included, but commented
**	out, in the runWithOptions: method.
*/

#import "Child.h"

#import <unistd.h>
#import <util.h>
#import <sys/types.h>
#import <sys/wait.h>
#import <stdlib.h>
#import "StartupOptions.h"

static NSMutableArray *_children;

@interface Child (PrivateMethods)

+ (void)addChild:(Child *)c;
+ (void)removeChild:(Child *)c;
- (void)runWithOptions:(StartupOptions *)options;
- (void)abortWithMessage:(NSString *)message;
- (void)checkStatus;

@end

@implementation Child

+ (void)initChildList
{
    _children = [[NSMutableArray arrayWithCapacity:0] retain];
}

+ (void)addChild:(Child *)c
{
    //Work on a copy of the array, so the SIGCHLD handler always gets an intact array
    NSMutableArray *original = _children;

    if (![original containsObject:c])
    {
        NSMutableArray *copy = [[NSMutableArray arrayWithCapacity:[original count]+1] retain];
    
        [copy addObjectsFromArray:original];
        [copy addObject:c];
    
        _children = copy;
        [original release];
    }
}

+ (void)removeChild:(Child *)c
{
    //Work on a copy of the array, so the SIGCHLD handler always gets an intact array
    NSMutableArray *original = _children;

    if ([original containsObject:c])
    {
        NSMutableArray *copy = [[NSMutableArray arrayWithCapacity:[original count]-1] retain];
    
        [copy addObjectsFromArray:original];
        [copy removeObject:c];
    
        _children = copy;
        [original release];
    }
}

+ (void)handleSIGCHLD
{
    int i, count = [_children count];

    for (i=0; i<count; i++)
    {
        [(Child *)[_children objectAtIndex:i] checkStatus];
    }
}

+ (Child *)childWithOptions:(StartupOptions *)options winsize:(struct winsize)winsize delegate:(id)aDelegate
{
    return [[[self alloc] initWithOptions:options winsize:(struct winsize)winsize delegate:aDelegate] autorelease];
}

- (id)initWithOptions:(StartupOptions *)options winsize:(struct winsize)winsize delegate:(id)aDelegate
{
    if (self = [super init])
    {
        char name[256];
        int fd;

        //Initialise ptyfd to -1
        ptyfd = -1;

        //Store reference to delegate
        delegate = aDelegate;

        //Register for SIGCHLD
        [Child addChild:self];

        //Open pseudoterminal
        process_id = forkpty(&fd, name, NULL, &winsize);

        switch (process_id)
        {
        case 0: //Child process - forkpty succeeded
            [self runWithOptions:options]; //shouldn't return
            break;
        case -1: //Parent process - forkpty failed
            [self autorelease];
            self = nil;
            break;
        default: //Parent process - forkpty succeeded
            ptyname = [[NSString stringWithCString:name] retain];
            ptyfd = fd;
            break;
        }
    }
    return self;
}

- (void)setDelegate:(id)aDelegate
{
    delegate = aDelegate;
}

- (oneway void)dealloc
{
    [ptyname release];
    [super dealloc];
}

- (void)runWithOptions:(StartupOptions *)options
{
    NSString *command = [[NSBundle mainBundle] pathForResource:@"brandy" ofType:nil];

    //Place Brandy's path in quotes, so that any spaces won't cause trouble
    command = [NSString localizedStringWithFormat:@"\"%@\"", command];

    //Build the command line for running Brandy
    //command = [[NSString stringWithCString:"gdb "] stringByAppendingString:command];
    command = [command stringByAppendingString:@" "];
    command = [command stringByAppendingString:[options cmdlineOptions]];

    if (!command)
    {
        [self abortWithMessage:NSLocalizedString(@"Brandy executable not found in application bundle.\n", @"")];
    }

    //Switch to the specified working directory
    if (![[NSFileManager defaultManager] changeCurrentDirectoryPath:[options workingDirectory]])
    {
        [self abortWithMessage:[NSString localizedStringWithFormat:NSLocalizedString(@"Can't switch to directory '%s'.\n", @""), [options workingDirectory]]];
    }

    //Execute the child environment setup callback
    if ([delegate respondsToSelector:@selector(childSetEnv:)])
    {
        if ([delegate childSetEnv:self] != 0)
        {
            [self abortWithMessage:NSLocalizedString(@"The setting up of environment variables has failed.\n", @"")];
        }
    }

    //Use the shell to run brandy, so that redirection is possible
    execl(getenv("SHELL"), "sh", "-c", [command cString], (char *)0);

    [self abortWithMessage:NSLocalizedString(@"Failed to run brandy via the shell.\n", @"")];
}

- (void)abortWithMessage:(NSString *)message
{
    fprintf(stderr, [message cString]);
	fflush(stderr);
    exit(EXIT_FAILURE);
}

- (NSString *)ptyname
{
    return ptyname;
}

- (int)ptyFileDescriptor
{
    return ptyfd;
}

- (void)kill
{
    delegate = nil;
    kill(process_id, SIGKILL);
}

- (void)checkStatus
{
    if (process_id > 0)
    {
        if (waitpid(process_id, &exitStatus, WNOHANG) == process_id)
        {
            if (WIFEXITED(exitStatus) || WIFSIGNALED(exitStatus))
            {
                //Simple signal that child process has terminated
                //Leave cleanup to -(void)poll in normal program execution
                process_id = -1;
            }
        }
    }
}

- (void)poll
{
    if (process_id < 0)
    {
        //Child process has terminated - notify delegate and clean up
        [self retain];

        [delegate childTerminated:self];

        close(ptyfd);
        [Child removeChild:self];

        [self autorelease];
    }
}

- (NSString *)exitStatusString
{
    NSString *string = nil;

    if (WIFSIGNALED(exitStatus))
    {
        string = [NSString localizedStringWithFormat:NSLocalizedString(@"\n[Brandy terminated by signal %d]\r\n", @""), WTERMSIG(exitStatus)];
    }
    else if (WIFEXITED(exitStatus))
    {
        string = [NSString localizedStringWithFormat:NSLocalizedString(@"\n[Brandy exited with status %d]\r\n", @""), WEXITSTATUS(exitStatus)];
    }

    return string;
}

@end
