/*
** This file is part of BrandyTerminal, a Mac OS X container for Brandy.
** Copyright (C) 2002, 2004-5 Crispian Daniels
**
** BrandyTerminal is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2, or (at your option)
** any later version.
**
** BrandyTerminal is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with BrandyTerminal; see the file COPYING.  If not, write to
** the Free Software Foundation, 59 Temple Place - Suite 330,
** Boston, MA 02111-1307, USA.
**
**
**	This file contains the implementation of the AppDelegate class.
**
**	It alters the default Cocoa launch behaviour by showing the
**	About panel instead of a new document.
**
**  It also displays the New Session dialog box in response to File->New
**  and ensures preferences have been stored on exit.
*/

#import "AppDelegate.h"

#import "StartupOptions.h"
#import "MyDocument.h"
#import "TerminalWindowController.h"
#import "btermjlib.h"


@interface FullscreenViewWindow : NSWindow {
}

- (BOOL)canBecomeKeyWindow;

@end

@implementation FullscreenViewWindow

- (BOOL)canBecomeKeyWindow;
{
    return YES;
}

@end


@implementation AppDelegate

- (BOOL)applicationShouldOpenUntitledFile:(NSApplication *)sender
{
    return NO;
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    NSApplication *app = [NSApplication sharedApplication];

    [app tryToPerform:@selector(orderFrontStandardAboutPanel:) with:self];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification
{
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

	[defaults synchronize];
        [self setFullscreenController:nil];
}

- (IBAction)newDocument:(id)sender
{
	[StartupOptions showDialog];
}

- (void)optionsSpecifiedForNewDocument
{
	[[NSDocumentController sharedDocumentController] newDocument:self];
}

- (TerminalWindowController*)fullscreenController
{
    return fullscreenController;
}

- (CFDictionaryRef)selectFullscreenMode
{
        enum
        {
            MAX_DISPLAYS_TO_TEST = 8
        };

	CGDirectDisplayID activeDspys[MAX_DISPLAYS_TO_TEST];
	CGDisplayCount dspyCnt;
        CFDictionaryRef match = NULL;

        if (CGGetActiveDisplayList(MAX_DISPLAYS_TO_TEST, activeDspys, &dspyCnt) == 0)
	{
		CGDisplayCount i;

		for (i=0; i<dspyCnt; i++)
		{
			long bpp = 0, width = 0, height = 0;
			boolean_t exactMatch;

			match = CGDisplayBestModeForParameters(activeDspys[i], 16, BTJL_SCREEN_WIDTH, BTJL_SCREEN_HEIGHT, &exactMatch);

			// Check against minimum requirements
			CFNumberGetValue(CFDictionaryGetValue(match, kCGDisplayBitsPerPixel), kCFNumberLongType, &bpp);
			CFNumberGetValue(CFDictionaryGetValue(match, kCGDisplayWidth), kCFNumberLongType, &width);
			CFNumberGetValue(CFDictionaryGetValue(match, kCGDisplayHeight), kCFNumberLongType, &height);

			if (bpp >= 16 && width >= BTJL_SCREEN_WIDTH && height >= BTJL_SCREEN_HEIGHT)
			{
				displayID = activeDspys[i];
				break;
			}
		}

                if (i==dspyCnt)
                {
                    match = NULL;
                }
	}

        return match;
}

- (NSRect)directDisplayFrame
{
    NSRect frameRect = NSMakeRect(0, 0, BTJL_SCREEN_WIDTH, BTJL_SCREEN_HEIGHT);
    NSArray *screens = [NSScreen screens];
    int i;

    for (i=0; i<[screens count]; ++i)
    {
        NSScreen *screen = (NSScreen*)[screens objectAtIndex:i];
        NSNumber *idNumber = [[screen deviceDescription] objectForKey:@"NSScreenNumber"];

        if ((CGDirectDisplayID)[idNumber intValue] == displayID)
        {
            frameRect = [screen frame];
            break;
        }
    }

    return frameRect;
}

- (void)setFullscreenController:(TerminalWindowController*)controller
{
    bool failed = FALSE;

    if (!fullscreenModeChange && fullscreenController != controller)
    {
        fullscreenModeChange = YES;

        if (fullscreenController == nil && controller != nil)
        {
            //Switching into fullscreen mode
            if (fullscreenWindow == nil)
            {
                NSRect r = NSMakeRect(0, 0, BTJL_SCREEN_WIDTH, BTJL_SCREEN_HEIGHT);

                fullscreenWindow = [[FullscreenViewWindow alloc] initWithContentRect:r styleMask:NSBorderlessWindowMask backing:NSBackingStoreBuffered defer:NO];

                [fullscreenWindow setDelegate:self];
            }

            failed = TRUE;

            if (fullscreenWindow != nil && CGCaptureAllDisplays() == 0)
            {
                CFDictionaryRef selectedMode;

                selectedMode = [self selectFullscreenMode];

                if (selectedMode != NULL)
                {
                    int width = 0, height = 0;

                    originalDisplayMode = CGDisplayCurrentMode(displayID);
                    CFRetain(originalDisplayMode);

                    CFNumberGetValue(CFDictionaryGetValue(selectedMode, kCGDisplayWidth), kCFNumberLongType, &width);
                    CFNumberGetValue(CFDictionaryGetValue(selectedMode, kCGDisplayHeight), kCFNumberLongType, &height);

                    if (CGDisplaySwitchToMode(displayID, selectedMode) == 0)
                    {
                        NSRect ddFr = [self directDisplayFrame];
                        NSPoint frameOrigin = NSMakePoint( ddFr.origin.x, ddFr.origin.y + ddFr.size.height - BTJL_SCREEN_HEIGHT );

                        frameOrigin.x += (width - BTJL_SCREEN_WIDTH)/2;
                        frameOrigin.y += (height - BTJL_SCREEN_HEIGHT)/2;

                        [fullscreenWindow setLevel:CGShieldingWindowLevel()];
                        [fullscreenWindow setFrameOrigin:frameOrigin];
                        [fullscreenWindow orderFront:self];
                        HideCursor();

                        failed = FALSE;
                    }

                    if (failed)
                    {
                        CFRelease(originalDisplayMode);
                    }
                }

                if (failed)
                {
                    CGReleaseAllDisplays();
                }
            }
        }

        if (fullscreenController != nil)
        {
            //Transfer view back to source window
            [fullscreenController setContainerView:nil];
        }

        if (!failed && controller != nil)
        {
            //Transfer view to fullscreen window
            [controller setContainerView:[fullscreenWindow contentView]];
        }

        if (fullscreenController != nil && controller == nil)
        {
            //Switching out of fullscreen mode
            [fullscreenWindow orderOut:self];
            ShowCursor();

            CGDisplaySwitchToMode(displayID, originalDisplayMode);
            CFRelease(originalDisplayMode);

            CGReleaseAllDisplays();
        }

        if (!failed)
        {
            fullscreenController = controller;
        }

        fullscreenModeChange = NO;
    }
}


- (void)windowDidResignKey:(NSNotification *)aNotification
{
    if ([aNotification object] == fullscreenWindow)
    {
        //Don't remain in fullscreen mode if fullscreen window ceases to be key
        [self setFullscreenController:nil];
    }
}

@end
