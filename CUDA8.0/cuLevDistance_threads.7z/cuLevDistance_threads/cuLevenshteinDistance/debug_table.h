#pragma once

//#define DEBUG_TABLE

extern long * debug_table;
