#pragma once
#ifndef __DPEDIST_H__
#define __DPEDIST_H__

long dp_edist(char t[], long n, char p[], long m);

#endif /*  __DPEDIST_H__ */
