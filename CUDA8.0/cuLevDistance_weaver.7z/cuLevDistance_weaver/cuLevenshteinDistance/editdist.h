#pragma once
#ifndef __EDITDIST_H__
#define __EDITDIST_H__

long dp_edist(char t[], long n, char p[], long m);

#endif /*  __EDITDIST_H__ */
