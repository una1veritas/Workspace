/*
	MakeImage
 
    Copyright (C) 2010 F. Zoll

	MakeImage appends 0-Bytes to the end of a given File, to fill it up
	to a desired size. Default destination size is 256256 bytes.

	Changed to append 0xE5 bytes instead of 0s.
	
    MakeImage is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    MakeImage is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with MakeImage.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "stdlib.h"
#include "stdio.h"

#define FILLBYTE 0xE5

int main (int argc, const char* argv[])
{
	unsigned int bytes,len,dsize;
	int er;
	int i;
	char	buffer[1024];
	FILE *f1,*f2;

	dsize = 256256;

	if (( argc != 3 ) && ( argc != 4 ))
	{
		printf ("Wrong Argument count !\n");
		printf ("Use like: \n MakeImage inputfile outputfile [destfilesize]\n");
		printf ("[] is optional\n");
	}

	if ( argc == 4 )
	{
		sscanf ((const char*)argv[3],"%d",&dsize);
	}

	if ( argc >= 3 )
	{
		printf ("- Opening Input File\n");
	f1 = fopen ((const char*)argv[1],"rb");	
	if ( f1 != NULL )
	{
		printf ("- Opening Output File\n");
		f2 = fopen ((const char*)argv[2],"wb");
		if ( f2 != NULL )
		{
			printf ("- Copy Input File content to Output File\n");
			len = 0;
			do
			{
				bytes = fread (buffer,1,1024,f1);
				if (bytes != 0)
				{
					fwrite (buffer,bytes,1,f2);
					len += bytes;
				}
			} while ( bytes != 0 );
			
			for ( i=0; i < 1024;i++) buffer[i] = FILLBYTE;

			printf ("- Append Empty Block to End of File\n");

			while ( len < dsize )
			{
				if ( len + 1024 <= dsize )
				{
					fwrite (buffer,1024,1,f2);
					len += 1024;
				}
				else
				{
					fwrite (buffer,dsize-len,1,f2);
					len += ( dsize - len );
				}
			}
			fclose (f2);
		}
		else
		{
			printf ("Can't open Output File !\n");
		}
		fclose (f1);
	}
	else
	{
		printf ("Input File not Found !\n");
	}
	}
	return 0;
}

