/*--------------------------------------------------------*\
 | nulrq.c                                                |
 |                                                        |
 | This file exists to provide an empty implementation of |
 | the bios() function when linking the keytest program.  |
\*--------------------------------------------------------*/

void bios(int func)
{
}

