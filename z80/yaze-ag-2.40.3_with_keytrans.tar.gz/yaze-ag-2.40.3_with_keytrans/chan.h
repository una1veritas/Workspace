#define CHNconin	0
#define CHNconout	1
#define CHNrdr		2
#define CHNpun		3
#define CHNlst		4
#define CHNaux		5
