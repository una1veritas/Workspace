void uart_init(void);		/* Initialize UART */
uint8_t uart_get (void);	/* Get a byte from UART Rx */
uint8_t uart_test(void);	/* Check number of data in UART Rx */
void uart_put (uint8_t);	/* Put a byte into UART Tx */
