/**************************************************************
*                IIC-EEPROM driver
*
* (converted LABO Gataro's "Mini LCD Driver with IIC V0.1")
*
*                                    (C)neko Java 2012.10.14
***************************************************************/
// ----------------------------------------------------------------

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <avr/sleep.h>
#include <avr/pgmspace.h>
#include <inttypes.h>
#include <string.h>

#include "iicrom.h"

// ----------------------------------------------------------------
//  Internal functions ( not prototyped in iicrom.h )
//-----------------------------------------------------------------

#if !USE_TWI
//�E�G�C�g 2.5 us
static void wait_2r5us( uint8_t t)
{ uint8_t cnt;
  while( t--)
  { for( cnt = 0; cnt<(LOOPCNT/4); cnt++)
     asm volatile("nop");
  }
}
#endif

//�E�G�C�g 10 us
static void wait_10us( uint8_t t)
{ uint8_t cnt;
  while( t--)
  { for( cnt = 0; cnt<LOOPCNT; cnt++)
     asm volatile("nop");
  }
}
//�E�F�C�g 1 ms
static void wait_ms(uint16_t t)
{ while(t--)
   wait_10us(100);
}
// ---------------------------------------------------------------
//    TWI intrinsic functions
#if USE_TWI

static uint8_t TWI_wait(void)
{
	uint8_t r;
	WAIT_TWINT;
	r=TW_STATUS;
	return(r);
}

static uint8_t TWI_write(uint8_t x)
{
	TWDR=x;
	TWI_NEXT;
	return TWI_wait();
}

uint8_t TWI_read(char ack, uint8_t *data)
{
	uint8_t r;
	if (ack) {		// IIC_NACK == 1
	   TWI_NACK;
	} else {
	   TWI_ACK;
	}
	r=TWI_wait();
	*data=TWDR;
	return (r);
}

static uint8_t TWI_sla_set(uint8_t sla_rw)
{
	uint8_t r;
	TWI_START;
	r=TWI_wait();

	if(r!=TW_REP_START && r!=TW_START) return r;
	r=TWI_write(sla_rw);
	return(r);
}

static void TWI_end(void)
{
  TWI_STOP;
  wait_10us(5);      //50us�ÂԂ����
}

static void TWI_init(void)
{
	TWSR = 0;
	TWBR = TW_BOUD;
	TWCR = 1<<TWEN;
}

#else
//----------------------------GPIO IIC referred from Mr.ChaN's RTC.c---------------

static void iic_init(void)
{
	iicROM_DDDR |=(1<<iicROM_SCL)|(1<<iicROM_SDA);     // set DDR as output port
	iicROM_DPORT &=~((1<<iicROM_SCL)|(1<<iicROM_SDA)); // PORT init
}  // set them as output port

static void iic_delay(void)
{
  wait_2r5us(1);   // 2.5 us = 400khz  
}

/* Generate start condition on the IIC bus */
static void iic_start (void)
{
	SDA_HIGH();
	iic_delay();
	SCL_HIGH();
	iic_delay();
	SDA_LOW();
	iic_delay();
	SCL_LOW();
	iic_delay();
}

/* Generate stop condition on the IIC bus */
static void iic_stop (void)
{
	SDA_LOW();
	iic_delay();
	SCL_HIGH();
	iic_delay();
	SDA_HIGH();
	iic_delay();
}

/* Send a byte to the IIC bus */
static BOOL iic_send(uint8_t dat)
{
	uint8_t b = 0x80;
	BOOL ack;

	do {
		if (dat & b)	 {	/* SDA = Z/L */
			SDA_HIGH();
		} else {
			SDA_LOW();
		}
		iic_delay();
		SCL_HIGH();
		iic_delay();
		while(SCL_VAL==0);	//add. 2012/10/14
		SCL_LOW();
		iic_delay();
	} while (b >>= 1);
	SDA_HIGH();
	iic_delay();
	SCL_HIGH();
	iic_delay();
	while(SCL_VAL==0);	//add. 2012/10/14
	ack = SDA_VAL;
	SCL_LOW();
	iic_delay();
	return ack;
}

/* Receive a byte from the IIC bus */
static uint8_t iic_read(BOOL ack)	//add. 2012/10/14
{
	uint8_t data=0, i;
	
	SDA_HIGH();
	for(i=0; i<8; i++){
		data<<=1;
		SCL_HIGH();
		iic_delay();
		while(SCL_VAL==0);
		if(SDA_VAL) data++;
		SCL_LOW();
		iic_delay();
	}
	if(ack) SDA_HIGH(); else SDA_LOW();
	iic_delay();
	SCL_HIGH();
	iic_delay();
	while(SCL_VAL==0);
	SCL_LOW();
	iic_delay();
	
	return data;
}

static uint8_t iic_sla_set(uint8_t sla)
{
	iic_start();
	return iic_send(sla);
}

static void iic_end(void)
{
	iic_stop();
	wait_10us(5);
}

#endif

//-----------------------------------------------------------------------------------------
//   iicROM Public Functions (����ȍ~��header file �Ō��J����j
//-----------------------------------------------------------------------------------------
// ������------------------------------------------------------------
void iicROM_init(void)
{
#if USE_TWI
   TWI_init();        // initialize TWI regs
#else
   iic_init();
#endif
   wait_ms(10);
}

// �y�[�W��������-------------------------------------------------------------------
uint8_t iicROM_page_write(uint16_t adr, uint8_t *data)	// 64byte per page. data[64]
{
	uint8_t r, i, adr_h, adr_l;
	adr_h = (uint8_t)(adr >> 8); adr_l = (uint8_t)(adr & 0x00FF);

#if USE_TWI
	if((r=TWI_sla_set(iicROM_ADR | TW_WRITE))!=TW_MT_SLA_ACK) goto EXIT;
	if((r=TWI_write(adr_h))!=TW_MT_DATA_ACK) goto EXIT;
	if((r=TWI_write(adr_l))!=TW_MT_DATA_ACK) goto EXIT;
	for(i=0; i<64; i++){
		if((r=TWI_write(data[i]))!=TW_MT_DATA_ACK) goto EXIT;
	}
	TWI_STOP;
	wait_ms(5);	// Write cycle time.
	return 0;
	EXIT:
	TWI_end();
	return r;
#else
	if((r=iic_sla_set(iicROM_ADR | IIC_WRITE))!=IIC_ACK) goto EXIT;
	if((r=iic_send(adr_h))!=IIC_ACK) goto EXIT;
	if((r=iic_send(adr_l))!=IIC_ACK) goto EXIT;
	for(i=0; i<64; i++){
		if((r=iic_send(data[i]))!=IIC_ACK) goto EXIT;
	}
	iic_stop();
	wait_ms(5);	// Write cycle time.
	return 0;
	EXIT:
	iic_end();
	return err_NODEV;
#endif
}

// �ǂݏo���J�n------------------------------------------------------
uint8_t iicROM_read_start(uint8_t adr_h, uint8_t adr_l)
{
	uint8_t r;

#if USE_TWI
	if((r=TWI_sla_set(iicROM_ADR | TW_WRITE))!=TW_MT_SLA_ACK) goto EXIT;
	if((r=TWI_write(adr_h))!=TW_MT_DATA_ACK) goto EXIT;
	if((r=TWI_write(adr_l))!=TW_MT_DATA_ACK) goto EXIT;
	if((r=TWI_sla_set(iicROM_ADR | TW_READ))!=TW_MR_SLA_ACK) goto EXIT;
	return 0;
	EXIT:
	TWI_end();
	return r;
#else
	if((r=iic_sla_set(iicROM_ADR | IIC_WRITE))!=IIC_ACK) goto EXIT;
	if((r=iic_send(adr_h))!=IIC_ACK) goto EXIT;
	if((r=iic_send(adr_l))!=IIC_ACK) goto EXIT;
	if((r=iic_sla_set(iicROM_ADR | IIC_READ))!=IIC_ACK) goto EXIT;
	return 0;
	EXIT:
	iic_end();
	return err_NODEV;
#endif
}

// �ǂݏo��-----------------------------------------------------------
uint8_t iicROM_read(uint8_t *data)
{
#if USE_TWI
	uint8_t r;
	if((r=TWI_read(IIC_ACK, data))!=TW_MR_DATA_ACK) goto EXIT;
	return 0;
	EXIT:
	TWI_end();
	return r;
#else
	*data=iic_read(IIC_ACK);
	return 0;
#endif
}
// �ŏI�ǂݏo��--------------------------------------------------------
uint8_t iicROM_read_end(uint8_t *data)
{
#if USE_TWI
	uint8_t r;
	if((r=TWI_read(IIC_NACK, data))!=TW_MR_DATA_NACK) goto EXIT;
	TWI_end();
	return 0;
	EXIT:
	TWI_end();
	return r;
#else
	*data=iic_read(IIC_NACK);
	iic_end();
	return 0;
#endif
}
