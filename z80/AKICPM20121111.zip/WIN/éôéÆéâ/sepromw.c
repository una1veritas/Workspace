/*-----------------------------------------------------------------------*/
/*  Serial EeP ROM Writer (Win32)              (c)neko_Java   2012.10.31 */
/*  for 32kB I2C-EEPROM (ex. 24LC256)                                    */
/*                                    (converted ChaN's avr-writer tool) */
/*-----------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include <ctype.h>
#include <windows.h>

#define MESS(str)	fputs(str, stderr)
#define MAX_SIZE	32768
//#define COMPORT		5

#define INIFILE "sepromw.ini"

/* Program error codes */
#define	RC_FAIL		1
#define	RC_FILE		2
#define	RC_INIT		3
#define RC_DEV		4
#define	RC_SYNTAX	5

/* Command */
#define	CM_READ		1
#define	CM_VERIFY	2
#define	CM_WRITE	3


/*-----------------------------------------------------------------------
  Global variables (initialized by load_commands())
-----------------------------------------------------------------------*/

BYTE CodeBuff[MAX_SIZE];		/* Program code R/W buffer */

/*---------- Command Parameters ------------*/

char Command[2];				/* -r  Read command (1st,2nd char) */

struct {						/* Code/Data write command (hex file) */
	DWORD CodeSize;				/* Loaded program code size (.hex) */
	char Mode;					/* -v 1:Verify only (skip programming) */
	BYTE HighByte;				/* address max value. high byte */
	BYTE LowByte;				/* address max value. low byte */
} CmdWrite;

static HANDLE hComm = INVALID_HANDLE_VALUE;
DWORD wnBW;
DWORD rnBW;

int ComPort=5;
int Pause;

/*-----------------------------------------------------------------------
  Messages
-----------------------------------------------------------------------*/

void output_usage ()
{
	int n;
	static const char *const MesUsage[] = {
		"I2C-EEP-ROM writing tool (c)neko Java\n\n",
		"write code        : <hex file> \n",
		"Verify code       : -V <hex file> \n",
		"Read code         : -R\n",
		"set comPort No.   : -P<No.>\n",
		NULL
	};

	for(n = 0; MesUsage[n] != NULL; n++)
		MESS(MesUsage[n]);
}


/*-----------------------------------------------------------------------
  Hex format manipulations    (by ChaN)
-----------------------------------------------------------------------*/

/* Pick a hexdecimal value from hex record */

DWORD get_valh (
	char **lp,	/* pointer to line read pointer */
	int count, 	/* number of digits to get (2,4,6,8) */
	BYTE *sum	/* byte check sum */
) {
	DWORD val = 0;
	BYTE n;


	do {
		n = *(*lp)++;
		if((n -= '0') >= 10) {
			if((n -= 7) < 10) return 0xFFFFFFFF;
			if(n > 0xF) return 0xFFFFFFFF;
		}
		val = (val << 4) + n;
		if(count & 1) *sum += (BYTE)val;
	} while(--count);
	return val;
}


/* Load Intel/Motorola hex file into data buffer */ 

long input_hexfile (
	FILE *fp,			/* input stream */
	BYTE *buffer,		/* data input buffer */
	DWORD buffsize,		/* size of data buffer */
	DWORD *datasize		/* effective data size in the input buffer */
) {
	char line[600];			/* line input buffer */
	char *lp;				/* line read pointer */
	long lnum = 0;			/* input line number */
	WORD seg = 0, hadr = 0;	/* address expantion values for intel hex */
	DWORD addr, count, n;
	BYTE sum;


	while(fgets(line, sizeof(line), fp) != NULL) {
		lnum++;
		lp = &line[1]; sum = 0;

		if(line[0] == ':') {	/* Intel Hex format */
			if((count = get_valh(&lp, 2, &sum)) > 0xFF) return lnum;	/* byte count */
			if((addr = get_valh(&lp, 4, &sum)) > 0xFFFF) return lnum;	/* offset */

			switch (get_valh(&lp, 2, &sum)) {	/* block type? */
				case 0x00 :	/* data */
					addr += (seg << 4) + (hadr << 16);
					while(count--) {
						n = get_valh(&lp, 2, &sum);		/* pick a byte */
						if(n > 0xFF) return lnum;
						if(addr >= buffsize) continue;	/* clip by buffer size */
						buffer[addr++] = (BYTE)n;		/* store the data */
						if(addr > *datasize)			/* update data size information */
							*datasize = addr;
					}
					break;

				case 0x01 :	/* end */
					if(count != 0) return lnum;
					break;

				case 0x02 :	/* segment base [19:4] */
					if(count != 2) return lnum;
					seg = (WORD)get_valh(&lp, 4, &sum);
					if(seg == 0xFFFF) return lnum;
					break;

				case 0x03 :	/* program start address (segment:offset) */
					if(count != 4) return lnum;
					get_valh(&lp, 8, &sum);
					break;

				case 0x04 :	/* high address base [31:16] */
					if(count != 2) return lnum;
					hadr = (WORD)get_valh(&lp, 4, &sum);
					if(hadr == 0xFFFF) return lnum;
					break;

				case 0x05 :	/* program start address (linear) */
					if(count != 4) return lnum;
					get_valh(&lp, 8, &sum);
					break;

				default:	/* invalid block */
					return lnum;
			} /* switch */
			if(get_valh(&lp, 2, &sum) > 0xFF) return lnum;	/* get check sum */
			if(sum) return lnum;							/* test check sum */
			continue;
		} /* if */

		if(line[0] == 'S') {	/* Motorola S format */
			if((*lp >= '1')&&(*lp <= '3')) {

				switch (*lp++) {	/* record type? (S1/S2/S3) */
					case '1' :
						count = get_valh(&lp, 2, &sum) - 3;
						if(count > 0xFF) return lnum;
						addr = get_valh(&lp, 4, &sum);
						if(addr > 0xFFFF) return lnum;
						break;
					case '2' :
						count = get_valh(&lp, 2, &sum) - 4;
						if(count > 0xFF) return lnum;
						addr = get_valh(&lp, 6, &sum);
						if(addr > 0xFFFFFF) return lnum;
						break;
					default :
						count = get_valh(&lp, 2, &sum) - 5;
						if(count > 0xFF) return lnum;
						addr = get_valh(&lp, 8, &sum);
						if(addr == 0xFFFFFFFF) return lnum;
				}
				while(count--) {
					n = get_valh(&lp, 2, &sum);
					if(n > 0xFF) return lnum;
					if(addr >= buffsize) continue;	/* clip by buffer size */
					buffer[addr++] = (BYTE)n;		/* store the data */
					if(addr > *datasize)			/* update data size information */
						*datasize = addr;
				}
				if(get_valh(&lp, 2, &sum) > 0xFF) return lnum;	/* get check sum */
				if(sum != 0xFF) return lnum;					/* test check sum */
			} /* switch */
			continue;
		} /* if */

		if(line[0] >= ' ') return lnum;
	} /* while */

	return feof(fp) ? 0 : -1;
}


/* Put an Intel Hex data block */

void put_hexline (
	FILE *fp,			/* output stream */
	const BYTE *buffer,	/* pointer to data buffer */
	WORD ofs,			/* block offset address */
	BYTE count,			/* data byte count */
	BYTE type			/* block type */
) {
	BYTE sum;

	/* Byte count, Offset address and Record type */
	fprintf(fp, ":%02X%04X%02X", count, ofs, type);
	sum = count + (ofs >> 8) + ofs + type;

	/* Data bytes */
	while(count--) {
		fprintf(fp, "%02X", *buffer);
		sum += *buffer++;
	}

	/* Check sum */
	fprintf(fp, "%02X\n", (BYTE)-sum);
}


/* Output data in Intel Hex format */

void output_hexfile (
	FILE *fp,			/* output stream */
	const BYTE *buffer,	/* pointer to data buffer */
	DWORD datasize,		/* number of bytes to be output */
	BYTE blocksize		/* HEX block size (1,2,4,..,128) */
) {
	WORD seg = 0, ofs = 0;
	BYTE segbuff[2], d, n;
	DWORD bc = datasize;


	while(bc) {
		if((ofs == 0) && (datasize > 0x10000)) {
			segbuff[0] = (BYTE)(seg >> 8); segbuff[1] = (BYTE)seg;
			put_hexline(fp, segbuff, 0, 2, 2);
			seg += 0x1000;
		}
		if(bc >= blocksize) {	/* full data block */
			for(d = 0xFF, n = 0; n < blocksize; n++) d &= *(buffer+n);
			if(d != 0xFF) put_hexline(fp, buffer, ofs, blocksize, 0);
			buffer += blocksize;
			bc -= blocksize;
			ofs += blocksize;
		} else {				/* fractional data block */
			for(d = 0xFF, n = 0; n < bc; n++) d &= *(buffer+n);
			if(d != 0xFF) put_hexline(fp, buffer, ofs, (BYTE)bc, 0);
			bc = 0;
		}
	}

	put_hexline(fp, NULL, 0, 0, 1);	/* End block */
}

/*-----------------------------------------------------------------------
   Search and Open configuration file 
-----------------------------------------------------------------------*/

FILE *open_cfgfile(char *filename)
{
	FILE *fp;
	char filepath[256], *dmy;


	if((fp = fopen(filename, "rt")) != NULL) 
		return fp;
	if(SearchPath(NULL, filename, NULL, sizeof(filepath), filepath, &dmy)) {
		if((fp = fopen(filepath, "rt")) != NULL) 
			return fp;
	}
	return NULL;
}


/*-----------------------------------------------------------------------
  Command line analysis
-----------------------------------------------------------------------*/

int load_commands (int argc, char **argv)
{
	char *cp, c, *cmdlst[20], cmdbuff[256];
	int cmd;
	FILE *fp;
	DWORD ln;


	/* Clear data buffers */
	memset(CodeBuff, 0xFF, sizeof(CodeBuff));

	cmd = 0; cp = cmdbuff;

	/* Import ini file as command line parameters */
	fp = open_cfgfile(INIFILE);
	if(fp != NULL) {
		while(fgets(cp, cmdbuff + sizeof(cmdbuff) - cp, fp) != NULL) {
			if(cmd >= (sizeof(cmdlst) / sizeof(cmdlst[0]) - 1)) break;
			if(*cp <= ' ') break;
			cmdlst[cmd++] = cp; cp += strlen(cp) + 1;
		}
		fclose(fp);
	}

	/* Get command line parameters */
	while(--argc && (cmd < (sizeof(cmdlst) / sizeof(cmdlst[0]) - 1)))
		cmdlst[cmd++] = *++argv;
	cmdlst[cmd] = NULL;

	/* Analyze command line parameters... */
	for(cmd = 0; cmdlst[cmd] != NULL; cmd++) {
		cp = cmdlst[cmd];

		if(*cp == '-') {	/* Command switches... */
			cp++;
			switch (tolower(*cp++)) {
				case 'v' :	/* -v */
					CmdWrite.Mode = 1; //verify
					break;

				case 'r' :	/* -r */
					Command[0] = 'r';
					break;

				case 'p' :	/* -p<num> (compot No.) */
					ComPort = (int)strtoul(cp, &cp, 0);
					break;

				case 'w' :	/* -w<num> (pause before exit) */
					Pause = strtoul(cp, &cp, 2) + 1;
					break;

				default :	/* invalid command */
					return RC_SYNTAX;
			} /* switch */
			if(*cp >= ' ') return RC_SYNTAX;	/* option trails garbage */
		} /* if */

		else {	/* HEX Files (Write command) */
			if((fp = fopen(cp, "rt")) == NULL) {
				fprintf(stderr, "%s : Unable to open.\n", cp);
				return RC_FILE;
			}
			ln = input_hexfile(fp, CodeBuff, sizeof(CodeBuff), &CmdWrite.CodeSize);
			fclose(fp);
			CmdWrite.HighByte = (BYTE)(CmdWrite.CodeSize >> 8);
			CmdWrite.LowByte = (BYTE)CmdWrite.CodeSize;
			if(ln) {
				if(ln < 0) {
					fprintf(stderr, "%s : File access failure.\n", cp);
				} else {
					fprintf(stderr, "%s (%ld) : Hex format error.\n", cp, ln);
				}
				return RC_FILE;
			}
		} /* else */

	} /* for */

	return 0;
}



/*-----------------------------------------------------------------------
  Port initialize and close
-----------------------------------------------------------------------*/

int open_ifport ()
{
	//Initialize control port
	char sComm[16];
	DCB dcb = { sizeof(DCB),
				38400, TRUE, FALSE, FALSE, FALSE,
				DTR_CONTROL_DISABLE, FALSE,
				FALSE, FALSE, FALSE, FALSE, FALSE,
				RTS_CONTROL_DISABLE, FALSE, 0, 0,
				10, 10,
				8, NOPARITY, ONESTOPBIT, '\x11', '\x13', '\xFF', '\xFF', 0 };

	sprintf(sComm, "\\\\.\\COM%u", ComPort);
	hComm = CreateFile(sComm, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hComm == INVALID_HANDLE_VALUE) {
		MESS("Port open error.\n");
		return RC_INIT;
	}
	SetCommState(hComm, &dcb);
	//COMMTIMEOUTS commtimeouts = { 0, 2000, 100, 100, 300};
	COMMTIMEOUTS commtimeouts = { 0, 5000, 5000, 5000, 5000};
	SetCommTimeouts(hComm, &commtimeouts);
	
	return 0;
}


void close_ifport ()
{
	//CloseHandle
	if(hComm != INVALID_HANDLE_VALUE)
		CloseHandle(hComm);
}



/*-----------------------------------------------------------------------
  Device control Pre functions
-----------------------------------------------------------------------*/

int write_byte(BYTE data)	//with check
{
	BYTE ret_data;
	
	WriteFile(hComm, &data, 1, &wnBW, NULL);
	if(wnBW != 1) {MESS("Time out.\n"); return RC_FAIL;}
	ReadFile (hComm, &ret_data, 1, &rnBW, NULL);
	if(rnBW != 1) {MESS("Time out.\n"); return RC_FAIL;}
	if(ret_data != data) {MESS("Communication error.\n"); return RC_FAIL;}
	return 0;
}

int write_page(BYTE *data)	// 64bytes per page
{
	BYTE d;
	
	WriteFile(hComm, data, 64, &wnBW, NULL);
	if(wnBW != 64) {MESS("Time out.\n"); return RC_FAIL;}
	MESS(".");
	if(read_byte(&d)) return RC_FAIL;	//dummy(wait for receive 'page write complete.')
	return 0;
}

int read_byte(BYTE *data)
{
	ReadFile (hComm, data, 1, &rnBW, NULL);
	if(rnBW != 1) {MESS("Time out.\n"); return RC_FAIL;}
	return 0;
}

/*-----------------------------------------------------------------------
  Device control functions
-----------------------------------------------------------------------*/

int command_xmit(BYTE com)
{
	BYTE com_buff[3];
	int rc;
	int i;

	if(rc = open_ifport ()) return rc;

	com_buff[0] = com;
	com_buff[1] = CmdWrite.HighByte; //address max value.
	com_buff[2] = CmdWrite.LowByte;

	for(i=0; i<3; i++){
		if(write_byte(com_buff[i])) return RC_FAIL;
	}
	return 0;
}


int read_device() // CM_READ
{
	WORD adr;
	int rc;

	if(rc = command_xmit(CM_READ)) return rc;

	MESS("Reading...");
	for(adr=0; adr < MAX_SIZE; adr++){
		if(read_byte(&CodeBuff[adr])) return RC_FAIL;
	}
	MESS("Passed.\n");
	output_hexfile(stdout, CodeBuff, MAX_SIZE, 32);
	return 0;
}

int write_device() // CM_VERIFY, CM_WRITE
{
	WORD adr;
	BYTE rt;
	int rc;
	BYTE com;

	if(CmdWrite.Mode == 1){ //verify
		com = CM_VERIFY;
	}else{
		com = CM_WRITE;
	}

	if(rc = command_xmit(com)) return rc;

	if(com == CM_WRITE){
		MESS("Writing");
		for(adr=0; adr < CmdWrite.CodeSize; adr+=64){
			if(write_page(&CodeBuff[adr])) return RC_FAIL;
		}
		MESS("Passed.\n");
	}

	MESS("Verifying...");
	for(adr=0; adr < CmdWrite.CodeSize; adr++){
		if(read_byte(&rt)) return RC_FAIL;
		if(rt != CodeBuff[adr]){
			fprintf(stderr, "Failed at %04X:%02X-%02X\n", adr, CodeBuff[adr], rt);
			return RC_FAIL;
		}
	}
	MESS("Passed.\n");
	return 0;
}


/* Terminate process */

void terminate (int rc)
{
	close_ifport();

	if((Pause == 1) || ((Pause == 2)&&(rc != 0))) {
		MESS("\nType Enter to exit...");
		getchar();
	}
}


int main (int argc, char **argv)
{
	int rc;

	if(rc = load_commands(argc, argv)) { 
		if(rc == RC_SYNTAX) output_usage();
		terminate(rc);
		return rc;
	}

	/* Read command is specified */
	if(Command[0] == 'r') {
		rc = read_device();
		terminate(rc);
		return rc;
	}

	/* Write or Verify command is specified */
	if(CmdWrite.CodeSize) {
		if(rc = write_device()) {
			terminate(rc);
			return rc;
		}
	}else{
		rc = RC_SYNTAX;
		output_usage();
		terminate(rc);
		return rc;
	}

}
