/**************************************************************
*                IIC-EEPROM driver header
*
* (converted LABO Gataro's "Mini LCD Driver with IIC V0.1")
*
*                                    (C)neko Java 2012.10.10
***************************************************************/
//
//--------------------------------------------------
//    �@��ˑ��̒�`�i���������ύX����΂悢�j
//
#define  USE_TWI	0		// �W��IIC(TWI�j���g��=1   GPIO�̂Ƃ� =0
//
//
#define SYSCLK  16000000UL	// CPU clock 16Mhz

#define iicROM_DPORT PORTG	//IIC�|�[�g�iTWI���g���Ƃ��͐ݒ�s�v�j
#define iicROM_DPIN  PING
#define iicROM_DDDR  DDRG
#define iicROM_SDA   PG3	// Data
#define iicROM_SCL   PG4	// Clock

//-----------------------�����܂�----------------------------
//    IIC�f�B�o�C�X�A�h���X
#define  iicROM_ADR      0xA0	//24C256 fix
//    �҂����Ԑݒ�p
#define TEN_US    400000UL     // 4�T�C�N���̃��[�v��10��s�����
#define LOOPCNT   (SYSCLK / TEN_US) // ���[�v�J�E���g

#define err_NODEV    1        // rc=1 no device
#define err_COMD     2        // rc=2 command error 
#define err_DATA     3        // rc=3 data write error

//**********************************************************
//  AVR Built-in IIC(TWI) Macros 
//**********************************************************
#include <util/twi.h>      // 01/2008 TWI�̃t���O��`
// TWI �}�N��
#define SET_TWCR(x) {TWCR=(x)|(1<<TWINT)|(1<<TWEN);} while(0)
#define TWI_START   SET_TWCR(1<<TWSTA)
#define TWI_ACK     SET_TWCR(1<<TWEA)
#define TWI_NACK    SET_TWCR(0)
#define TWI_NEXT    SET_TWCR(0)
#define TWI_STOP    SET_TWCR(1<<TWSTO)
#define TWI_END     SET_TWCR(0)
#define WAIT_TWINT  loop_until_bit_is_set(TWCR,TWINT)

#define TWI_CLK   400000
#define  TW_BOUD  12	// ((SYSCLK/TWI_CLK - 16)/2)   400kHz

//--------------------GPIO IIC header file-----------------------------------------
//  append PORT drive (the original was DDR access only)
#define SCL_LOW() iicROM_DDDR |= (1<<iicROM_SCL)
#define SCL_HIGH() iicROM_DDDR &=  ~(1<<iicROM_SCL)				/* SCL = High-Z */
#define	SCL_VAL		((iicROM_DPIN & (1<<iicROM_SCL)) ? 1 : 0)	/* SCL input level */
#define SDA_LOW()  iicROM_DDDR |= (1<<iicROM_SDA)
#define SDA_HIGH()	iicROM_DDDR &= ~(1<<iicROM_SDA)				/* SDA = High-Z */
#define	SDA_VAL		((iicROM_DPIN & (1<<iicROM_SDA)) ? 1 : 0)	/* SDA input level */
typedef enum { IIC_ACK = 0, IIC_NACK } BOOL;
#define	IIC_WRITE	0
#define	IIC_READ	1

//--------------------Declear Proto Type of functions------------------------------
//�֐��v���g�^�C�v
void iicROM_init(void);
uint8_t iicROM_page_write(uint16_t adr, uint8_t *data);
uint8_t iicROM_read_start(uint8_t adr_h, uint8_t adr_l);
uint8_t iicROM_read(uint8_t *data);
uint8_t iicROM_read_end(uint8_t *data);

//---------------------------------End of header-----------------------------------
