/*----------------------------------------------------------------------*/
/* PC program download module                              2012.10.31   */
/*                                                                      */
/*    PC <--> I2C EEPROM(24LC256)  (r/w)                                */
/*                                                      (C)neko Java    */
/*----------------------------------------------------------------------*/
#include <avr/io.h>
#include <inttypes.h>

#include "uart.h"
#include "iicrom.h"

/* Program error codes */
#define	RC_FAIL		1
#define	RC_FILE		2
#define	RC_INIT		3
#define RC_DEV		4
#define	RC_SYNTAX	5

/* Command */
#define	CM_READ		1
#define	CM_VERIFY	2
#define	CM_WRITE	3

#define	REP_TIME	0xFFFFFFFF

static uint8_t	Com;
static uint8_t	H_byte, L_byte;

extern void nop_wait(uint16_t count);


uint8_t receive_byte_chk(uint8_t *data)	// AVR <- PC with check
{
	unsigned long i=0;
	while(uart_test()==0){
		i++;
		if(i==REP_TIME) return RC_FAIL;
	}
	*data=uart_get();
	uart_put(*data);
	return 0;
}

uint8_t receive_byte(uint8_t *data)	// AVR <- PC
{
	unsigned long i=0;
	while(uart_test()==0){
		i++;
		if(i==REP_TIME) return RC_FAIL;
	}
	*data=uart_get();
	return 0;
}

uint8_t send_byte(uint8_t data)	// AVR -> PC
{
	uart_put(data);
	return 0;
}

uint8_t get_com()
{
	if(receive_byte_chk(&Com)) return RC_FAIL;
	if(receive_byte_chk(&H_byte)) return RC_FAIL;
	if(receive_byte_chk(&L_byte)) return RC_FAIL;
	return 0;
}

uint8_t read_device(uint16_t code_size)
{
	uint8_t data;
	uint16_t adr;
	
	if(iicROM_read_start(0, 0)) return RC_FAIL;
	for(adr=0x0000; adr<(code_size-1); adr++){
		if(iicROM_read(&data)) return RC_FAIL;
		if(send_byte(data)) return RC_FAIL;
	}
	if(iicROM_read_end(&data)) return RC_FAIL;
	if(send_byte(data)) return RC_FAIL;
	return 0;
}

uint8_t write_device(uint16_t code_size)
{
	uint8_t buff[64], i=0, d=0;
	uint16_t adr;

	for(adr=0; adr<code_size; adr++){
		if(receive_byte(&buff[i])) return RC_FAIL;
		i++;
		if(i==64){
			if(iicROM_page_write(adr-63, buff)) return RC_FAIL;
			i=0;
			if(send_byte(d)) return RC_FAIL;	//dummy
		}
	}
	if(i!=0){
		if(iicROM_page_write(adr-i, buff)) return RC_FAIL;
		if(send_byte(d)) return RC_FAIL;	//dummy
	}
	return 0;
}

//-----------------------------------------------------------------------------------------
//    Public Functions 
//-----------------------------------------------------------------------------------------
void pc_write_sub()
{
	uint16_t code_size;
	
	if(uart_test()==0) return;
	
	if(get_com()) return;
	code_size = ((uint16_t)H_byte << 8) + (uint16_t)L_byte;
	
	switch (Com){
		case CM_READ:
			if(read_device(0x8000)) return;
			break;
		case CM_VERIFY:
			if(read_device(code_size)) return;
			break;
		case CM_WRITE:
			if(write_device(code_size)) return;
			if(read_device(code_size)) return;
	}
}
