/*----------------------------------------------------------------------*/
/* base board for Z80 CPU                                  2012.10.4    */
/*                                         definitions                  */
/*                                                      (c)neko Java    */
/*----------------------------------------------------------------------*/
/*                                             CTS���͒ǉ� 2013.1.29    */
/*----------------------------------------------------------------------*/

#include <avr/io.h>

/* pin assignment ------------------------- */
#define P_RESET		PE3
//#define P_WAIT		PE4
#define P_NMI		PG2
#define P_BUSRQ		PE2
#define P_WR		PE6
#define P_RD		PE5
#define P_MREQ		PE7
#define P_BUSAK		PB5
#define P_IOREQ		PB4
#define P_PCWR		PB7
#define P_CTS		PG0
#define P_HALT		PG1

/* pin output ----------------------------------------------- */
#define RESET_H()	DDRE &= ~_BV(P_RESET); PORTE |= _BV(P_RESET)
#define RESET_L()	PORTE &= ~_BV(P_RESET); DDRE |= _BV(P_RESET)
//#define WAIT_H()	PORTE |=  _BV(P_WAIT)
//#define WAIT_L()	PORTE &= ~_BV(P_WAIT)
#define NMI_H()		PORTG |=  _BV(P_NMI)
#define NMI_L()		PORTG &= ~_BV(P_NMI)
#define BUSRQ_H()	DDRE &= ~_BV(P_BUSRQ); PORTE |= _BV(P_BUSRQ)
#define BUSRQ_L()	PORTE &= ~_BV(P_BUSRQ); DDRE |= _BV(P_BUSRQ)
#define WR_H()		PORTE |=  _BV(P_WR)
#define WR_L()		PORTE &= ~_BV(P_WR)
#define RD_H()		PORTE |=  _BV(P_RD)
#define RD_L()		PORTE &= ~_BV(P_RD)
#define MREQ_L()	PORTE &= ~_BV(P_MREQ); DDRE |= _BV(P_MREQ)

/* pin input ------------------------------------------------ */
#define WR()		(PINE & _BV(P_WR))
#define RD()		(PINE & _BV(P_RD))
#define BUSAK()		(PINB & _BV(P_BUSAK))
#define IOREQ()		(PINB & _BV(P_IOREQ))
#define PCWR()		(PINB & _BV(P_PCWR))
#define CTS()		(PING & _BV(P_CTS))
#define HALT()		(PING & _BV(P_HALT))

/* pin direction control ------------------------------------------------------------ */
#define RW_IN()		PORTE |= _BV(P_WR) | _BV(P_RD); DDRE &= ~(_BV(P_WR) | _BV(P_RD))
#define RW_OUT()	PORTE |= _BV(P_WR) | _BV(P_RD); DDRE |= _BV(P_WR) | _BV(P_RD)
#define D_BUS_IN()	DDRC = 0; PORTC = 0xFF
#define D_BUS_OUT()	DDRC = 0xFF
#define AD_BUS_IN()	DDRA = 0; PORTA = 0xFF; DDRF = 0; PORTF = 0xFF
#define AD_BUS_OUT()	DDRA = 0xFF; DDRF = 0xFF
#define MREQ_Z()		DDRE &= ~_BV(P_MREQ); PORTE |= _BV(P_MREQ)

/* DMA mode and result ---------------------------------------- */
#define DMA_NONE	0
#define DMA_READ	1
#define DMA_WRITE	2
#define DMA_WRITE_BACK	3
#define DMA_WRITE_ROM	4
#define DMA_OK		0
#define DMA_NG		1

/* DMA command assignment [AVR side]-------------------------------------------------- */
#define CON_STS		0x80	//[O] Returns 0xFF if the UART has a byte, 0 otherwise.
#define CON_IN		0x81	//[O]
#define CON_OUT		0x82	//[I]
#define TRACK_SEL_L	0xA0	//[I]
#define TRACK_SEL_H	0xA1	//[I]
#define SECTOR_SEL	0xA2	//[I]
#define ADR_L		0xA4	//[I]
#define ADR_H		0xA5	//[I]
#define EXEC_DMA	0xA6	//[I] command 1:read, 2:write.
#define DMA_RS		0xA7	//[O] 0:OK, 1:NG.
#define ROM_SAVE	0xA8	//[I]

#define COM_ADR		0xFFFE
#define VAL_ADR		0xFFFF

/* Disk parameters ------------------------------------------------------------------- */
#define SDC_CLST_SIZE	512		// fixed for SDC.
#define SECT_SIZE		128		// fixed for CP/M.
#define SECT_CNT		64		// CP/M sector size.
#define BLOCK_SIZE		2048	// CP/M block size.
#define CPM_CLST_CNT_PER_BLOCK	(BLOCK_SIZE/SECT_SIZE)
#define SDC_CLST_CNT_PER_BLOCK	(BLOCK_SIZE/SDC_CLST_SIZE)

#define EEPROM_SIZE	2048
