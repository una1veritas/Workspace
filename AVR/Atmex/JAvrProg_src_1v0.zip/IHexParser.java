/*
JAvrProg
An AVR programmer that uses the AVR-PROG protocol + some speeded up xfers
(used most commonly in bootloaders!)
For more info go to: http://www.media.mit.edu/~ladyada/techproj/Atmex

Copyright (C) 2004

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

*/

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class IHexParser {

    public static byte[] readIHexFile(File f) throws IOException {
	char c;
	int recordLen, recordAddr, recordType, recordCksum;
	byte checksum = 0;
	byte b;
	byte[] buffer = new byte[2048];
	char[] minibuff = new char[256];
	String str;
	int segmentAddr = 0;

	Arrays.fill(buffer, (byte)0xFF);
	//make file into inputstream
	FileReader fr = new FileReader(f);

	// read one line at a time
	// eat whitespacebefore and after records
	while (true) {
	    do {
		c = (char)fr.read();
	    } while (Character.isWhitespace(c));

	    if (c != ':') 
		throw new IOException("Expected : got "+c);

	    checksum = 0;
	    str = (char)fr.read()+""+(char)fr.read(); 
	    recordLen = Integer.parseInt(str, 16);
	    checksum += recordLen;
	    
	    str = (char)fr.read()+""+(char)fr.read(); 
	    checksum += Integer.parseInt(str, 16);
	    str += (char)fr.read()+""+(char)fr.read(); 
	    recordAddr = Integer.parseInt(str, 16) + segmentAddr*16;
	    checksum += recordAddr & 0xff;
	    
	    str = (char)fr.read()+""+(char)fr.read(); 
	    recordType = Integer.parseInt(str, 16);
	    checksum += recordType;
	    
	    switch (recordType) {
	    case 0x00:
		fr.read(minibuff, 0, recordLen*2);
		for (int i=0; i<recordLen*2; i+=2) {
		    str = minibuff[i] +""+ minibuff[i+1];
		    int j = Integer.parseInt(str, 16);
		    b = (byte)j;
		    buffer[recordAddr + i/2] = b;
		    checksum += b;
		}
		str = (char)fr.read() +""+ (char)fr.read(); 
		recordCksum = Integer.parseInt(str, 16);
		if ((checksum + recordCksum) % 256 != 0) {
		    throw new IOException("checksum = "+checksum+
					  " vs "+recordCksum);
		}
		break;
	    case 0x01:
		return buffer;
	    case 0x02:
		// read the next two bytes, thats the new segment addr
		fr.read(minibuff, 0, recordLen*2);
		segmentAddr = 0;
		for (int i=0; i<recordLen*2; i+=2) {
		    str = minibuff[i] +""+ minibuff[i+1];
		    segmentAddr <<= 8;
		    int j = Integer.parseInt(str, 16);
		    segmentAddr |= j;
		    checksum += j;
		}

		str = (char)fr.read() +""+ (char)fr.read(); 
		recordCksum = Integer.parseInt(str, 16);
		if ((checksum + recordCksum) % 256 != 0) {
		    throw new IOException("checksum = "+checksum+
				       " vs "+recordCksum);
		}
		break;
	    default:
		System.out.println("unknown type "+recordType);
	    }
	}
    }
}
