/*
 * @(#)SerialConnection.java	1.10 00/05/04 SMI
 * 
 * Copyright 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 * 
 * Sun grants you ("Licensee") a non-exclusive, royalty free, license
 * to use, modify and redistribute this software in source and binary
 * code form, provided that i) this copyright notice and license appear
 * on all copies of the software; and ii) Licensee does not utilize the
 * software in a manner which is disparaging to Sun.
 * 
 * This software is provided "AS IS," without a warranty of any kind.
 * ALL EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES,
 * INCLUDING ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED. SUN AND
 * ITS LICENSORS SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY
 * LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THE
 * SOFTWARE OR ITS DERIVATIVES. IN NO EVENT WILL SUN OR ITS LICENSORS
 * BE LIABLE FOR ANY LOST REVENUE, PROFIT OR DATA, OR FOR DIRECT,
 * INDIRECT, SPECIAL, CONSEQUENTIAL, INCIDENTAL OR PUNITIVE DAMAGES,
 * HOWEVER CAUSED AND REGARDLESS OF THE THEORY OF LIABILITY, ARISING
 * OUT OF THE USE OF OR INABILITY TO USE SOFTWARE, EVEN IF SUN HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * 
 * This software is not designed or intended for use in on-line control
 * of aircraft, air traffic, aircraft navigation or aircraft
 * communications; or in the design, construction, operation or
 * maintenance of any nuclear facility. Licensee represents and
 * warrants that it will not use or redistribute the Software for such
 * purposes.
 */
import javax.comm.*;
import java.io.*;
import java.awt.event.*;
import java.util.TooManyListenersException;

/**
 * A class that handles the details of a serial connection. Reads from one
 * TextArea and writes to a second TextArea.
 * Holds the state of the connection.
 */
public class SerialConnection implements //SerialPortEventListener, 
					 CommPortOwnershipListener {
    private String   PortName;
    private int      PortBaudRate;
    private int      PortFlowControl, PortDataBits, PortStopBits, PortParity;

    private OutputStream       os;
    private InputStream	       is;
    private CommPortIdentifier portId;
    private SerialPort	       sPort;
    private boolean	       open;

    /**
     * Creates a SerialConnection object and initilizes variables passed in
     * as params.
     * @param parent A MintyComm object.
     * @param parameters A SerialParameters object.
     * @param messageAreaOut The TextArea that messages that are to be sent out
     * of the serial port are entered into.
     * @param messageAreaIn The TextArea that messages comming into the serial
     * port are displayed on.
     */
    public SerialConnection(String name, int speed, int flow, int data, int stop, int parity) {
	PortName = name;
	PortBaudRate = speed;
	PortFlowControl = flow;
	PortDataBits = data;
	PortStopBits = stop;
	PortParity = parity;
	open = false;
    }

    /**
     * Attempts to open a serial connection and streams using the parameters
     * in the SerialParameters object. If it is unsuccesfull at any step it
     * returns the port to a closed state, throws a
     * <code>SerialConnectionException</code>, and returns.
     * Gives a timeout of 30 seconds on the portOpen to allow other applications
     * to reliquish the port if have it open and no longer need it.
     */
    public void openConnection() throws SerialConnectionException {

	// Obtain a CommPortIdentifier object for the port you want to open.
	try {
	    portId = 
		CommPortIdentifier.getPortIdentifier(PortName);
	} catch (NoSuchPortException e) {
	    throw new SerialConnectionException(e.getMessage());
	} 

	// Open the port represented by the CommPortIdentifier object. Give
	// the open call a relatively long timeout of 30 seconds to allow
	// a different application to reliquish the port if the user
	// wants to.
	try {
	    sPort = (SerialPort) portId.open("JAvrProg", 1000);
	} catch (PortInUseException e) {
	    throw new SerialConnectionException(e.getMessage());
	} 

	// Set the parameters of the connection. If they won't set, close the
	// port before throwing an exception.
	try {
	    setConnectionParameters();
	} catch (SerialConnectionException e) {
	    sPort.close();
	    
	    throw e;
	} 

	// Open the input and output streams for the connection. If they won't
	// open, close the port before throwing an exception.
	try {
	    os = sPort.getOutputStream();
	    is = sPort.getInputStream();
	} catch (IOException e) {
	    sPort.close();

	    throw new SerialConnectionException("Error opening i/o streams");
	} 
	/*
	// Add this object as an event listener for the serial port.
	try {
	    sPort.addEventListener(this);
	} catch (TooManyListenersException e) {
	    sPort.close();

	    throw new SerialConnectionException("too many listeners added");
	} 
	
	// Set notifyOnDataAvailable to true to allow event driven input.
	sPort.notifyOnDataAvailable(true);
	
	// Set notifyOnBreakInterrup to allow event driven break handling.
	sPort.notifyOnBreakInterrupt(true);
	*/

	// Set receive timeout to allow breaking out of polling loop during
	// input handling.
	try {
	    sPort.enableReceiveTimeout(3);
	} catch (UnsupportedCommOperationException e) {}

	// Add ownership listener to allow ownership event handling.
	portId.addPortOwnershipListener(this);

	open = true;
	
    } 

    /**
     * Sets the connection parameters to the setting in the parameters object.
     * If set fails return the parameters object to origional settings and
     * throw exception.
     */
    public void setConnectionParameters() throws SerialConnectionException {

	// Set connection parameters, if set fails return parameters object
	// to origioriginalnal state.
	try {
	    sPort.setSerialPortParams(PortBaudRate, 
				      PortDataBits, 
				      PortStopBits, 
				      PortParity);
	} catch (UnsupportedCommOperationException e) {
	    throw new SerialConnectionException("Unsupported parameter");
	} 

	// Set flow control.
	try {
	    sPort.setFlowControlMode(PortFlowControl);
	} catch (UnsupportedCommOperationException e) {
	    throw new SerialConnectionException("Unsupported flow control");
	} 
    } 

    /**
     * Close the port and clean up associated elements.
     */
    public void closeConnection() {

	// If port is alread closed just return.
	if (!open) {
	    return;
	} 


	// Check to make sure sPort has reference to avoid a NPE.
	if (sPort != null) {
	    try {

		// close the i/o streams.
		os.close();
		is.close();
	    } catch (IOException e) {
		System.err.println(e);
	    } 

	    // Close the port.
	    sPort.close();

	    // Remove the ownership listener.
	    portId.removePortOwnershipListener(this);
	} 

	open = false;
    } 

    /**
     * Send a one second break signal.
     */
    public void sendBreak() {
	sPort.sendBreak(1000);
    } 

    /**
     * Reports the open status of the port.
     * @return true if port is open, false if port is closed.
     */
    public boolean isOpen() {
	return open;
    } 

    /**
     * Handles SerialPortEvents. The two types of SerialPortEvents that this
     * program is registered to listen for are DATA_AVAILABLE and BI. During
     * DATA_AVAILABLE the port buffer is read until it is drained, when no more
     * data is availble and 30ms has passed the method returns. When a BI
     * event occurs the words BREAK RECEIVED are written to the messageAreaIn.
     */
    public int byteswaiting() {
	int i=0;

	try {
	    i =  is.available();
	} catch (IOException e) {
	    System.err.println("InputStream read error: " + e);
	} 
	return i;
    }


    public byte readbyte(int timeout_ms) throws IOException {
	int data;
	
	try {
	    sPort.enableReceiveTimeout(timeout_ms);
	    if (sPort.isReceiveTimeoutEnabled()) {
		data = is.read();
		if (data == -1)
		    throw new IOException("No data");
		return (byte)data;
	    }
	} catch (UnsupportedCommOperationException e) {
	    // oh well, do it the hard way :(
	}
 
	while (byteswaiting() == 0) {
	    try { Thread.sleep(10);} catch (InterruptedException ex) {}
	    timeout_ms -= 10;
	    if (timeout_ms <= 0) {
		throw new IOException("No data");
	    }
	}
	data = is.read();
	if (data == -1)
	    throw new IOException("No data");
	return (byte)data;
    }

    public byte[] readbytes(int timeout_ms) throws IOException{
	int i=0;
	byte[] data = new byte[1024];

	try {
	    sPort.enableReceiveTimeout(timeout_ms);
	    if (sPort.isReceiveTimeoutEnabled()) {
		// ok we can use the timeout system
		i = is.read(data);
		if (i == -1)
		    throw new IOException("No data");
		byte[] totaldata = new byte[i];
		System.arraycopy(data, 0, totaldata, 0, i);
		return totaldata;
	    }
	} catch (UnsupportedCommOperationException e) {
	    // oh well, do it the hard way :(
	    throw new IOException("eek");
	}
 
	data = new byte[1024];	    
	while (true) {
	    while (byteswaiting() == 0) {
		try { Thread.sleep(10);} catch (InterruptedException ex) {}
		timeout_ms -= 10;
		if (timeout_ms <= 0) {
		    if (i <= 0) 
			throw new IOException("No data");
		    byte[] totaldata = new byte[i];
		    System.arraycopy(data, 0, totaldata, 0, i);
		    return totaldata;
		}
	    }
	    int j;
	    while ((j = is.read()) != -1) {
		data[i++] = (byte)j;
	    }
	    if (i == 1024)
		return data;
	}
    }

    public byte[] readbytes(int bytes, int timeout_ms) throws IOException {
	int numread;
	byte[] data = new byte[bytes];

	try {
	    sPort.enableReceiveTimeout(timeout_ms);
	    if (sPort.isReceiveTimeoutEnabled()) {
		// ok we can use the timeout system
		numread = is.read(data);
		if ((numread == -1) || (numread != bytes))
		    throw new IOException("No data");
		return data;
	    }
	} catch (UnsupportedCommOperationException e) {
	    // oh well, do it the hard way :(
	}

	
	for (int i=0; i < bytes; i++) {
	    while (byteswaiting() == 0) {
		try { Thread.sleep(10);} catch (InterruptedException ex) {}
		timeout_ms -= 10;
		if (timeout_ms <= 0) {
		    throw new IOException("Timed out");
		}
	    }
	    try {
		int j;
		while ((j = (byte)is.read()) != -1) {
		    data[i] = (byte)j;
		}
	    } catch (IOException e) {
		System.err.println("InputStream read error: " + e);
	    }
	}
	return data;
    }

    public String readstring(int timeout_ms) throws IOException {
	
	while (byteswaiting() == 0) {
	    try { Thread.sleep(10);} catch (InterruptedException ex) {}
	    timeout_ms -= 10;
	    if (timeout_ms <= 0) {
		throw new IOException("Timed out");
	    }
	}

	StringBuffer r = new StringBuffer("");
	try {
	    int i;
	    while ((i = is.read()) != -1) {
		r.append((char)i);
	    }
	} catch (IOException e) {
	    System.err.println("InputStream read error: " + e);
	}
	return r.toString();
    }

    public void send(String s) {
	try {
	    os.write(s.getBytes());
	} catch (IOException e) {
	    System.err.println("OutputStream write error: " + e);
	}
    }
    public void send(byte[] buff, int size) {
	try {
	    os.write(buff, 0, size);
	} catch (IOException e) {
	    System.err.println("OutputStream write error: " + e);
	}
    }

    public void send(char buff) {
	try {
	    os.write(buff);
	} catch (IOException e) {
	    System.err.println("OutputStream write error: " + e);
	}
    }
   public void send(byte buff) {
	try {
	    os.write(buff);
	} catch (IOException e) {
	    System.err.println("OutputStream write error: " + e);
	}
    }
    /**
     * Handles ownership events. If a PORT_OWNERSHIP_REQUESTED event is
     * received a dialog box is created asking the user if they are
     * willing to give up the port. No action is taken on other types
     * of ownership events.
     */
    public void ownershipChange(int type) {
    } 
}




