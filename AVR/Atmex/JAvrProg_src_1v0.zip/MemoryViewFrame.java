/*
JAvrProg
An AVR programmer that uses the AVR-PROG protocol + some speeded up xfers
(used most commonly in bootloaders!)
For more info go to: http://www.media.mit.edu/~ladyada/techproj/Atmex

Copyright (C) 2004

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

*/

import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.BorderFactory; 
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

// text area to view memory
public class MemoryViewFrame extends JFrame {
    JTextArea textArea;

    public MemoryViewFrame() {
	
	textArea = new JTextArea();
        //textArea.setFont(new Font("Serif", Font.ITALIC, 16));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane areaScrollPane = new JScrollPane(textArea);
        areaScrollPane.setVerticalScrollBarPolicy(
                        JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        areaScrollPane.setPreferredSize(new Dimension(250, 250));
        areaScrollPane.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createCompoundBorder(
                                BorderFactory.createTitledBorder("Flash Memory"),
                                BorderFactory.createEmptyBorder(5,5,5,5)),
                areaScrollPane.getBorder()));
	getContentPane().add(areaScrollPane);
	setResizable(true);
	setVisible(false);
	repaint();
    }

    public MemoryViewFrame(byte[] buffer) {
		textArea = new JTextArea();
        //textArea.setFont(new Font("Serif", Font.ITALIC, 16));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        JScrollPane areaScrollPane = new JScrollPane(textArea);
        areaScrollPane.setVerticalScrollBarPolicy(
                        JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        areaScrollPane.setPreferredSize(new Dimension(250, 250));
        areaScrollPane.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createCompoundBorder(
                                BorderFactory.createTitledBorder("Flash Memory"),
                                BorderFactory.createEmptyBorder(5,5,5,5)),
                areaScrollPane.getBorder()));
	getContentPane().add(areaScrollPane);
	setResizable(true);
	setVisible(false);
	repaint();

	textArea.setText(convertBufferToString(buffer));
    }

    public void setText(byte[] buffer) {
	textArea.setText(convertBufferToString(buffer));
    }


    
    private static final char hexchars[] =
    {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F' };
    public static String convertBufferToString(byte[] buffer) {
	StringBuffer sb = new StringBuffer();
	byte b;

	for (int i=0; i< buffer.length; i++) {
	    b = buffer[i];
	    sb.append( hexchars[(b>>4) & 0xF] );
	    sb.append( hexchars[b & 0xF] );
	    sb.append(' ');
	}
	return sb.toString();
    }

}
