/*
JAvrProg
An AVR programmer that uses the AVR-PROG protocol + some speeded up xfers
(used most commonly in bootloaders!)
For more info go to: http://www.media.mit.edu/~ladyada/techproj/Atmex

Copyright (C) 2004

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

*/

public class DeviceDescriptor {
    private String name;
    private byte devid;
    private byte[] signature;
    private int flashsize, eepromsize;
    private int flashpagesize, eeprompagesize;

    public DeviceDescriptor(String n, byte id, byte sig1, byte sig2, byte sig3, 
		     int fs, int es, int fps, int eps) {
	name = n;
	devid = id;
	signature = new byte[3];
	signature[0] = sig1; signature[1] = sig2; signature[2] = sig3;
	flashsize = fs; eepromsize = es;
	flashpagesize = fps; eeprompagesize = eps;
    }

    public String getName() { return name; }
    public byte getDevID() {return devid; }
    public byte[] getSignature() { 
	byte[] sigclone = new byte[3];
	System.arraycopy(signature, 0, sigclone, 0, 3);
	return sigclone; }
    public int getFlashSize() { return flashsize; }
    public int getEEPROMSize() { return eepromsize; }
    public int getFlashPageSize() { return flashpagesize; }
    public int getEEPROMPageSize() { return eeprompagesize; }

    public String toString() { return name; }
}
