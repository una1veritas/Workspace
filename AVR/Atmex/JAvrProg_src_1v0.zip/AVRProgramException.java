public class AVRProgramException extends Exception {
    public AVRProgramException(String str) {
	super(str);
    }

    public AVRProgramException() {
	super();
    }

}
