/*
JAvrProg
An AVR programmer that uses the AVR-PROG protocol + some speeded up xfers
(used most commonly in bootloaders!)
For more info go to: http://www.media.mit.edu/~ladyada/techproj/Atmex

Copyright (C) 2004

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

*/

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Set;
import java.util.Arrays;
import javax.swing.UIManager;
import javax.swing.BorderFactory; 
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.filechooser.*;
import javax.swing.JProgressBar;
import javax.comm.*;

public class JAvrProg extends JFrame implements ActionListener{

    // panel window size
    final int HEIGHT = 365;
    final int WIDTH = 290;

    JPanel HexFilePanel;
    JLabel HexFileName;
    JButton HexFileBrowseButton, HexFileReloadButton;
    JFileChooser HexFileChooser;
    
    JPanel ProgressPanel;
    JProgressBar ProgressBar;
    JLabel ProgressLabel;

    JPanel FlashPanel;
    JButton FlashProgramButton, FlashVerifyButton, FlashReadButton;

    JPanel EEPROMPanel;
    JButton EEPROMProgramButton, EEPROMVerifyButton, EEPROMReadButton;

    JPanel DevicePanel;
    JComboBox DeviceChooser;

    JPanel AdvancedPanel;
    JButton AdvancedButton;

    MemoryViewFrame memview;

    SerialConnection serialconnection = null;
    String AVRBoardName;
    Hashtable DevicesByID = new Hashtable();
    Hashtable DevicesByName = new Hashtable();
    Vector SupportedDevices = new Vector();
    
    byte[] FlashBuffer, HexFileBuffer;
    byte[] EEPROMBuffer;

    public static void main(String[] args) {
	
	/* set the look and feel first, to make it look the best */
	try {
	    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	} catch (Exception e) {
	    System.out.println("failed to get look & feel:"+e.getMessage());
	}
	
	JAvrProg jap = new JAvrProg(args);
	jap.setResizable(false);
	jap.setVisible(true);
	jap.repaint();
    }

    public JAvrProg(String[] args) {
	super("JAvrProg");

	///////////////
	// Load all devices
	// (by hand for now) 
	DeviceDescriptor dev;
	dev = new DeviceDescriptor("ATtiny2313", (byte)0x23, 
				   (byte)0x1E, (byte)0x91, (byte)0x0A,
				   2048, 128, 32, 4);
	DevicesByID.put(new Byte(dev.getDevID()), dev);
	DevicesByName.put(dev.getName(), dev);
	SupportedDevices.add(dev);
	///////////////


	JPanel MainPanel = new JPanel();
	GridBagLayout gridbag = new GridBagLayout();
	MainPanel.setLayout(gridbag);
	GridBagConstraints gridbag_c = new GridBagConstraints();
	gridbag_c.fill = GridBagConstraints.HORIZONTAL;

	HexFilePanel = new JPanel();
	HexFilePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Hex File"));
	HexFilePanel.setLayout(new GridLayout(2,1, 10, 10));

	HexFileName = new JLabel("");
	HexFileName.setBorder(BorderFactory.createLoweredBevelBorder());
	JPanel HexFileButtonPanel = new JPanel();
	HexFileButtonPanel.setLayout(new GridLayout(1, 3, 10, 30));
	HexFileBrowseButton = new JButton("Browse...");
	HexFileBrowseButton.setEnabled(true);
	HexFileBrowseButton.setMnemonic(KeyEvent.VK_B); 
	HexFileBrowseButton.setBorder(BorderFactory.createRaisedBevelBorder());
	HexFileBrowseButton.setPreferredSize(new Dimension(10,25));
	HexFileBrowseButton.addActionListener(this);
	HexFileReloadButton = new JButton("Reload");
	HexFileReloadButton.setEnabled(false);
	HexFileReloadButton.setMnemonic(KeyEvent.VK_L); 
	HexFileReloadButton.setBorder(BorderFactory.createRaisedBevelBorder());
	HexFileReloadButton.setPreferredSize(new Dimension(10,25));
	HexFileReloadButton.addActionListener(this);

	HexFileChooser = new JFileChooser("Open");
	HexFileChooser.addChoosableFileFilter(new FileFilter() {
		public boolean accept(File f) {
		    if (f.isDirectory()) {
			return true;
		    }
		    
		    // extract the extension
		    String ext = null;
		    String s = f.getName();
		    int i = s.lastIndexOf('.');
		    if (i > 0 &&  i < s.length() - 1) {
			ext = s.substring(i+1).toLowerCase();
			return ext.toUpperCase().equals("HEX");
		    } else {
			return false;
		    }
		}    
		public String getDescription() {
		    return "Hex files (*.hex)";
		}

	    });

	HexFileButtonPanel.add(HexFileBrowseButton);
	HexFileButtonPanel.add(HexFileReloadButton);
	HexFileButtonPanel.add(new JLabel(""));
	HexFilePanel.add(HexFileName);
	HexFilePanel.add(HexFileButtonPanel);
	
	gridbag_c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag_c.anchor = GridBagConstraints.FIRST_LINE_START;
	gridbag_c.weighty = 0;
	gridbag_c.weightx = 0;
	MainPanel.add(HexFilePanel, gridbag_c);

	ProgressPanel = new JPanel();
	ProgressPanel.setLayout(new GridLayout(2, 1, 10, 10));
	ProgressLabel = new JLabel("");
	ProgressBar = new JProgressBar();
	ProgressBar.setBorder(BorderFactory.createLoweredBevelBorder());
	ProgressBar.setIndeterminate(false);
	ProgressBar.setMinimum(0);
	ProgressBar.setMaximum(100);
	ProgressBar.setStringPainted(true);
	ProgressBar.setValue(0);
	ProgressBar.setString("");
	ProgressPanel.add(ProgressLabel);
	ProgressPanel.add(ProgressBar);

	gridbag_c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag_c.anchor = GridBagConstraints.LINE_START;
	gridbag_c.weighty = 0;
	gridbag_c.weightx = 0;
	MainPanel.add(ProgressPanel, gridbag_c);

	FlashPanel = new JPanel();
	FlashPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Flash"));
	FlashPanel.setLayout(new GridLayout(1, 3, 10, 10));

	FlashProgramButton = new JButton("Program");
	FlashProgramButton.setMnemonic(KeyEvent.VK_P); 
	FlashProgramButton.setBorder(BorderFactory.createRaisedBevelBorder());
	FlashProgramButton.addActionListener(this);
	FlashPanel.add(FlashProgramButton);
	FlashVerifyButton = new JButton("Verify");
	FlashVerifyButton.setMnemonic(KeyEvent.VK_V); 
	FlashVerifyButton.setBorder(BorderFactory.createRaisedBevelBorder());
	FlashVerifyButton.addActionListener(this);
	FlashPanel.add(FlashVerifyButton);
	FlashReadButton = new JButton("Read");
	FlashReadButton.addActionListener(this);
	FlashReadButton.setMnemonic(KeyEvent.VK_R); 
	FlashReadButton.setBorder(BorderFactory.createRaisedBevelBorder());
	FlashPanel.add(FlashReadButton);


	gridbag_c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag_c.anchor = GridBagConstraints.LINE_START;
	gridbag_c.weighty = 1.0;
	gridbag_c.weightx = 1.0;	
  	MainPanel.add(FlashPanel, gridbag_c);

	EEPROMPanel = new JPanel();
	EEPROMPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "EEPROM"));
	EEPROMPanel.setLayout(new GridLayout(1, 3, 10, 10));

	EEPROMProgramButton = new JButton("Program");
	EEPROMProgramButton.setMnemonic(KeyEvent.VK_M); 
	EEPROMProgramButton.setBorder(BorderFactory.createRaisedBevelBorder());
	EEPROMProgramButton.addActionListener(this);
	EEPROMPanel.add(EEPROMProgramButton);
	EEPROMVerifyButton = new JButton("Verify");
	EEPROMVerifyButton.setMnemonic(KeyEvent.VK_E); 
	EEPROMVerifyButton.setBorder(BorderFactory.createRaisedBevelBorder());
	EEPROMVerifyButton.addActionListener(this);
	EEPROMPanel.add(EEPROMVerifyButton);
	EEPROMReadButton = new JButton("Read");
	EEPROMReadButton.addActionListener(this);
	EEPROMReadButton.setMnemonic(KeyEvent.VK_D); 
	EEPROMReadButton.setBorder(BorderFactory.createRaisedBevelBorder());
	EEPROMPanel.add(EEPROMReadButton);

	gridbag_c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag_c.anchor = GridBagConstraints.LINE_START;
	gridbag_c.weighty = 1.0;
	gridbag_c.weightx = 1.0;
	MainPanel.add(EEPROMPanel, gridbag_c);
	
	DevicePanel = new JPanel();
	DevicePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), "Device"));
	DeviceChooser = new JComboBox(SupportedDevices);
	DeviceChooser.addActionListener(this);
	DevicePanel.add(DeviceChooser);

	gridbag_c.gridwidth = GridBagConstraints.REMAINDER;
	gridbag_c.anchor = GridBagConstraints.PAGE_END;
	gridbag_c.weighty = 1.0;
	gridbag_c.weightx = 1.0;
	MainPanel.add(DevicePanel, gridbag_c);

	getContentPane().add(MainPanel);
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(screenSize.width / 2 - WIDTH / 2, 
                    screenSize.height / 2 - HEIGHT / 2);
	setSize(WIDTH, HEIGHT);

	enableMainWindow();
	memview = new MemoryViewFrame(new byte[1]);
	memview.setSize(WIDTH, HEIGHT);
	
    }

    private void disableMainWindow() {
	HexFileBrowseButton.setEnabled(false);
	HexFileReloadButton.setEnabled(false);

	FlashProgramButton.setEnabled(false);
	FlashVerifyButton.setEnabled(false);
	FlashReadButton.setEnabled(false);

	EEPROMProgramButton.setEnabled(false);
	EEPROMVerifyButton.setEnabled(false);
	EEPROMReadButton.setEnabled(false);

	DeviceChooser.setEnabled(false);
    }

    private void enableMainWindow() {
	HexFileBrowseButton.setEnabled(true);
	HexFileReloadButton.setEnabled((HexFileName.getText() != ""));

	FlashProgramButton.setEnabled(true);
	FlashVerifyButton.setEnabled(true);
	FlashReadButton.setEnabled(true);

	// not supported right now
	EEPROMProgramButton.setEnabled(false);
	EEPROMVerifyButton.setEnabled(false);
	EEPROMReadButton.setEnabled(false);

	DeviceChooser.setEnabled(true);
    }

    private boolean connect() {
	// find an open COM port
	CommPortIdentifier portId;
	Enumeration en = CommPortIdentifier.getPortIdentifiers();

	byte[] recvdata;
	// iterate through the COM ports, to find a bootloader
	while (en.hasMoreElements()) {
	    portId = (CommPortIdentifier) en.nextElement();
	    if (portId.getPortType() != CommPortIdentifier.PORT_SERIAL)
		continue;
	    /*if ( findAVRBoard(portId.getName(), 115200) )
		break;
	    */
	    if ( findAVRBoard(portId.getName(), 19200) )
		break;
	}
	if ((serialconnection == null) || (! serialconnection.isOpen()) ) {
	    System.out.println("Failed to find AVR board");
	    return false;
	}
	return true;
    }

    private boolean findAVRBoard(String portname, int baudrate) {
	byte[] recvdata = null;
	try {
	    //System.out.println("trying to open port "+portname+" at "+baudrate+"bps");
	    serialconnection = 
		new SerialConnection(portname, baudrate, 
				     SerialPort.FLOWCONTROL_NONE, 
				     SerialPort.DATABITS_8,
				     SerialPort.STOPBITS_1, 
				     SerialPort.PARITY_NONE);
		serialconnection.openConnection();
	} catch (SerialConnectionException sce) {
	    //System.out.println("Couldn't open");
	    return false;
	}
	for (int i=0; i<3; i++) {
	    serialconnection.send((byte)0x1B);
	    serialconnection.send((byte)0x1B);
	    serialconnection.send((byte)0x1B);
	    serialconnection.send((byte)0x1B);
	    serialconnection.send((byte)'S');
	    try {
		recvdata = 
		    serialconnection.readbytes(250); // 250ms timeout
	    } catch (IOException ioe) {}
	    if (recvdata != null)
		break;
	}
	if (recvdata == null) {
	    //System.out.println("failed");
	    serialconnection.closeConnection();
	    return false;
	}
	if (recvdata.length != 7) {
	    serialconnection.closeConnection();
	    return false;
	}
	StringBuffer sb = new StringBuffer();
	for (int i=0; i< recvdata.length; i++) {
	    sb.append((char)recvdata[i]);
	}
	AVRBoardName = sb.toString();
	System.out.println("Found "+AVRBoardName);
	
	// get supported devices
	serialconnection.send((byte)'t');
	try {
	    recvdata = serialconnection.readbytes(100);
	} catch (IOException e) {
	    return false;
	}
	if (recvdata[recvdata.length - 1] != 0)
	    return false;
	
	/*
	  SupportedDevices = new Vector();
	  for (int i=0; i < recvdata.length - 1; i++) {
	  DeviceDescriptor d = (DeviceDescriptor)DevicesByID.get(new Byte(recvdata[i]));
	  if (d != null)
	  SupportedDevices.add(d);
	  }
	*/
	return true;
    }

    public void actionPerformed(ActionEvent evt) {
	if (evt.getSource() == HexFileBrowseButton) {
	    // show the browse window
	    
	    int returnVal = HexFileChooser.showOpenDialog(JAvrProg.this);

	    if (returnVal == JFileChooser.APPROVE_OPTION) {
		File file = HexFileChooser.getSelectedFile();
		HexFileName.setText(file.getAbsolutePath());
		HexFileReloadButton.setEnabled(true);
		try {
		    HexFileBuffer = IHexParser.readIHexFile(file);
		    memview.setText(HexFileBuffer);
		    memview.repaint();
		} catch (IOException ioe) {
		    System.out.println("Failed to read file: "+file+" "
				       +ioe.getMessage());
		}
	    } 
	}
	else if (evt.getSource() == HexFileReloadButton) {
	    File file = new File(HexFileName.getText());
	    try {
		HexFileBuffer = IHexParser.readIHexFile(file);
		memview.setText(HexFileBuffer);
		memview.repaint();
	    } catch (IOException ioe) {
		System.out.println("Failed to read file: "+file+" "+ioe.getMessage());
	    }
	}
	else if (evt.getSource() == FlashProgramButton) {
	    if (! connect()) {
		return;
	    }
	    
	    final SwingWorker worker = new SwingWorker() {
		    public Object construct() {
			DeviceDescriptor device;
			device = (DeviceDescriptor)DeviceChooser.getSelectedItem();

			disableMainWindow();
			FlashBuffer = new byte[HexFileBuffer.length];
			System.arraycopy(HexFileBuffer, 0, FlashBuffer, 0, HexFileBuffer.length);
			try {
			    // get the address for later
			    byte[] bootloadResetVector;
			    int bootloadAddr, usercodeAddr;
			    bootloadResetVector = 
				AVRProgram.readWord(0x0000, serialconnection);
			    bootloadAddr = bootloadResetVector[0];
			    if (bootloadAddr < 0) 
				bootloadAddr += 256;
			    bootloadAddr += 1 + (bootloadResetVector[1] & 0xF)*256;
			    bootloadAddr *= 2;
			    
			    ProgressLabel.setText("Erasing Device...");
			    AVRProgram.erase(device, serialconnection, ProgressBar);

			    ProgressLabel.setText(ProgressLabel.getText()+"Programming...");			    
			    // mess with the buffer! put the bootloader addr in place of
			    // the reset buffer
			    byte[] usercodeResetVector = new byte[2];
			    usercodeResetVector[0] = FlashBuffer[0];
			    usercodeResetVector[1] = FlashBuffer[1];
			    FlashBuffer[0] = bootloadResetVector[0];
			    FlashBuffer[1] = bootloadResetVector[1];
			    // Where is the usercode really?
			    usercodeAddr = usercodeResetVector[0];
			    if (usercodeAddr < 0) 
				usercodeAddr += 256;
			    usercodeAddr += 1 + (usercodeResetVector[1] & 0xF)*256;
			    usercodeAddr *= 2;
			    int jumpsize = ((usercodeAddr - bootloadAddr - 2)/2) + 1;
			    //System.out.println("jumpsize = 0x"+Integer.toString(usercodeAddr, 16));
			    usercodeResetVector[0] = (byte)(jumpsize & 0xFF);
			    usercodeResetVector[1] = (byte)(0xC0 | ((jumpsize >> 8) & 0xF));
			    FlashBuffer[bootloadAddr-2] = usercodeResetVector[0];
			    FlashBuffer[bootloadAddr-1] = usercodeResetVector[1];
			    
			    // Program the chip!
			    AVRProgram.programFlash(FlashBuffer, 0, bootloadAddr, device,
						    serialconnection, ProgressBar);
			    
			    // Verify!
			    ProgressLabel.setText(ProgressLabel.getText()+"Verifying...");
			    byte[] verifybuffer = AVRProgram.readFlash(device, 0, bootloadAddr,
						     serialconnection, ProgressBar);
			    byte[] verify2buffer = new byte[bootloadAddr];
			    System.arraycopy(FlashBuffer, 0, verify2buffer, 0, bootloadAddr);
			    
			    if (Arrays.equals(verify2buffer, verifybuffer)) {
				ProgressLabel.setText(ProgressLabel.getText()+"OK");
			    } else {
				ProgressLabel.setText(ProgressLabel.getText()+"Failed!");
			    }				
			} catch (IOException e) {
			    System.out.println("Failed: "+e.getMessage());
			    ProgressLabel.setText(ProgressLabel.getText()+"Failed!");
			} catch (AVRProgramException e) {
			    System.out.println("Failed: "+e.getMessage());
			    ProgressLabel.setText(ProgressLabel.getText()+"Failed!");
			}
			serialconnection.closeConnection();
			enableMainWindow();
			return new Integer(0);
		    }
		};
	    worker.start();
	}
	else if (evt.getSource() == FlashVerifyButton) {
	    if (! connect()) {
		return;
	    }

	    final SwingWorker worker = new SwingWorker() {
		    public Object construct() {
			DeviceDescriptor device
			    = (DeviceDescriptor)DeviceChooser.getSelectedItem();
			
			disableMainWindow();
			try {
			    ProgressLabel.setText("Reading Device...");
			    // get the bootcode addr
			    byte[] bootloadResetVector =
				AVRProgram.readWord(0x0000, serialconnection);
			    int bootloadAddr = bootloadResetVector[0];
			    if (bootloadAddr < 0) bootloadAddr += 256;
			    bootloadAddr += 1 + (bootloadResetVector[1] & 0xF)*256;
			    bootloadAddr *= 2;

			    FlashBuffer = 
				AVRProgram.readFlash((DeviceDescriptor)DeviceChooser.getSelectedItem(),
						     0, bootloadAddr,
						     serialconnection, ProgressBar);
			    // get the usercode addr
			    int jumpsize = FlashBuffer[bootloadAddr-2];
			    if (jumpsize < 0) 
				jumpsize += 256;
			    jumpsize += (FlashBuffer[bootloadAddr-1] & 0xF)*256;
			    if ((jumpsize & 0x800) != 0) 
				jumpsize -= 0x1000;
			    jumpsize *= 2;
			    int usercodeAddr = ((bootloadAddr + jumpsize)/2);

			    FlashBuffer[0] = (byte)((usercodeAddr-1) & 0xFF);
			    FlashBuffer[1] = (byte)(0xC0 | (((usercodeAddr-1) >> 8) & 0xF));
			    FlashBuffer[bootloadAddr-2] = (byte)0xFF;
			    FlashBuffer[bootloadAddr-1] = (byte)0xFF;

			    byte[] HexFileBuffer2 = new byte[bootloadAddr];
			    System.arraycopy(HexFileBuffer, 0, HexFileBuffer2, 0, bootloadAddr);
			    if (Arrays.equals(FlashBuffer, HexFileBuffer2))
				ProgressLabel.setText(ProgressLabel.getText()+"Verified");
			    else 
				ProgressLabel.setText(ProgressLabel.getText()+"Not Equiv.");

			} catch (IOException e) {
			    System.out.println("Failed: "+e.getMessage());
			    ProgressLabel.setText(ProgressLabel.getText()+"Failed!");
			} catch (AVRProgramException e) {
			    System.out.println("Failed: "+e.getMessage());
			    ProgressLabel.setText(ProgressLabel.getText()+"Failed!");
			}
			serialconnection.closeConnection();
			enableMainWindow();			return new Integer(0);
		    }
		};
		worker.start();
	}
	else if (evt.getSource() == FlashReadButton) {
	    if (! connect()) {
		return;
	    }

	    final SwingWorker worker = new SwingWorker() {
		    public Object construct() {
			DeviceDescriptor device;
			device = (DeviceDescriptor)DeviceChooser.getSelectedItem();
			
			disableMainWindow();
			try {
			    ProgressLabel.setText("Reading Device...");
			    // get the bootcode addr
			    byte[] bootloadResetVector =
				AVRProgram.readWord(0x0000, serialconnection);
			    int bootloadAddr = bootloadResetVector[0];
			    if (bootloadAddr < 0) 
				bootloadAddr += 256;
			    bootloadAddr += 1 + (bootloadResetVector[1] & 0xF)*256;
			    bootloadAddr *= 2;
			    //System.out.println("bootloader is at "+bootloadAddr);			    

			    HexFileBuffer = 
				AVRProgram.readFlash((DeviceDescriptor)DeviceChooser.getSelectedItem(),
						     0, bootloadAddr,
						     serialconnection, ProgressBar);
			    // get the usercode addr
			    int jumpsize = HexFileBuffer[bootloadAddr-2];
			    if (jumpsize < 0) 
				jumpsize += 256;
			    jumpsize += (HexFileBuffer[bootloadAddr-1] & 0xF)*256;
			    if ((jumpsize & 0x800) != 0) {
				jumpsize -= 0x1000;
			    }
			    jumpsize *= 2;
			    int usercodeAddr = ((bootloadAddr + jumpsize)/2);

			    HexFileBuffer[0] = (byte)((usercodeAddr-1) & 0xFF);
			    HexFileBuffer[1] = (byte)(0xC0 | (((usercodeAddr-1) >> 8) & 0xF));
			    HexFileBuffer[bootloadAddr-2] = (byte)0xFF;
			    HexFileBuffer[bootloadAddr-1] = (byte)0xFF;

			    ProgressLabel.setText(ProgressLabel.getText()+"OK");
			    memview.setText(HexFileBuffer);
			    memview.setVisible(true);
			} catch (IOException e) {
			    System.out.println("Failed: "+e.getMessage());
			    ProgressLabel.setText(ProgressLabel.getText()+"Failed!");
			} catch (AVRProgramException e) {
			    System.out.println("Failed: "+e.getMessage());
			    ProgressLabel.setText(ProgressLabel.getText()+"Failed!");
			}
			serialconnection.closeConnection();
			enableMainWindow();
			return new Integer(0);
		    }
		};
		worker.start();
		
	}
    }
}

