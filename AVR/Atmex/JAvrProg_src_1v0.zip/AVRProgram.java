/*
JAvrProg
An AVR programmer that uses the AVR-PROG protocol + some speeded up xfers
(used most commonly in bootloaders!)
For more info go to: http://www.media.mit.edu/~ladyada/techproj/Atmex

Copyright (C) 2004

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

*/

import javax.swing.JProgressBar;
import java.io.IOException;
import javax.comm.*;

public class AVRProgram {

    public static byte[] readWord(int address, SerialConnection serialconn) throws IOException {
	setAddress(serialconn, address);
	serialconn.send((byte)'R');
	try {
	    byte[] ret = serialconn.readbytes(2, 1000);
	    byte temp;
	    temp = ret[1];
	    ret[1] = ret[0];
	    ret[0] = temp;
	    return ret;
	} catch (IOException e) {
	    throw new IOException("bad response");
	}
    }


    public static void programFlash(byte[] buffer, int startaddr, int endaddr,
				    DeviceDescriptor device, 
				    SerialConnection serialconn, 
				    JProgressBar pb) throws IOException, AVRProgramException {

	int flashsize = device.getFlashSize();
	int flashpagesize = device.getFlashPageSize();
	byte b;
	byte[] bootloaderAddr, usercodeAddr = new byte[2];

	pb.setMaximum(flashsize);
	pb.setValue(0);
	pb.setString("0x0");

	if ((startaddr % flashpagesize != 0) || (endaddr % flashpagesize != 0)) {
	    return;
	}

	//System.out.println("Writing "+ (endaddr-startaddr) +" bytes of Flash to "+device.getName());
	setLED(serialconn);

	// try autoincrement?
	serialconn.send((byte)'a');
	b = serialconn.readbyte(100);
	if (b != (byte)'Y')
	    throw new AVRProgramException("bad response..want autoincrementing!"); 

	// enter programming mode
	serialconn.send((byte)'P');
	b = serialconn.readbyte(100);
	if (b != (byte)0x0D)
	    throw new AVRProgramException("bad response");
	
	setAddress(serialconn, startaddr);

	boolean fastmode = true; 
	byte[] flashpagebuffer = new byte[flashpagesize];

	for (int i = startaddr; i < endaddr; i += flashpagesize) {
	    pb.setValue(i);
	    pb.setString("0x"+Integer.toString(i, 16));

	    // read next page into buffer
	    System.arraycopy(buffer, i, flashpagebuffer, 0, flashpagesize);

	    // Check if this next page
	    // is all 0xFF and therefore blank, then skip it if it is
	    boolean blankpage = true;
	    for (int j=0; j<flashpagesize; j++) {
		if (flashpagebuffer[j] !=  (byte)0xFF) {
		    blankpage = false; 
		    break;
		}
	    }
	    if (blankpage) {
		//System.out.println("Skipping "+i);
		setAddress(serialconn, i+flashpagesize);
		continue;
	    }

	    // if fastmode, do it fast!
	    if (fastmode) {
		serialconn.send((byte)'Z');
		// if this is the first time, check to see if we got back a '?'
		if (i==startaddr) {
		    //System.out.println("Fast?");
		    byte ret = '!';
		    try {
			ret = serialconn.readbyte(100); 
		    } catch (IOException e) {
			// yay we didnt get a '?' back
		    }
		    if (ret == '?') {
			fastmode = false;
			// this is kinda icky, but basically, undo the incrementation & start over
			i -= flashpagesize;
			continue;
		    }
		    //System.out.println("Yay fast!");
		}
		serialconn.send(flashpagebuffer, flashpagesize);
		b = serialconn.readbyte(100);
		if (b != (byte)0x0D)
		    throw new IOException("bad response");
		continue;
	    } else {
		// ok slow mode, send one byte at a time :(
		try {
		    for (int j=0; j < flashpagesize; j+=2) {
			serialconn.send((byte)'c');
			serialconn.send(flashpagebuffer[j]);
			b = serialconn.readbyte(100);
			if (b != (byte)0x0D)
			    throw new IOException("bad response");
			serialconn.send((byte)'C');
			serialconn.send(flashpagebuffer[j+1]);
			b = serialconn.readbyte(100);
			if (b != (byte)0x0D)
			    throw new IOException("bad response");
		    }
		} catch (IOException e) {
		    // hmm, we didnt get a response, lets try again
		    System.out.println("No response, restarting from address "+i);
		    serialconn.send((byte)0x1B);
		    serialconn.send((byte)0x1B);
		    serialconn.send((byte)0x1B);
		    serialconn.send((byte)0x1B);
		    try {
			serialconn.readbytes(1000);
		    } catch (IOException e2) {}
		    setAddress(serialconn, i);
		    i -= flashpagesize; // (to undo the forloop increment)
		    continue;
		}
		
		
		// stupid autoincrement means we have to reset the address!
		setAddress(serialconn, i);
		serialconn.send((byte)'m');
		b = serialconn.readbyte(100);
		if (b != (byte)0x0D)
		    throw new IOException("bad response");
		
		setAddress(serialconn, i+flashpagesize);
	    }
	}
	pb.setValue(pb.getMaximum());
	pb.setString("");
	clearLED(serialconn);

	// leave programming mode
	serialconn.send((byte)'L');
	b = serialconn.readbyte(100);
	if (b != (byte)0x0D)
	    throw new IOException("bad response");
	
    }
    public static byte[] readFlash(DeviceDescriptor device, int startaddr, int endaddr,
				   SerialConnection serialconn, JProgressBar pb)
	throws IOException, AVRProgramException {

	byte b;
	byte[] buffer;
	int flashsize = device.getFlashSize();
	int flashpagesize = device.getFlashPageSize();

	pb.setValue(0);
	pb.setMaximum(endaddr);
	if (endaddr > flashsize)
	    throw new AVRProgramException("Can't read past end of flash");
	if ((endaddr % flashpagesize != 0) || (startaddr % flashpagesize != 0))
	    throw new AVRProgramException("Can only read whole flash pages");

	//System.out.println("Reading "+(endaddr-startaddr)+" bytes of Flash from "+device.getName());
	buffer = new byte[(endaddr-startaddr)];
	
	setLED(serialconn);
	// try autoincrement?
	serialconn.send((byte)'a');
	b = serialconn.readbyte(100);
	if (b != (byte)'Y')
	    throw new AVRProgramException("bad response..want autoincrementing!");

	setAddress(serialconn, startaddr);
	    
	boolean fastmode = true;
	byte[] flashpagebuffer;
	for (int i=startaddr; i < endaddr; i+=flashpagesize) {
	    pb.setValue(i);
	    pb.setString("0x"+Integer.toString(i, 16));

	    try {
		// try fastmode
		if (fastmode) {
		    serialconn.send((byte)'z');
		    try {
			flashpagebuffer = serialconn.readbytes(flashpagesize, 250);
		    } catch (IOException e) {
			if (i == startaddr) {
			    fastmode = false;
			    i -= flashpagesize;
			    // so there is a wierdo chance the first byte is '?'...reset address
			    setAddress(serialconn, startaddr);
			    continue;
			}
			else throw e;
		    }
		}  else { // not fast :(
		    // read one page in
		    flashpagebuffer = new byte[flashpagesize];
		    byte[] word;
		    for (int j=0; j < flashpagesize; j+=2) {
			serialconn.send((byte)'R');
			word = serialconn.readbytes(2, 1000);
			flashpagebuffer[j] = word[0];
			flashpagebuffer[j+1] = word[1];
		    }
		}
	    } catch (IOException e) {
		// retry this page...
		System.out.println("No response, restarting from address "+i);
		try {
		    serialconn.readbytes(flashpagesize, 1000); // flush the buffer
		} catch (IOException e2) {}
		serialconn.send((byte)0x1B);
		serialconn.send((byte)0x1B);
		serialconn.send((byte)0x1B);
		serialconn.send((byte)0x1B);
		setAddress(serialconn, i);
		i -= flashpagesize; // (to undo the forloop increment)
		continue;
		
	    }
	    // ok read in one page, copy that page into the buffer
	    System.arraycopy(flashpagebuffer, 0, buffer, i-startaddr, flashpagesize);
	}
	
	pb.setValue(endaddr);
	clearLED(serialconn);
	
	return buffer;
    }

    public static void setAddress(SerialConnection serialconn, int addr) throws IOException {
	byte b;
	addr /= 2;
	serialconn.send((byte)'A');
	serialconn.send((byte)((addr >> 8)&0xff));
	serialconn.send((byte)(addr&0xff));

	//System.out.println("setting addr: "+addr);
	b = serialconn.readbyte(100);
	if (b != (byte)0x0d)
	    throw new IOException("bad response");
    }

    public static void erase(DeviceDescriptor device, SerialConnection serialconn, JProgressBar pb) throws IOException {
	byte b;

	//System.out.println("Erasing "+device.getName());
	setLED(serialconn);
	serialconn.send((byte)'e');
	b = serialconn.readbyte(3000); // give em 3 s
	if (b != (byte)0x0d)
	    throw new IOException("bad response");
	pb.setValue(100);
	clearLED(serialconn);
    }

    public static void setLED(SerialConnection serialconn) throws IOException {
	byte b;
	serialconn.send((byte)'x');
	serialconn.send((byte)0x00);
	b = serialconn.readbyte(100);
	if (b != (byte)0x0d)
	    throw new IOException("bad response");
    }

    public static void clearLED(SerialConnection serialconn) throws IOException {
	byte b;
	serialconn.send((byte)'y');
	serialconn.send((byte)0x00);
	b = serialconn.readbyte(100);
	if (b != (byte)0x0d)
	    throw new IOException("bad response");
    }

}
