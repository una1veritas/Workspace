-------------------------------------------------------
Embedded CaffeineMark Toolkit
-------------------------------------------------------
(C) Copyright 1996, 1997 Pendragon Software Corporation

Part of the CaffeineMark 3.0 Suite
Beta release 7/8/97

IMPORTANT: Please read the accompanying software 
license and disclaimer from the file disclaim.html. 
------------------------------------------------------

The CaffeineMark is a Java benchmark that can be used 
to measure the performance of Java Virtual Machines.
CaffeineMark scores are approximately proportional to 
the number of Java bytecode instructions executed per
second. The test should run comfortably even in small 
memory environments.

The Embedded CaffeineMark uses a subset of the tests
used in the desktop version of the CaffeineMark. The
individual test scores are combined into a geometric 
mean in order to generate an overall score.

More information can be found at Pendragon Software's
web site at http://www.webfayre.com.

------------------------------------------------------

A sample Java application has been included to 
illustrate how the benchmark can be called.

