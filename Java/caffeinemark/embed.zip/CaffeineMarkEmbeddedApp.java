import CaffeineMarkEmbeddedBenchmark;

public class CaffeineMarkEmbeddedApp {

    public static void main(String[] args) {

        int i;

		//Declare the embedded benchmark object
		//Note, CaffeineMarkEmbeddedBenchmark extends the Thread class
		CaffeineMarkEmbeddedBenchmark ceb;

        ceb = new CaffeineMarkEmbeddedBenchmark();

		//Set the normal embedded sequence of tests
		ceb.setNormalSequence();

		//Set all tests to run locally 
		//- this statement is currently 
		//  optional but should be used 
		//  for compatibility with future versions.
		ceb.setAllLocal();

		//Run the thread object synchronously
		ceb.run();

		//Write out the scores to the System output stream.
		//You may substitute any other mechanism for results output.
		for (i = CaffeineMarkEmbeddedBenchmark.SieveTest;
				i <= CaffeineMarkEmbeddedBenchmark.MethodTest;
				i++) {

				System.out.print(ceb.getTestName(i));
				System.out.println(" score = " + ceb.getTestResult(i));
		}

		//Output the overall score
		System.out.println("Overall score = " + ceb.EmbeddedCaffeineMarkScore());

    }

}