/***************************************************************************
 **                        
 **    This file defines the Special Function Registers for
 **    Atmel Semiconductors 
 **    AT91R40008
 **    
 **    Used with ICCARM and AARM.
 **                                
 **    (c) Copyright IAR Systems 2003
 **                                
 **    $Revision: 33661 $
 **                                
 ***************************************************************************/

#include "Atmel/ioat91x40.h"
