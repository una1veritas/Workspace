#ifndef IOSAM3U_H
#define IOSAM3U_H

#ifdef sam3u4
# define sam3u4e
#endif
#ifdef sam3u2
# define sam3u2e
#endif
#ifdef sam3u1
# define sam3u1e
#endif

#include "sam3u/SAM3U.h"

#endif /* IOSAM3U_H */
