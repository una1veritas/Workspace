#ifndef IOSAM3S_H
#define IOSAM3S_H

#ifdef sam3s4
# define sam3s4c
#endif
#ifdef sam3s2
# define sam3s2c
#endif
#ifdef sam3s1
# define sam3s1c
#endif

#include "sam3s/SAM3S.h"

#endif /* IOSAM3S_H */
