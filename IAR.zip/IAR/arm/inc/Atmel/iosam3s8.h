#ifndef IOSAM3S8_H
#define IOSAM3S8_H

#ifdef sam3sd8
# define sam3sd8c
#endif

#ifdef sam3s8
# define sam3s8c
#endif

#include "sam3s8/SAM3S8.h"

#endif /* IOSAM3S8_H */
