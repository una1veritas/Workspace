#ifndef IOSAM3N_H
#define IOSAM3N_H

#ifdef sam3n4
# define sam3n4c
#endif
#ifdef sam3n2
# define sam3n2c
#endif
#ifdef sam3n1
# define sam3n1c
#endif

#include "sam3n/SAM3N.h"

#endif /* IOSAM3N_H */
