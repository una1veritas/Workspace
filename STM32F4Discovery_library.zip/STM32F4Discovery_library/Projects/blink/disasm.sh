#!/usr/bin/env sh
#/home/texane/sat/bin/arm-none-eabi-objdump -marm -Mforce-thumb -EL -b binary -D /tmp/barfoo
/home/texane/sat/bin/arm-none-eabi-objdump -marm -EL -b binary -D /tmp/barfoo
