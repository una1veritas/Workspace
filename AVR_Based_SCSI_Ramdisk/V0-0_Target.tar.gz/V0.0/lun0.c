/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         lun0.c
*
* Language:     C
*
* Description:  These routines control LUN 0 (logical unit 0)
*
*               The taskmanager administers the tasks, the deviceserver executes
*               them
*
*               This is a minimum implementation supporting only one task for
*               every LUN and only one active task for all LUNs at any time
*
*               Note:
*               Commands to LUNs that do not exist are handled by the
*               'lunx_()' routines (only the REQUEST_SENSE and INQUIRY commands
*               are implemented reporting a connect state of 0x03 ("No device
*               supported for this LUN")
*
* Copyright:    (C) 2005 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc (Version 3.3)
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
*
* Changelog:    2005-06-11  Michael Baeuerle
*               Function 'lunx_tm_create()' added
*               Function 'lun0_tm_create()' added
*
*               2005-06-12  Michael Baeuerle
*               Function 'lunx_ds_execute()' added
*               Function 'lun0_ds_execute()' added
*               Data type 'struct TM_TASK' added
*               Data type 'TASK' added
*
*               2005-06-14  Michael Baeuerle
*               'lun0_ds_execute()': Set task state to 'ENDED'
*               'lunx_ds_execute()': Set task state to 'ENDED'
*               'INQUIRY' command implemented
*
*               2005-06-17  Michael Baeuerle
*               'TEST_UNIT_READY' command implemented
*               'REQUEST SENSE' command implemented
*               'FORMAT UNIT' command implemented
*               'RESERVE(6)' command implemented
*               'RESERVE(10)' command implemented
*               'RELEASE(6)' command implemented
*               'RELEASE(10)' command implemented
*
*               2005-06-18  Michael Baeuerle
*               'READ(6)' command implemented
*
*               2005-06-23  Michael Baeuerle
*               'READ(10)' command implemented
*
*               2005-06-24  Michael Baeuerle
*               Bugfix: LUN x device server: Data was not truncated as requested
*                by application client - Fixed
*
*               2005-06-25  Michael Baeuerle
*               Bugfix: 'READ(6)': Now transmits the number of blocks requested
*               Bugfix: 'READ(10)': Now transmits the number of blocks requested
*               UNIT ATTENTION condition handling added
*               Constant 'BLOCKSIZE' added
*
*               2005-07-08  Michael Baeuerle
*               'lun0_tm_create()': Init 'lun0_maxlba' after task is created
*               Constant 'LB_OOR_ERR' added
*               Constant 'LB_UC_ERR' added
*               Function 'lun0_lb_read()' added
*               Function 'lun0_lb_write()' added
*               Sense key MEDIUM ERROR added
*               'WRITE(6)' command implemented
*               'WRITE(10)' command implemented
*
*               2005-07-11  Michael Baeuerle
*               Bugfix: 'READ CAPACITY(10)': Now returns last valid LBA
*
*               2005-07-12  Michael Baeuerle
*               Bugfix: 'lb_write()': Now call 'dram_write()' with 32Bit address
*               Bugfix: 'lb_read()': Now call 'dram_read()' with 32Bit address
*
*
* To do:        Implement remaining optional commands
*
********************************************************************************
*/


/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include <avr/pgmspace.h>
#include <stdio.h>
#include <string.h>
#include "global.h"
#include "debug.h"
#include "inquiry.h"
#include "pia.h"
#include "dram.h"
#include "lun0.h"


/*
********************************************************************************
*
* Type definitions
*
********************************************************************************
*/

struct TM_TASK {
   uint8_t  state;                 /* ENDED or CURRENT */
   uint8_t  cdb[16];               /* Command descriptor block */
   uint8_t  ini_id;                /* Initiator SCSI ID */
};

struct LUN_SENSE {
   uint8_t  key;                   /* Sense key */
   uint8_t  code;                  /* Sense code */
   uint8_t  qualifier;             /* Sense code qualifier */
   uint8_t  info[4];               /* General information */
   uint8_t  key_specific[3];       /* Sense key specific information */
};

typedef struct TM_TASK  TASK;      /* Task handled by taskmanager */
typedef struct LUN_SENSE  SENSE;   /* Sense data for LUN */


/*
********************************************************************************
*
* Global constants
*
********************************************************************************
*/

/* Size of logical blocks in bytes */
/* If you want to increase the blocksize, ensure that there is enough stack
 * space for the data buffer
 */
#define BLOCKSIZE        512

/* 6 Byte command opcodes */
#define TEST_UNIT_READY  0x00
#define REQUEST_SENSE    0x03
#define FORMAT_UNIT      0x04
#define READ6            0x08
#define WRITE6           0x0A      /* Optional */
#define INQUIRY          0x12
#define RESERVE6         0x16      /* Optional */
#define RELEASE6         0x17      /* Optional */
#define SEND_DIAGNOSTIC  0x1D
/* 10 Byte command opcodes */
#define READ_CAPACITY10  0x25
#define READ10           0x28
#define WRITE10          0x2A      /* Optional */
#define RESERVE10        0x56
#define RELEASE10        0x57
/* 12 Byte command opcodes */
#define REPORT_LUNS      0xA0      /* Optional */
#define READ12           0xA8      /* Optional */
#define WRITE12          0xAA      /* Optional */
/* 16 Byte command opcodes */
#define READ16           0x88      /* Optional */
#define WRITE16          0x8A      /* Optional */
#define READ_CAPACITY16  0x9E      /* Optional */

/* Task states */
#define ENDED            0x00
#define CURRENT          0x01

/* Sense keys */
#define NO_SENSE         0x00
#define NOT_READY        0x02
#define MEDIUM_ERROR     0x03
#define HARDWARE_ERROR   0x04
#define ILLEGAL_REQUEST  0x05
#define UNIT_ATTENTION   0x06

/* Error return values for logical block access routines */
#define LB_OOR_ERR       1
#define LB_UC_ERR        2


/*
********************************************************************************
*
* Global variables
*
********************************************************************************
*/

static TASK  lun0_task = {0};      /* LUN0 current task */
static TASK  lunx_task = {0};      /* Current task for nonexisting LUNs */

static SENSE  lun0_sense;          /* LUN0 sense data */
static SENSE  lunx_sense;          /* Sense data for nonexisting LUNs */

static uint8_t  res_active = 0;    /* Reservation active if not zero */
static uint8_t  res_initiator;     /* Initiator which reserved us */
static uint8_t  res_device;        /* Access granted for this initiator */

static uint16_t  maxlba;           /* Last valid LBA */


/*
********************************************************************************
*
* Read logical block
*
* Return value:
* 0         : Success
* LB_OOR_ERR: LBA out of range
* LB_UC_ERR : Uncorrectable data error
*
********************************************************************************
*/

static inline uint8_t  lb_read(uint16_t  lba, uint8_t*  buffer) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[LUN 0 LB access] Read logical block with LBA 0x";
   static const char  string1[] PROGMEM
    = "[LUN 0 LB access] LBA limit: 0x";
   static const char  string2[] PROGMEM
    = "[LUN 0 LB access] LBA out of range!\n";
   static const char  string3[] PROGMEM
    = "[LUN 0 LB access] Uncorrectable read error!\n";
   char  sbuf2[6];                 /* Enough for %04X + \n + \0 */
#endif
   uint8_t  rv;

   /* Check for LBA is out of range */
#ifdef DEBUGMASK
   strcpy_P(sbuf, string1);
   sprintf(sbuf2, "%04X\n", maxlba);
   strcat(sbuf, sbuf2);
   debug(6, sbuf);
#endif
   if (lba > maxlba) {
      STRCPY_P(sbuf, string2);
      DEBUG(6, sbuf);
      return(LB_OOR_ERR);
   }

   /* Read logical block */
#ifdef DEBUGMASK
   strcpy_P(sbuf, string0);
   sprintf(sbuf2, "%04X\n", lba);
   strcat(sbuf, sbuf2);
   debug(6, sbuf);
#endif
   rv = dram_read((uint32_t) lba * BLOCKSIZE, buffer, BLOCKSIZE);
   if (rv) {
      /* Error */
      switch (rv) {
         case DRAM_PARITY_ERR:     /* Parity error */
            STRCPY_P(sbuf, string3);
            DEBUG(6, sbuf);
            return(LB_UC_ERR);
         case DRAM_PAGE_ERR:       /* Page access error */
            /* This indicates that 'BLOCKSIZE' is not a power of two */
         default:
            /* DRAM access error */
            fatal(6);
      }
   }
   return(0);
}


/*
********************************************************************************
*
* Write logical block
*
* Return value:
* 0         : Success
* LB_OOR_ERR: LBA out of range
* LB_UC_ERR : Uncorrectable data error
*
********************************************************************************
*/

static inline uint8_t  lb_write(uint16_t  lba, uint8_t*  buffer) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[LUN 0 LB access] Write logical block with LBA 0x";
   static const char  string1[] PROGMEM
    = "[LUN 0 LB access] LBA limit: 0x";
   static const char  string2[] PROGMEM
    = "[LUN 0 LB access] LBA out of range!\n";
   static const char  string3[] PROGMEM
    = "[LUN 0 LB access] Uncorrectable write error!\n";
   char  sbuf2[6];                 /* Enough for %04X + \n + \0 */
#endif
   uint8_t  rv;

   /* Check for LBA is out of range */
#ifdef DEBUGMASK
   strcpy_P(sbuf, string1);
   sprintf(sbuf2, "%04X\n", maxlba);
   strcat(sbuf, sbuf2);
   debug(6, sbuf);
#endif
   if (lba > maxlba) {
      STRCPY_P(sbuf, string2);
      DEBUG(6, sbuf);
      return(LB_OOR_ERR);
   }

   /* Write logical block */
#ifdef DEBUGMASK
   strcpy_P(sbuf, string0);
   sprintf(sbuf2, "%04X\n", lba);
   strcat(sbuf, sbuf2);
   debug(6, sbuf);
#endif
   rv = dram_write((uint32_t) lba * BLOCKSIZE, buffer, BLOCKSIZE);
   if (rv) {
      /* Error */
      switch (rv) {
         case DRAM_PARITY_ERR:     /* Parity error */
            STRCPY_P(sbuf, string3);
            DEBUG(6, sbuf);
            return(LB_UC_ERR);
         case DRAM_PAGE_ERR:       /* Page access error */
            /* This indicates that 'BLOCKSIZE' is not a power of two */
         default:
            /* DRAM access error */
            fatal(6);
      }
   }
   return(0);
}


/*
********************************************************************************
*
* LUN1-31 taskmanager
*
* Returns 0 on success, 1 if the task is not created (=> BUSY)
*
********************************************************************************
*/

uint8_t  lunx_tm_create(uint8_t  ini_id, uint8_t*  cdb) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[LUN x Taskmanager] Create task\n";
#endif
   uint8_t  i;

   /* Check for running task */
   if (lunx_task.state == CURRENT) return(1);

   /* Create task */
   STRCPY_P(sbuf, string0);
   DEBUG(4, sbuf);
   lunx_task.ini_id = ini_id;
   for (i = 0; i < 16; i++) {
      lunx_task.cdb[i] = cdb[i];
   }
   lunx_task.state = CURRENT;
   return(0);
}


/*
********************************************************************************
*
* LUN1-31 deviceserver
*
* Returns 0 on success, 1 for error (=> CHECK_CONDITION)
*
********************************************************************************
*/

uint8_t  lunx_ds_execute(void) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[LUN x Deviceserver] Execute task\n";
   static const char  string1[] PROGMEM
    = "[LUN x Deviceserver] Command successfully completed\n";
   static const char  string2[] PROGMEM
    = "[LUN x Deviceserver] Command: INQUIRY\n";
   static const char  string3[] PROGMEM
    = "[LUN x Deviceserver] Command: REQUEST SENSE\n";
   static const char  string4[] PROGMEM
    = "[LUN x Deviceserver] Error, sense data prepared\n";
   static const char  string5[] PROGMEM
    = "[LUN x Deviceserver] SCSI transmission error\n";
   static const char  string6[] PROGMEM
    = "[LUN x Deviceserver] Unknown command\n";
   static const char  string7[] PROGMEM = "[LUN x Deviceserver] Opcode: 0x";
   char  sbuf2[3];                 /* Enough for %02X + \0 */
#endif
   uint8_t  rv;
   uint8_t  buffer[18];
   uint16_t  length;

   /* Execute task */
   STRCPY_P(sbuf, string0);
   DEBUG(4, sbuf);
   lunx_task.state = ENDED;

   /* Execute command */
   length = 0;
   switch (lunx_task.cdb[0]) {
      case INQUIRY:
         STRCPY_P(sbuf, string2);
         DEBUG(4, sbuf);
         /* Check for additional information request */
         if (lunx_task.cdb[1] & 0x03) {
            /* Not supported => Prepare sense data */
            lunx_sense.key = ILLEGAL_REQUEST;
            lunx_sense.code = 0x24;          /* "Invalid field in CDB" */
            lunx_sense.qualifier = 0x00;
            lunx_sense.info[0] = 0x00;
            lunx_sense.info[1] = 0x00;
            lunx_sense.info[2] = 0x00;
            lunx_sense.info[3] = 0x00;
            lunx_sense.key_specific[0] = 0xC0;  /* "Error in Byte 1" */
            lunx_sense.key_specific[1] = 0x00;
            lunx_sense.key_specific[2] = 0x01;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Copy response data into data buffer */
         length = 5;
         memcpy_P(buffer, lunx_inquiry, length);
         /* Truncate data if necessary */
         if (lunx_task.cdb[4] < length) {
            length = lunx_task.cdb[4];
         }
         break;
      /* ==================================================================== */
      case REQUEST_SENSE:
         STRCPY_P(sbuf, string3);
         DEBUG(4, sbuf);
         length = 18;
         /* Copy sense data into data buffer */
         buffer[0] = 0x70 | (1 << 7);        /* 'Valid' Bit + "Current error" */
         buffer[1] = 0x00;                   /* Unused */
         buffer[2] = lunx_sense.key;         /* Sense key */
         memcpy_P(&buffer[3], &lunx_sense.info, 4);  /* General information */
         buffer[7] = 0x0A;                   /* Additional length */
         buffer[8] = 0x00;                   /* Unused */
         buffer[9] = 0x00;                   /* Unused */
         buffer[10] = 0x00;                  /* Unused */
         buffer[11] = 0x00;                  /* Unused */
         buffer[12] = lunx_sense.code;       /* Sense code */
         buffer[13] = lunx_sense.qualifier;  /* Sense code qualifier */
         buffer[14] = 0x00;                  /* Unused */
                                            /* Sense key specific information */
         memcpy_P(&buffer[15], &lunx_sense.key_specific, 3);
         /* Truncate data if necessary */
         if (lunx_task.cdb[4] < length) {
            length = lunx_task.cdb[4];
         }
         break;
      /* ==================================================================== */
      default:
         /* Unknown command */
         STRCPY_P(sbuf, string6);
         DEBUG(4, sbuf);
         /* Print CDB */
#ifdef DEBUGMASK
         strcpy_P(sbuf, string7);
         sprintf(sbuf2, "%02X", lunx_task.cdb[0]);
         strcat(sbuf, sbuf2);
         strcat(sbuf, "\n");
         debug(4, sbuf);
#endif
         /* Prepare sense data */
         lunx_sense.key = ILLEGAL_REQUEST;
         lunx_sense.code = 0x25;             /* "Logical unit not supported" */
         lunx_sense.qualifier = 0x00;
         lunx_sense.info[0] = 0x00;
         lunx_sense.info[1] = 0x00;
         lunx_sense.info[2] = 0x00;
         lunx_sense.info[3] = 0x00;
         lunx_sense.key_specific[0] = 0xC0;  /* "Error in command opcode" */
         lunx_sense.key_specific[1] = 0x00;
         lunx_sense.key_specific[2] = 0x00;
         STRCPY_P(sbuf, string4);
         DEBUG(4, sbuf);
         return(1);
   }   
   /* Send data */
   rv = pia_put_data(buffer, length);
   if (rv) {
      /* Data transmission error */
      STRCPY_P(sbuf, string5);
      DEBUG(4, sbuf);
      /* Try to get PIA ready again */
      rv = pia_abort(); if (rv) fatal(3);
      rv = pia_recover(); if (rv) fatal(3);
      /* Prepare sense data */
      lunx_sense.key = HARDWARE_ERROR;
      lunx_sense.code = 0x4B;                /* "Data phase error" */
      lunx_sense.qualifier = 0x00;
      lunx_sense.info[0] = 0x00;
      lunx_sense.info[1] = 0x00;
      lunx_sense.info[2] = 0x00;
      lunx_sense.info[3] = 0x00;
      lunx_sense.key_specific[0] = 0x00;
      lunx_sense.key_specific[1] = 0x00;
      lunx_sense.key_specific[2] = 0x00;
      STRCPY_P(sbuf, string4);
      DEBUG(4, sbuf);
      return(1);
   }

   /* Prepare sense data */
   lunx_sense.key = NO_SENSE;
   lunx_sense.code = 0x00;                   /* "No additional information" */
   lunx_sense.qualifier = 0x00;
   lunx_sense.info[0] = 0x00;
   lunx_sense.info[1] = 0x00;
   lunx_sense.info[2] = 0x00;
   lunx_sense.info[3] = 0x00;
   lunx_sense.key_specific[0] = 0x00;
   lunx_sense.key_specific[1] = 0x00;
   lunx_sense.key_specific[2] = 0x00;
   /* Command successfully completed */
   STRCPY_P(sbuf, string1);
   DEBUG(4, sbuf);
   return(0);
}


/*
********************************************************************************
*
* LUN0 taskmanager
*
********************************************************************************
*/

/* Check for reservation conflict */
/* Returns 0 if no conflict occur, 1 otherwise (=> RESERVATION CONFLICT) */
uint8_t  lun0_tm_check_reservation(uint8_t  ini_id, uint8_t*  cdb) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[LUN 0 Taskmanager] Check for reservation\n";
   static const char  string1[] PROGMEM
    = "[LUN 0 Taskmanager] Reservation conflict\n";
   static const char  string2[] PROGMEM
    = "[LUN 0 Taskmanager] Reservation active for initator with SCSI ID ";
   char  sbuf2[7];                  /* Enough for %d + \n + \0 */
#endif

   /* Check reservation */
   STRCPY_P(sbuf, string0);
   DEBUG(4, sbuf);
   if (!res_active) return(0);
   /* Reservation active */
#ifdef DEBUGMASK
   strcpy_P(sbuf, string2);
   sprintf(sbuf2, "%d\n", res_device);
   strcat(sbuf, sbuf2);
   debug(4, sbuf);
#endif
   /* Accept INQUIRY and REPORT_LUNS commands from any initiator */
   if ((cdb[0] == INQUIRY) || (cdb[0] == REPORT_LUNS)) return(0);
   /* Check reservation type */
   if (res_device == res_initiator) {
      /* Normal reservation active */
      if (res_device == ini_id) return(0);
   }
   else {
      /* 3rd party reservation active */
      if (res_initiator == ini_id) {
         /* Let initiator that installed the 3rd party reservation change it */
         if ((cdb[0] == RESERVE10) || (cdb[0] == RELEASE10)) return(0);
      }
      if (res_device == ini_id) {
         /* Deny reservation change by 3rd party initiator */
         if ((cdb[0] != RESERVE10) && (cdb[0] != RELEASE10)) return(0);
      }
   }
   /* Reservation conflict */
   STRCPY_P(sbuf, string1);
   DEBUG(4, sbuf);
   return(1);
}


/* Create new task */
/* Returns 0 on success, 1 if the task is not created (=> BUSY) */
uint8_t  lun0_tm_create(uint8_t  ini_id, uint8_t*  cdb) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[LUN 0 Taskmanager] Create task\n";
#endif
   uint8_t  i;

   /* Check for running task */
   if (lun0_task.state == CURRENT) return(1);

   /* Create task */
   STRCPY_P(sbuf, string0);
   DEBUG(4, sbuf);
   lun0_task.ini_id = ini_id;
   for (i = 0; i < 16; i++) {
      lun0_task.cdb[i] = cdb[i];
   }
   lun0_task.state = CURRENT;

   /* Calculate last LBA */
   maxlba
    = (uint16_t) memsize * (uint16_t) (1024L * 1024L / BLOCKSIZE);
   maxlba--;
   return(0);
}


/*
********************************************************************************
*
* LUN0 deviceserver
*
* Returns 0 on success, 1 for error (=> CHECK_CONDITION)
*
********************************************************************************
*/

uint8_t  lun0_ds_execute(void) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[LUN 0 Deviceserver] Execute task\n";
   static const char  string1[] PROGMEM
    = "[LUN 0 Deviceserver] Command successfully completed\n";
   static const char  string2[] PROGMEM
    = "[LUN 0 Deviceserver] Error, sense data prepared\n";
   static const char  string3[] PROGMEM
    = "[LUN 0 Deviceserver] Unsupported command group\n";
   static const char  string4[] PROGMEM
    = "[LUN 0 Deviceserver] Unknown command\n";
   static const char  string5[] PROGMEM
    = "[LUN 0 Deviceserver] SCSI transmission error\n";
   static const char  string6[] PROGMEM
    = "[LUN 0 Deviceserver] Command: TEST UNIT READY\n";
   static const char  string7[] PROGMEM
    = "[LUN 0 Deviceserver] Command: REQUEST SENSE\n";
   static const char  string8[] PROGMEM
    = "[LUN 0 Deviceserver] Command: FORMAT UNIT\n";
   static const char  string9[] PROGMEM
    = "[LUN 0 Deviceserver] Command: READ(6)\n";
   static const char  string10[] PROGMEM
    = "[LUN 0 Deviceserver] Command: WRITE(6)\n";
   static const char  string11[] PROGMEM
    = "[LUN 0 Deviceserver] Command: INQUIRY\n";
   static const char  string14[] PROGMEM
    = "[LUN 0 Deviceserver] Command: SEND DIAGNOSTIC\n";
   static const char  string15[] PROGMEM
    = "[LUN 0 Deviceserver] Command: READ CAPACITY(10)\n";
   static const char  string16[] PROGMEM
    = "[LUN 0 Deviceserver] Command: READ(10)\n";
   static const char  string17[] PROGMEM
    = "[LUN 0 Deviceserver] Command: WRITE(10)\n";
   static const char  string18[] PROGMEM
    = "[LUN 0 Deviceserver] Command: RESERVE(10)\n";
   static const char  string19[] PROGMEM
    = "[LUN 0 Deviceserver] Command: RELEASE(10)\n";
   static const char  string20[] PROGMEM
    = "[LUN 0 Deviceserver] CDB: ";
   static const char  string21[] PROGMEM
    = "[LUN 0 Deviceserver] UNIT ATTENTION condition, sense data prepared\n";
   char  sbuf2[4];                 /* Enough for %02X + 1 char + \0 */
#endif
   uint8_t  rv;                    /* Return value */
   uint8_t  buffer[BLOCKSIZE];     /* Data buffer (Check for stack overflow!) */
   uint16_t  length = 0;           /* Number of bytes prepared for initiator */
   uint32_t  capacity;             /* Capacity in logical blocks */
   uint16_t  i, ii;

   /* Execute task */
   STRCPY_P(sbuf, string0);
   DEBUG(4, sbuf);
   lun0_task.state = ENDED;
 
   /* Check for unsupported command group */
   if (lun0_task.cdb[0] < 0x20) length = 6;
   if ((lun0_task.cdb[0] >= 0x20) && (lun0_task.cdb[0] < 0x60)) length = 10;
   if ((lun0_task.cdb[0] >= 0xA0) && (lun0_task.cdb[0] < 0xC0)) length = 12;
   if ((lun0_task.cdb[0] >= 0x80) && (lun0_task.cdb[0] < 0xA0)) length = 16;
   if (!length) {
      /* Unsupported command group */
      STRCPY_P(sbuf, string3);
      DEBUG(4, sbuf);
      /* Prepare sense data */
      lun0_sense.key = ILLEGAL_REQUEST;
      lun0_sense.code = 0x24;                /* "Invalid field in CDB" */
      lun0_sense.qualifier = 0x00;
      lun0_sense.info[0] = 0x00;
      lun0_sense.info[1] = 0x00;
      lun0_sense.info[2] = 0x00;
      lun0_sense.info[3] = 0x00;
      lun0_sense.key_specific[0] = 0xC0;     /* "Error in command opcode" */
      lun0_sense.key_specific[1] = 0x00;
      lun0_sense.key_specific[2] = 0x00;
      STRCPY_P(sbuf, string2);
      DEBUG(4, sbuf);
      return(1);   
   }
#ifdef DEBUGMASK
   /* Print CDB */
   strcpy_P(sbuf, string20);
   for (i = 0; i < length; i++) {
      sprintf(sbuf2, "%02X ", lun0_task.cdb[i]);
      strcat(sbuf, sbuf2);
   }
   strcat(sbuf, "\n");
   debug(4, sbuf);
#endif

   /* Check for UNIT ATTENTION condition */
   if (unit_attention & (1 << lun0_task.ini_id)) {
      /* UNIT ATTENTION condition pending for current initiator */
      if ((lun0_task.cdb[0] != INQUIRY) && (lun0_task.cdb[0] != REPORT_LUNS)) {
         /*
          * If command is INQUIRY or REPORT LUNS, the UNIT ATTENTION condition
          * is preserved and delivered after the next command (as defined by
          * the SAM document)
          */
         /* Clear UNIT ATTENTION condition for current initiator */
         unit_attention &= (uint8_t) ~(1 << lun0_task.ini_id);
         /* Prepare sense data */
         lun0_sense.key = UNIT_ATTENTION;
         lun0_sense.code = 0x29;             /* "Power-on or target reset" */
         lun0_sense.qualifier = 0x00;
         lun0_sense.info[0] = 0x00;
         lun0_sense.info[1] = 0x00;
         lun0_sense.info[2] = 0x00;
         lun0_sense.info[3] = 0x00;
         lun0_sense.key_specific[0] = 0x00;
         lun0_sense.key_specific[1] = 0x00;
         lun0_sense.key_specific[2] = 0x00;
         STRCPY_P(sbuf, string21);
         DEBUG(4, sbuf);
         return(1);
      }
   }

   /* Execute command */
   length = 0;
   switch (lun0_task.cdb[0]) {
      case TEST_UNIT_READY:
         STRCPY_P(sbuf, string6);
         DEBUG(4, sbuf);
         /* Check whether DRAM is present */
         if (!memsize) {
            /* No, prepare sense data */
            lun0_sense.key = NOT_READY;
            lun0_sense.code = 0x3A;          /* "Medium not present" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0x00;
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x00;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         break;
      /* ==================================================================== */
      case REQUEST_SENSE:
         STRCPY_P(sbuf, string7);
         DEBUG(4, sbuf);
         length = 18;
         /* Copy sense data into data buffer */
         buffer[0] = 0x70 | (1 << 7);        /* 'Valid' Bit + "Current error" */
         buffer[1] = 0x00;                   /* Unused */
         buffer[2] = lun0_sense.key;         /* Sense key */
         memcpy(&buffer[3], &lun0_sense.info, 4);  /* General information */
         buffer[7] = 0x0A;                   /* Additional length */
         buffer[8] = 0x00;                   /* Unused */
         buffer[9] = 0x00;                   /* Unused */
         buffer[10] = 0x00;                  /* Unused */
         buffer[11] = 0x00;                  /* Unused */
         buffer[12] = lun0_sense.code;       /* Sense code */
         buffer[13] = lun0_sense.qualifier;  /* Sense code qualifier */
         buffer[14] = 0x00;                  /* Unused */
                                            /* Sense key specific information */
         memcpy(&buffer[15], &lun0_sense.key_specific, 3);
         /* Truncate data if necessary */
         if (lun0_task.cdb[4] < length) {
            length = lun0_task.cdb[4];
         }
         break;
      /* ==================================================================== */
      case FORMAT_UNIT:
         STRCPY_P(sbuf, string8);
         DEBUG(4, sbuf);
         /* Check whether DRAM is present */
         if (!memsize) {
            /* No, prepare sense data */
            lun0_sense.key = NOT_READY;
            lun0_sense.code = 0x3A;          /* "Medium not present" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0x00;
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x00;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Check for parameter list ('FMTDATA' Bit) */
         if (lun0_task.cdb[1] & 0x10) {
            /* Parameter lists are not supported */
            /* Prepare sense data */
            lun0_sense.key = ILLEGAL_REQUEST;
            lun0_sense.code = 0x24;          /* "Invalid field in CDB" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0xC0;  /* "Error in Byte 1" */
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x01;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* We use no media format => Do nothing and report success */
         break;
      /* ==================================================================== */
      case READ6:
         STRCPY_P(sbuf, string9);
         DEBUG(4, sbuf);
         /* Check whether DRAM is present */
         if (!memsize) {
            /* No, prepare sense data */
            lun0_sense.key = NOT_READY;
            lun0_sense.code = 0x3A;          /* "Medium not present" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0x00;
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x00;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Number of blocks */
         if (lun0_task.cdb[4]) length = lun0_task.cdb[4]; else length = 256;
         /* LBA of first block */
         ii = (uint16_t) lun0_task.cdb[2] << 8;
         ii |= lun0_task.cdb[3];
         /* Send blocks */
         for (i = 0; i < length; i++) {
            /* Read block from medium */
            if (lun0_task.cdb[1] & 0x1F) rv = LB_OOR_ERR;
            else rv = lb_read(ii + i, buffer);
            if (rv) {
               /* Read error, prepare sense data */
               switch (rv) {
                  case LB_OOR_ERR:  /* LBA out of range */
                     lun0_sense.key = ILLEGAL_REQUEST;
                     lun0_sense.code = 0x21;      /* "LBA out of range" */
                     lun0_sense.qualifier = 0x00;
                     break;
                  case LB_UC_ERR:   /* Uncorrectable read error */
                  default:
                     lun0_sense.key = MEDIUM_ERROR;
                     lun0_sense.code = 0x11;      /* "Unrecovered read error" */
                     lun0_sense.qualifier = 0x00;
               }
               lun0_sense.info[0] = 0x00;
               lun0_sense.info[1] = 0x00;
               lun0_sense.info[2] = 0x00;
               lun0_sense.info[3] = 0x00;
               lun0_sense.key_specific[0] = 0x00;
               lun0_sense.key_specific[1] = 0x00;
               lun0_sense.key_specific[2] = 0x00;
               STRCPY_P(sbuf, string2);
               DEBUG(4, sbuf);
               return(1);
            }
            /* Send block to initiator */
            rv = pia_put_data(buffer, BLOCKSIZE);
            if (rv) {
               /* Data transmission error */
               STRCPY_P(sbuf, string5);
               DEBUG(4, sbuf);
               /* Try to get PIA ready again */
               rv = pia_abort(); if (rv) fatal(3);
               rv = pia_recover(); if (rv) fatal(3);
               /* Prepare sense data */
               lun0_sense.key = HARDWARE_ERROR;
               lun0_sense.code = 0x4B;       /* "Data phase error" */
               lun0_sense.qualifier = 0x00;
               lun0_sense.info[0] = 0x00;
               lun0_sense.info[1] = 0x00;
               lun0_sense.info[2] = 0x00;
               lun0_sense.info[3] = 0x00;
               lun0_sense.key_specific[0] = 0x00;
               lun0_sense.key_specific[1] = 0x00;
               lun0_sense.key_specific[2] = 0x00;
               STRCPY_P(sbuf, string2);
               DEBUG(4, sbuf);
               return(1);
            }
         }
         /* Data already sent */
         length = 0;
         break;
      /* ==================================================================== */
      case WRITE6:                           /* Optional */
         STRCPY_P(sbuf, string10);
         DEBUG(4, sbuf);
         /* Check whether DRAM is present */
         if (!memsize) {
            /* No, prepare sense data */
            lun0_sense.key = NOT_READY;
            lun0_sense.code = 0x3A;          /* "Medium not present" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0x00;
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x00;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Number of blocks */
         if (lun0_task.cdb[4]) length = lun0_task.cdb[4]; else length = 256;
         /* LBA of first block */
         ii = (uint16_t) lun0_task.cdb[2] << 8;
         ii |= lun0_task.cdb[3];
         /* Receive blocks */
         for (i = 0; i < length; i++) {
            /* Get block from initiator */
            rv = pia_get_data(buffer, BLOCKSIZE);
            if (rv) {
               /* Data transmission error */
               STRCPY_P(sbuf, string5);
               DEBUG(4, sbuf);
               /* Try to get PIA ready again */
               rv = pia_abort(); if (rv) fatal(3);
               rv = pia_recover(); if (rv) fatal(3);
               /* Prepare sense data */
               lun0_sense.key = HARDWARE_ERROR;
               lun0_sense.code = 0x4B;       /* "Data phase error" */
               lun0_sense.qualifier = 0x00;
               lun0_sense.info[0] = 0x00;
               lun0_sense.info[1] = 0x00;
               lun0_sense.info[2] = 0x00;
               lun0_sense.info[3] = 0x00;
               lun0_sense.key_specific[0] = 0x00;
               lun0_sense.key_specific[1] = 0x00;
               lun0_sense.key_specific[2] = 0x00;
               STRCPY_P(sbuf, string2);
               DEBUG(4, sbuf);
               return(1);
            }
            /* Write block to medium */
            if (lun0_task.cdb[1] & 0x1F) rv = LB_OOR_ERR;
            else rv = lb_write(ii + i, buffer);
            if (rv) {
               /* Write error, prepare sense data */
               switch (rv) {
                  case LB_OOR_ERR:           /* LBA out of range */
                     lun0_sense.key = ILLEGAL_REQUEST;
                     lun0_sense.code = 0x21;       /* "LBA out of range" */
                     lun0_sense.qualifier = 0x00;
                     break;
                  case LB_UC_ERR:            /* Uncorrectable write error */
                  default:
                     lun0_sense.key = MEDIUM_ERROR;
                     /* Return C0/03 because C0/00 "Write error" not allowed */
                     lun0_sense.code = 0x0C;       /* "Write error" */
                     lun0_sense.qualifier = 0x03;  /* Recommend reassignment */
               }
               lun0_sense.info[0] = 0x00;
               lun0_sense.info[1] = 0x00;
               lun0_sense.info[2] = 0x00;
               lun0_sense.info[3] = 0x00;
               lun0_sense.key_specific[0] = 0x00;
               lun0_sense.key_specific[1] = 0x00;
               lun0_sense.key_specific[2] = 0x00;
               STRCPY_P(sbuf, string2);
               DEBUG(4, sbuf);
               return(1);
            }
         }
         /* Nothing to send */
         length = 0;
         break;
      /* ==================================================================== */
      case INQUIRY:
         STRCPY_P(sbuf, string11);
         DEBUG(4, sbuf);
         /* Check for additional information request */
         if (lun0_task.cdb[1] & 0x03) {
            /* Not supported => Prepare sense data */
            lun0_sense.key = ILLEGAL_REQUEST;
            lun0_sense.code = 0x24;          /* "Invalid field in CDB" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0xC0;  /* "Error in Byte 1" */
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x01;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Copy response data into data buffer */
         memcpy_P(buffer, lun0_inquiry, 5);
         length = 5;
         if (buffer[4] <= 36 - 5) {
            memcpy_P(&buffer[5], &lun0_inquiry[5], buffer[4]);
            length += buffer[4];
         }
         else {
            memcpy_P(&buffer[5], &lun0_inquiry[5], 31);
            length += 31;
         }
         /* Truncate data if necessary */
         if (lun0_task.cdb[4] < length) {
            length = lun0_task.cdb[4];
         }
         break;
      /* ==================================================================== */
      case RESERVE6:                         /* Optional */
         /* Check for extend reservation ('Extend' Bit) */
         if (lun0_task.cdb[1] & 0x01) {
            /* Extend reservation not supported */
            /* Prepare sense data */
            lun0_sense.key = ILLEGAL_REQUEST;
            lun0_sense.code = 0x24;          /* "Invalid field in CDB" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0xC0;  /* "Error in Byte 1" */
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x01;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Normal reservation */
         res_initiator = lun0_task.ini_id;
         res_device = lun0_task.ini_id;
         res_active = 1;
         break;
      /* ==================================================================== */
      case RELEASE6:                         /* Optional */
         /* Check for extend release ('Extend' Bit) */
         if (lun0_task.cdb[1] & 0x01) {
            /* Extend release not supported */
            /* Prepare sense data */
            lun0_sense.key = ILLEGAL_REQUEST;
            lun0_sense.code = 0x24;          /* "Invalid field in CDB" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0xC0;  /* "Error in Byte 1" */
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x01;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Release reservation */
         res_active = 0;
         break;
      /* ==================================================================== */
      case SEND_DIAGNOSTIC:
         STRCPY_P(sbuf, string14);
         DEBUG(4, sbuf);
         /* Check for selftest request ('ST' Bit) */
         if (!(lun0_task.cdb[1] & 0x04)) {
            /* Only selftest supported */
            /* Prepare sense data */
            lun0_sense.key = ILLEGAL_REQUEST;
            lun0_sense.code = 0x24;          /* "Invalid field in CDB" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0xC0;  /* "Error in Byte 1" */
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x01;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* We cannot do useful checks without losing data! */
         /* Do nothing and report success */
         break;
      /* ==================================================================== */
      case READ_CAPACITY10:
         STRCPY_P(sbuf, string15);
         DEBUG(4, sbuf);
         /* Check whether DRAM is present */
         if (!memsize) {
            /* No, prepare sense data */
            lun0_sense.key = NOT_READY;
            lun0_sense.code = 0x3A;          /* "Medium not present" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0x00;
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x00;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         length = 8;
         /* Number of logical blocks */
         capacity = (uint32_t) memsize * 1024 * 1024 / BLOCKSIZE;
         capacity--;
         buffer[0] = (uint8_t) (capacity >> 24);
         buffer[1] = (uint8_t) ((capacity >> 16) & 0xFF);
         buffer[2] = (uint8_t) ((capacity >> 8) & 0xFF);
         buffer[3] = (uint8_t) (capacity & 0xFF);
         /* Blocksize */
         buffer[4] = 0x00;
         buffer[5] = 0x00;
         buffer[6] = (uint8_t) (BLOCKSIZE >> 8);
         buffer[7] = (uint8_t) (BLOCKSIZE & 0xFF);
         break;
      /* ==================================================================== */
      case READ10:
         STRCPY_P(sbuf, string16);
         DEBUG(4, sbuf);
         /* Check whether DRAM is present */
         if (!memsize) {
            /* No, prepare sense data */
            lun0_sense.key = NOT_READY;
            lun0_sense.code = 0x3A;          /* "Medium not present" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0x00;
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x00;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Number of blocks */
         length = (uint16_t) lun0_task.cdb[7] << 8;
         length |= lun0_task.cdb[8];
         /* LBA of first block */
         ii = (uint16_t) lun0_task.cdb[4] << 8;
         ii |= lun0_task.cdb[5];
         /* Send blocks */
         for (i = 0; i < length; i++) {
            /* Read block from medium */
            if (lun0_task.cdb[2] | lun0_task.cdb[3]) rv = LB_OOR_ERR;
            else rv = lb_read(ii + i, buffer);
            if (rv) {
               /* Read error, prepare sense data */
               switch (rv) {
                  case LB_OOR_ERR:  /* LBA out of range */
                     lun0_sense.key = ILLEGAL_REQUEST;
                     lun0_sense.code = 0x21;      /* "LBA out of range" */
                     lun0_sense.qualifier = 0x00;
                     break;
                  case LB_UC_ERR:   /* Uncorrectable read error */
                  default:
                     lun0_sense.key = MEDIUM_ERROR;
                     lun0_sense.code = 0x11;      /* "Unrecovered read error" */
                     lun0_sense.qualifier = 0x00;
               }
               lun0_sense.info[0] = 0x00;
               lun0_sense.info[1] = 0x00;
               lun0_sense.info[2] = 0x00;
               lun0_sense.info[3] = 0x00;
               lun0_sense.key_specific[0] = 0x00;
               lun0_sense.key_specific[1] = 0x00;
               lun0_sense.key_specific[2] = 0x00;
               STRCPY_P(sbuf, string2);
               DEBUG(4, sbuf);
               return(1);
            }
            /* Send block to initiator */
            rv = pia_put_data(buffer, BLOCKSIZE);
            if (rv) {
               /* Data transmission error */
               STRCPY_P(sbuf, string5);
               DEBUG(4, sbuf);
               /* Try to get PIA ready again */
               rv = pia_abort(); if (rv) fatal(3);
               rv = pia_recover(); if (rv) fatal(3);
               /* Prepare sense data */
               lun0_sense.key = HARDWARE_ERROR;
               lun0_sense.code = 0x4B;       /* "Data phase error" */
               lun0_sense.qualifier = 0x00;
               lun0_sense.info[0] = 0x00;
               lun0_sense.info[1] = 0x00;
               lun0_sense.info[2] = 0x00;
               lun0_sense.info[3] = 0x00;
               lun0_sense.key_specific[0] = 0x00;
               lun0_sense.key_specific[1] = 0x00;
               lun0_sense.key_specific[2] = 0x00;
               STRCPY_P(sbuf, string2);
               DEBUG(4, sbuf);
               return(1);
            }
         }
         /* Data already sent */
         length = 0;
         break;
      /* ==================================================================== */
      case WRITE10:                          /* Optional */
         STRCPY_P(sbuf, string17);
         DEBUG(4, sbuf);
         /* Check whether DRAM is present */
         if (!memsize) {
            /* No, prepare sense data */
            lun0_sense.key = NOT_READY;
            lun0_sense.code = 0x3A;          /* "Medium not present" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0x00;
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x00;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Number of blocks */
         length = (uint16_t) lun0_task.cdb[7] << 8;
         length |= lun0_task.cdb[8];
         /* LBA of first block */
         ii = (uint16_t) lun0_task.cdb[4] << 8;
         ii |= lun0_task.cdb[5];
         /* Receive blocks */
         for (i = 0; i < length; i++) {
            /* Get block from initiator */
            rv = pia_get_data(buffer, BLOCKSIZE);
            if (rv) {
               /* Data transmission error */
               STRCPY_P(sbuf, string5);
               DEBUG(4, sbuf);
               /* Try to get PIA ready again */
               rv = pia_abort(); if (rv) fatal(3);
               rv = pia_recover(); if (rv) fatal(3);
               /* Prepare sense data */
               lun0_sense.key = HARDWARE_ERROR;
               lun0_sense.code = 0x4B;       /* "Data phase error" */
               lun0_sense.qualifier = 0x00;
               lun0_sense.info[0] = 0x00;
               lun0_sense.info[1] = 0x00;
               lun0_sense.info[2] = 0x00;
               lun0_sense.info[3] = 0x00;
               lun0_sense.key_specific[0] = 0x00;
               lun0_sense.key_specific[1] = 0x00;
               lun0_sense.key_specific[2] = 0x00;
               STRCPY_P(sbuf, string2);
               DEBUG(4, sbuf);
               return(1);
            }
            /* Write block to medium */
            if (lun0_task.cdb[2] | lun0_task.cdb[3]) rv = LB_OOR_ERR;
            else rv = lb_write(ii + i, buffer);
            if (rv) {
               /* Write error, prepare sense data */
               switch (rv) {
                  case LB_OOR_ERR:  /* LBA out of range */
                     lun0_sense.key = ILLEGAL_REQUEST;
                     lun0_sense.code = 0x21;       /* "LBA out of range" */
                     lun0_sense.qualifier = 0x00;
                     break;
                  case LB_UC_ERR:   /* Uncorrectable write error */
                  default:
                     lun0_sense.key = MEDIUM_ERROR;
                     /* Return C0/03 because C0/00 "Write error" not allowed */
                     lun0_sense.code = 0xC0;       /* "Unrecovered read error" */
                     lun0_sense.qualifier = 0x03;  /* "Recommend reallocation" */
               }
               lun0_sense.info[0] = 0x00;
               lun0_sense.info[1] = 0x00;
               lun0_sense.info[2] = 0x00;
               lun0_sense.info[3] = 0x00;
               lun0_sense.key_specific[0] = 0x00;
               lun0_sense.key_specific[1] = 0x00;
               lun0_sense.key_specific[2] = 0x00;
               STRCPY_P(sbuf, string2);
               DEBUG(4, sbuf);
               return(1);
            }
         }
         /* Nothing to send */
         length = 0;
         break;
      /* ==================================================================== */
      case RESERVE10:
         STRCPY_P(sbuf, string18);
         DEBUG(4, sbuf);
         /* Check for extend reservation ('Extend' Bit) */
         if (lun0_task.cdb[1] & 0x01) {
            /* Extend reservation not supported */
            /* Prepare sense data */
            lun0_sense.key = ILLEGAL_REQUEST;
            lun0_sense.code = 0x24;          /* "Invalid field in CDB" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0xC0;  /* "Error in Byte 1" */
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x01;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Check for 3rd party reservation ('3rdPty' Bit) */
         if (lun0_task.cdb[1] & 0x10) {
            /* Reserve LUN for other initiator */
            res_initiator = lun0_task.ini_id;
            res_device = lun0_task.cdb[3];
         }
         else {
            /* Normal reservation */
            res_initiator = lun0_task.ini_id;
            res_device = lun0_task.ini_id;
         }
         res_active = 1;
         break;
      /* ==================================================================== */
      case RELEASE10:
         STRCPY_P(sbuf, string19);
         DEBUG(4, sbuf);
         /* Check for extend release ('Extend' Bit) */
         if (lun0_task.cdb[1] & 0x01) {
            /* Extend release not supported */
            /* Prepare sense data */
            lun0_sense.key = ILLEGAL_REQUEST;
            lun0_sense.code = 0x24;          /* "Invalid field in CDB" */
            lun0_sense.qualifier = 0x00;
            lun0_sense.info[0] = 0x00;
            lun0_sense.info[1] = 0x00;
            lun0_sense.info[2] = 0x00;
            lun0_sense.info[3] = 0x00;
            lun0_sense.key_specific[0] = 0xC0;  /* "Error in Byte 1" */
            lun0_sense.key_specific[1] = 0x00;
            lun0_sense.key_specific[2] = 0x01;
            STRCPY_P(sbuf, string2);
            DEBUG(4, sbuf);
            return(1);
         }
         /* Check for 3rd party release ('3rdPty' Bit) */
         if (lun0_task.cdb[1] & 0x10) {
            /* Check if matching reservation is active */
            if (lun0_task.cdb[3] != res_device) {
               /* Try to release nonexistent reservation */
               /* Prepare sense data */
               lun0_sense.key = ILLEGAL_REQUEST;
               lun0_sense.code = 0x24;       /* "Invalid field in CDB" */
               lun0_sense.qualifier = 0x00;
               lun0_sense.info[0] = 0x00;
               lun0_sense.info[1] = 0x00;
               lun0_sense.info[2] = 0x00;
               lun0_sense.info[3] = 0x00;
               lun0_sense.key_specific[0] = 0xC0;  /* "Error in Byte 3" */
               lun0_sense.key_specific[1] = 0x00;
               lun0_sense.key_specific[2] = 0x03;
               STRCPY_P(sbuf, string2);
               DEBUG(4, sbuf);
               return(1);
            }
         }
         /* Release reservation */
         res_active = 0;
         break;
      /* ==================================================================== */
      /* Commands that have become mandatory in recent SCSI drafts */
      case REPORT_LUNS:                      /* Optional */
      case READ12:                           /* Optional */
      case WRITE12:                          /* Optional */
      case READ16:                           /* Optional */
      case WRITE16:                          /* Optional */
      case READ_CAPACITY16:                  /* Optional */
      default:
         /* Unknown command */
         STRCPY_P(sbuf, string4);
         DEBUG(4, sbuf);
         /* Prepare sense data */
         lun0_sense.key = ILLEGAL_REQUEST;
         lun0_sense.code = 0x24;             /* "Invalid field in CDB" */
         lun0_sense.qualifier = 0x00;
         lun0_sense.info[0] = 0x00;
         lun0_sense.info[1] = 0x00;
         lun0_sense.info[2] = 0x00;
         lun0_sense.info[3] = 0x00;
         lun0_sense.key_specific[0] = 0xC0;  /* "Error in command opcode" */
         lun0_sense.key_specific[1] = 0x00;
         lun0_sense.key_specific[2] = 0x00;
         STRCPY_P(sbuf, string2);
         DEBUG(4, sbuf);
         return(1);   
   }
   /* Send data (if necessary) */
   rv = pia_put_data(buffer, length);
   if (rv) {
      /* Data transmission error */
      STRCPY_P(sbuf, string5);
      DEBUG(4, sbuf);
      /* Try to get PIA ready again */
      rv = pia_abort(); if (rv) fatal(3);
      rv = pia_recover(); if (rv) fatal(3);
      /* Prepare sense data */
      lun0_sense.key = HARDWARE_ERROR;
      lun0_sense.code = 0x4B;                /* "Data phase error" */
      lun0_sense.qualifier = 0x00;
      lun0_sense.info[0] = 0x00;
      lun0_sense.info[1] = 0x00;
      lun0_sense.info[2] = 0x00;
      lun0_sense.info[3] = 0x00;
      lun0_sense.key_specific[0] = 0x00;
      lun0_sense.key_specific[1] = 0x00;
      lun0_sense.key_specific[2] = 0x00;
      STRCPY_P(sbuf, string2);
      DEBUG(4, sbuf);
      return(1);
   }

   /* Prepare sense data */
   lun0_sense.key = NO_SENSE;
   lun0_sense.code = 0x00;                   /* "No additional information" */
   lun0_sense.qualifier = 0x00;
   lun0_sense.info[0] = 0x00;
   lun0_sense.info[1] = 0x00;
   lun0_sense.info[2] = 0x00;
   lun0_sense.info[3] = 0x00;
   lun0_sense.key_specific[0] = 0x00;
   lun0_sense.key_specific[1] = 0x00;
   lun0_sense.key_specific[2] = 0x00;
   /* Command successfully completed */
   STRCPY_P(sbuf, string1);
   DEBUG(4, sbuf);
   return(0);
}


/* EOF */
