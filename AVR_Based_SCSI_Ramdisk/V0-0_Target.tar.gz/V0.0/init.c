/*
********************************************************************************
*
* Header
*  
* Project:      SCSI controller
*
* Module:       Target
* File:         init.c
*
* Language:     C
* 
* Description:  Setup MCU after reset
* 
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler:   gcc (Version 3.3)
*               Platform:   AVR
*               OS:         none
* Tested with:  Compiler:   gcc (Version 3.3)
*               Platform:   SCSI RAM-disk Hardware V1.0.1 (ATmega64)
*               OS:         none
* Do not work:  -
* 
* 
* Changelog:    2004-10-24  Michael Baeuerle
*               Initialisation for I/O ports added
*               Initialisation for Timer1 added
* 
*               2004-11-06  Michael Baeuerle
*               Initialisation for USART0 added
* 
*               2004-11-07  Michael Baeuerle
*               Configure external interrupts
* 
*               2005-05-26  Michael Baeuerle
*               Code moved to section '.init3'
* 
*               2005-06-24  Michael Baeuerle
*               USART bitrate changed to 38.4kBit/s
* 
*               2005-06-25  Michael Baeuerle
*               Initialisation for Timer0 (DRAM refresh timer) added
* 
*               2005-07-06  Michael Baeuerle
*               Use Timer2 for DRAM refresh because of its higher priority
*               Initialisation for Timer0 removed
*               Initialisation for Timer2 (DRAM refresh timer) added
*
* 
* To do:        -
* 
********************************************************************************
*/


/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include <avr/io.h>
#include "global.h"
#include "interrupt.h"


/*
********************************************************************************
*
* Forwared declarations
*
********************************************************************************
*/

void  init3(void) __attribute__ ((naked)) __attribute__ ((section (".init3")));


/*
********************************************************************************
*
* Init1 section code
*
********************************************************************************
*/

void  init3(void) {
   /* Init Ports */
   DDRA = 0x00;                    /* Release memory data bus */
   PORTA = 0xFF;                   /* Enable memory data bus pull-ups */
   DDRB = 0xF0;                    /* Drive memory /CAS lines */
   PORTB = 0xFF;                   /* Enable pull-ups for ID Jumperblock */
   DDRC = 0xFF;                    /* Drive memory address lines */
   PORTC = 0x00;
   DDRD = 0xE0;
   PORTD = 0x1F;
   DDRE = 0x3E;                    /* Drive PIA control lines A0, RD and WR */
   PORTE = 0xFF;
   DDRF = 0x00;                    /* Release PIA data bus */
   PORTF = 0xFF;                   /* Enable PIA data bus pull-ups */
   DDRG = 0x1D;                    /* Drive memory /RAS and /WR line */
   PORTG = 0x1F;

   /* Init USART0 */
;   UBRR0H = 0x00;                  /* 9.6kBit/s */
;   UBRR0L = 103 / ((uint32_t) 16000000 / FREQUENCY);
   UBRR0H = 0x00;                  /* 38.4kBit/s */
   UBRR0L = 25 / ((uint32_t) 16000000 / FREQUENCY);
   UCSR0B = (1 << TXEN);           /* Enable transmitter */
   UCSR0A = (1 << TXC);            /* Clear transmit complete flag */
   UCSR0C = (3 << UCSZ0);          /* Set Frame format to 8N1 */

   /* Init system timer (1ms resolution) */
   /* Using Timer1 in CTC mode without prescaler */
   TCCR1A = 0x00;
   TCCR1B = (1 << WGM12) | (1 << CS10);
   TCCR1C = 0x00;
   OCR1AH = (uint8_t) ((FREQUENCY / (uint32_t) TPS) >> 8);
   OCR1AL = (uint8_t) ((FREQUENCY / (uint32_t) TPS) & 0x000000FF);
   TIMSK |= (1 << OCIE1A);

   /* Init DRAM refresh timer */
   /* Using Timer2 in CTC mode without prescaler */
   TCCR2 = (1 << WGM21) | (1 << CS20);
   OCR2 = 200 / ((uint32_t) 16000000 / FREQUENCY);  
   TIMSK |= (0 << OCIE2);          /* Mask compare match interrupt */

   /* Init external interrupts */
   EICRA = 0x00;
   EICRB = 0x00;                   /* Low-level trigger for ext. ints 6 & 7 */
   EIMSK = (0 << INT6) | (0 << INT7);  /* Mask external interrupts 6 & 7 */
   EIFR = (1 << INT6) | (1 << INT7);  /* Clear flags for ext. ints 6 & 7 */
}


/* EOF */
