/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         dram.c
*
* Language:     C
*
* Description:  DRAM access routines (Early write and fast page mode is used)
*
*               Attention:
*               Interrupt latency is critical (10us or refresh may time out)!
*               All DRAM accesses must be atomic so they must run with disabled
*                interrups or the refresh may collide on the memory bus
*               These routines are designed to match these requirements at 16MHz
*                core clock
*
*               Notes:
*               - Only 1MiByte and 4MiByte modules are supported
*               - The refresh is handled by Timer2 compare match interrupt
*                 handler => Look at 'interrupt.c'
*
* Copyright:    (C) 2005 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc (Version 3.3)
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
*
* Changelog:    2005-07-01  Michael Baeuerle
*               Function 'dram_read()' added
*               Function 'dram_write()' added
*
*               2005-07-03  Michael Baeuerle
*               Debugging messages added
*
*               2005-07-06  Michael Baeuerle
*               Bugfix: 'dram_read()': /CAS access time not met because AVR
*                has latched pin data on previous (not actual) cycle - Fixed
*               Bugfix: Page mode routines calculate wrong address - Fixed
*               More debugging messages added
*
*               2005-07-07  Michael Baeuerle
*               Fast assembler address splitting routines added
*               Constant 'FAST_ADDR_SPLIT' added (to enable the assembler code)
*
*               2005-07-09  Michael Baeuerle
*               Function 'dram_get_size()' added
*
*               2005-07-10  Michael Baeuerle
*               Bugfix: Remove overlapping register variables
*               Bugfix: Page mode address calculation fixed again
*               Bugfix: Shift address bits A8-A10 to Bit5-7 of MABH
*               'dram_get_size()' now rejects 256KiByte modules
*
*
* To do:        Parity checking
*
********************************************************************************
*/


/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include <avr/pgmspace.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <string.h>
#include "global.h"
#include "debug.h"
#include "time.h"
#include "dram.h"


/*
********************************************************************************
*
* Constants
*
********************************************************************************
*/

/* Debug message configuration */
/* Messages for data bytes are switched off if defined */
#define NO_DATA_MESSAGE
/* Messages for address splitting are switched off if defined */
#undef NO_ADDR_MESSAGE

/* Use fast assembler address split routines if defined */
/* Defining this doubles the transfer rate! (GCC V3.3 with -O3) */
#define FAST_ADDR_SPLIT

/* Access mode configuration */
#define PAGE_MODE                  /* Use fast page mode */
/* Only valid if PAGE_MODE is defined. Higher values for PP_SIZE increase the
 * interrupt latency. Change only if you know what you are doing!
 * Must be a power of two, maximum value: 256 */
#define PP_SIZE  4                 /* Pseudo-page size */


/*
********************************************************************************
*
* Read from DRAM
*
* A linear address space is used. The columns of the memory array are mapped on
* the least significant address bits to take advantage of the page mode:
*                        MSB                      LSB
* 1MiByte memory modules: XXMMRRRR RRRRRRCC CCCCCCCC (22 Bits)
* 4MiByte memory modules: MMRRRRRR RRRRRCCC CCCCCCCC (24 Bits)
* (M: Module address, R: Row address, C: Column address)
*
* The access must be atomic and runs with disabled interrupts!
*
* Parameters:
* 'addr'  : Start address (must be a multiple of 256)
* 'buffer': Pointer to buffer where data should be copied to
* 'len'   : Number of bytes to read (must be a multiple of 256)
*
* Return value:
* 0              : Success
* DRAM_PAGE_ERR  : 'addr' and/or 'len' is not divisible by 256
* DRAM_PARITY_ERR: Parity error
*
********************************************************************************
*/

uint8_t  dram_read(uint32_t  addr, uint8_t*  buffer, uint16_t  len) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[DRAM] Read ";
   static const char  string1[] PROGMEM = "Bytes at address 0x";
#ifndef NO_DATA_MESSAGE
   static const char  string2[] PROGMEM = "[DRAM] Read data: 0x";
#endif
#ifndef NO_ADDR_MESSAGE
   static const char  string3[] PROGMEM = "[DRAM] Module address: 0x";
   static const char  string4[] PROGMEM = "Row address: 0x";
   static const char  string5[] PROGMEM = "Column address: 0x";
#endif
   char  sbuf2[8];                      /* Enough for %d, %06X, + \n + \0 */
   uint16_t  buf2;                      /* Temporary buffer */
#endif  /* DEBUGMASK */
   uint8_t  abw;                        /* Address bus width */
   uint16_t  index = 0;                 /* Current byte */
   register uint8_t  cal  asm("r6");    /* Address buffers */
   register uint8_t  cah  asm("r7");
   register uint8_t  ral  asm("r8");
   register uint8_t  rah  asm("r9");
   register uint8_t  cas  asm("r10");
#ifdef PAGE_MODE
   uint8_t  i;                          /* Pseudo-page index */
#endif
#ifdef FAST_ADDR_SPLIT
   register uint32_t  tmp  asm("r2");   /* Temporary buffer */
#endif
   uint8_t  buf;                        /* Temporary buffer */

#ifdef DEBUGMASK
   strcpy_P(sbuf, string0);
   sprintf(sbuf2, "%d", len);
   strcat(sbuf, sbuf2);
   strcat_P(sbuf, string1);
   sprintf(sbuf2, "%06lX\n", addr);
   strcat(sbuf, sbuf2);
   debug(5, sbuf);
#endif

   /* Configure memory module size (address bus width) */
   if (memsize == 4) abw = 10;     /* 1MiByte Modules */
   else abw = 11;                  /* 4MiByte Modules */

   /* Ensure that access starts on max. pseudo-page (256) boundary */
   if ((uint8_t) (addr & 0xFF)) return(DRAM_PAGE_ERR);

   /* Ensure that length is a multiple of max. pseudo-page (256) size */
   if ((uint8_t) (len & 0xFF)) return(DRAM_PAGE_ERR);

   /* Switch memory data bus to input mode and enable pull-ups */
   MDB = 0xFF;
   D_MDB = 0x00;

   /* Deassert /WR (read command) */
   cli();
   MAUX |= (1 << WR);
   sei();
   /* Read command setup time (0ns) */
   /* => Always expired */

   /* Read data */
   while (index != len) {
      /* Pre-calculate address parts to reduce interrupt latency */
#ifndef FAST_ADDR_SPLIT
      /* Universal address splitting for arbitrary address bus width */
      /* This can be really slow if the optimizer is lame */
      /* Column address */
      cal = (uint8_t) (addr & 0xFF);
      cah = (uint8_t) ((addr >> 8) & 0xFF);
      /* Row address */
      ral = (uint8_t) ((addr >> abw) & 0xFF);
      rah = (uint8_t) ((addr >> (abw + 8)) & 0xFF);
      /* Module address and /CAS bitmask */
      switch ((uint8_t) (addr >> (2 * abw))) {
         case 0:
            cas = (1 << CAS0);
            break;
         case 1:
            cas = (1 << CAS1);
            break;
         case 2:
            cas = (1 << CAS2);
            break;
         case 3:
            cas = (1 << CAS3);
            break;
         default:
            /* Address out of range */
            cas = 0;               /* This prevents uninitialized warning */
            fatal(4);
      }
#else
      /* Assembler address splitting
       * Works only for:
       * -> 10Bit and 11Bit address bus width
       * -> CAS0 == 4, CAS1 == 5, CAS2 == 6, CAS3 == 7 */
      tmp = addr;
      /* Get Column address */
      asm(
         "mov  %1, %A3  \n\t"      /* Get low column address 'cal' */
         "mov  %2, %B3  \n\t"      /* Get high column address 'cah' */
         "lsr  %C0      \n\t"
         "ror  %B0      \n\t"
         "lsr  %C0      \n\t"
         "ror  %B0      \n\t"
         : "=r" (tmp), "=r" (cal), "=r" (cah)
         : "0" (tmp)
      );
      /* Get row and module address */
      if (abw == 10) {
         /* 10Bit address bus width */
         asm(
            "mov  %1, %B3   \n\t"  /* Get low row address 'ral' */
            "mov  %2, %C3   \n\t"  /* Get high row address 'rah' */
            "lsr  %C0       \n\t"
            "lsr  %C0       \n\t"
            "mov  %A0, %C3  \n\t"  /* Get module address */
            : "=r" (tmp), "=r" (ral), "=r" (rah)
            : "0" (tmp)
         );
      }
      else {
         /* 11Bit address bus width */
         asm(
            "lsr  %C0       \n\t"
            "ror  %B0       \n\t"
            "mov  %1, %B3   \n\t"  /* Get low row address 'ral' */
            "mov  %2, %C3   \n\t"  /* Get high row address 'rah' */
            "lsr  %C0       \n\t"
            "lsr  %C0       \n\t"
            "lsr  %C0       \n\t"
            "mov  %A0, %C3  \n\t"  /* Get module address */
            : "=r" (tmp), "=r" (ral), "=r" (rah)
            : "0" (tmp)
         );
      }
      /* Convert module address to /CAS bitmask */
      asm(
         "mov  %0, __zero_reg__  \n\t"  /* Load 0x10 to 'cas' */
         "inc  %1                \n\t"
         "swap  %1               \n\t"
         "sbrc  %A2, 0           \n\t"  /* Shift 'cas' left  */
         "lsl  %1                \n\t"
         "sbrc  %A2, 1           \n\t"
         "lsl  %1                \n\t"
         "sbrc  %A2, 1           \n\t"
         "lsl  %1                \n\t"
         : "=r" (cas)
         : "0" (cas), "r" (tmp)
      );
#endif
#ifndef NO_ADDR_MESSAGE
#ifdef DEBUGMASK
      if (!index) {
         /* Print address parts */
         strcpy_P(sbuf, string3);
         switch (cas) {
            case 0x10: buf = 0x0; break;
            case 0x20: buf = 0x1; break;
            case 0x40: buf = 0x2; break;
            case 0x80: buf = 0x3; break;
            default: buf = 0xF;    /* Error */
         }
         sprintf(sbuf2, "%01X, ", buf);
         strcat(sbuf, sbuf2);
         debug(5, sbuf);
         strcpy_P(sbuf, string4);
         buf2 = ((uint16_t) rah << 8) | ral;
         if (abw == 10) buf2 &= 0x03FF; else buf2 &= 0x07FF;
         sprintf(sbuf2, "%03X, ", buf2);
         strcat(sbuf, sbuf2);
         debug(5, sbuf);
         strcpy_P(sbuf, string5);
         buf2 = ((uint16_t) cah << 8) | cal;
         if (abw == 10) buf2 &= 0x03FF; else buf2 &= 0x07FF;
         sprintf(sbuf2, "%03X\n", buf2);
         strcat(sbuf, sbuf2);
         debug(5, sbuf);
      }
#endif
#endif  /* NO_ADDR_MESSAGE */
      /* Shift high address bits A8, A9 and A10 left 5Bits (Hardware V1.x) */
      buf = (uint8_t) (MABH & 0x1F);
      rah = (uint8_t) (rah << 5) | buf;
      cah = (uint8_t) (cah << 5) | buf;
      /* -------------------------------------------------------------------- */
      /* First access (atomic) */
      /* Disable interrupts */
      cli();
      /* Put row address on memory address bus */
      MABL = ral;
      MABH = rah;
      /* Row address setup time (0ns) */
      /* => Always expired */
      /* Assert /RAS strobe line */
      MAUX &= (uint8_t) ~(1 << RAS);
      /* Row address hold time (10ns) */
      /* /RAS to column address delay (15ns) */
      N50SLEEP;
      /* Put column address on memory address bus */
      MABL = cal;
      MABH = cah;
      /* /RAS to /CAS delay (20ns) */
      /* Column address setup time (0ns) */
      /* => Always expired */
      /* Assert /CAS strobe line on corresponding memory module */
      MCAS &= (uint8_t) ~cas;
      /* Access time from /CAS (20ns) */
      N100SLEEP;
      /* Attention:
       * Due to synchonization the pin status of the last cycle is read! */
      /* Read byte from memory data bus */
      buffer[index] = R_MDB;
      /* /RAS hold time (20ns) */
      /* Column address to /RAS lead time (35ns) */
      /* /RAS minimum pulse width (70ns) */
      /* => Always expired */
      /* Deassert /RAS strobe line */
      MAUX |= (1 << RAS);
      /* /CAS minimum pulse width (20ns) */
      /* /CAS hold time (70ns) */
      /* => Always expired */
      /* Deassert all /CAS strobe lines */
      MCAS |= (uint8_t) ((1 << CAS0) | (1 << CAS1) | (1 << CAS2) | (1 << CAS3));
      /* /CAS to /RAS precharge time (5ns) */
      /* /RAS precharge time (50ns) */
      /* => Will always expire in time */
      /* Enable interrupts */
      sei();
#ifndef NO_DATA_MESSAGE
#ifdef DEBUGMASK
      /* Print read data */
      strcpy_P(sbuf, string2);
      sprintf(sbuf2, "%02X\n", buffer[index]);
      strcat(sbuf, sbuf2);
      debug(5, sbuf);
#endif
#endif  /* NO_DATA_MESSAGE */
      /* -------------------------------------------------------------------- */
      index++;
      addr++;
      /* All interrupt handlers got the chance to be executed now */
#ifdef PAGE_MODE
      /* -------------------------------------------------------------------- */
      /* Page mode access (atomic, speed optimized) */
      /* Disable interrupts */
      cli();
      /* Put row address on memory address bus */
      MABL = ral;
      MABH = rah;
      /* Row address setup time (0ns) */
      /* => Always expired */
      /* Assert /RAS strobe line */
      MAUX &= (uint8_t) ~(1 << RAS);
      /* Row address hold time (10ns) */
      /* /RAS to column address delay (15ns) */
      N50SLEEP;
      /* Put column address on memory address bus */
      MABH = cah;
      /* /RAS to /CAS delay (20ns) */
      /* => Will always expire in time */
      for (i = 0; i < PP_SIZE - 1; i ++) {
         /* Put column address on memory address bus */
         MABL = ++cal;
         /* Column address setup time (0ns) */
         /* => Always expired */
         /* Assert /CAS strobe line on corresponding memory module */
         MCAS &= (uint8_t) ~cas;
         /* Access time from /CAS (20ns) */
         N100SLEEP;
         /* Attention:
          * Due to synchonization the pin status of the last cycle is read! */
         /* Read byte from memory data bus */
         buffer[index++] = R_MDB;
         /* /CAS minimum pulse width (20ns) */
         /* /CAS hold time (70ns) */
         /* => Always expired */
         /* Deassert all /CAS strobe lines */
         MCAS |= (uint8_t)
          ((1 << CAS0) | (1 << CAS1) | (1 << CAS2) | (1 << CAS3));
         /* /CAS precharge time (10ns) */
         /* => Will always expire in time */
      }
      /* /RAS hold time from /CAS precharge in page mode (45ns) */
      /* => Always expired */
      /* Deassert /RAS strobe line */
      MAUX |= (1 << RAS);
      /* Enable interrupts */
      sei();
#ifndef NO_DATA_MESSAGE
#ifdef DEBUGMASK
      /* Print read data */
      strcpy_P(sbuf, string2);
      sprintf(sbuf2, "%02X\n", buffer[index - 3]);
      strcat(sbuf, sbuf2);
      debug(5, sbuf);
      strcpy_P(sbuf, string2);
      sprintf(sbuf2, "%02X\n", buffer[index - 2]);
      strcat(sbuf, sbuf2);
      debug(5, sbuf);
      strcpy_P(sbuf, string2);
      sprintf(sbuf2, "%02X\n", buffer[index - 1]);
      strcat(sbuf, sbuf2);
      debug(5, sbuf);
#endif
#endif  /* NO_DATA_MESSAGE */
      /* -------------------------------------------------------------------- */
      addr += PP_SIZE - 1;
#endif  /* PAGE_MODE */
      /* /CAS to /RAS precharge time (5ns) */
      /* /RAS precharge time (50ns) */
      /* => Will always expire in time */
   }
   return(0);
}


/*
********************************************************************************
*
* Write to DRAM
*
* A linear address space is used. The columns of the memory array are mapped on
* the least significant address bits to take advantage of the page mode:
*                        MSB                      LSB
* 1MiByte memory modules: XXMMRRRR RRRRRRCC CCCCCCCC (22 Bits)
* 4MiByte memory modules: MMRRRRRR RRRRRCCC CCCCCCCC (24 Bits)
* (M: Module number, R: Row address, C: Column address)
*
* The access must be atomic and runs with disabled interrupts!
*
* Parameters:
* 'addr'  : Start address
* 'buffer': Pointer to buffer where data should be read from
* 'len'   : Number of bytes to write
*
* Return value:
* 0              : Success
* DRAM_PAGE_ERR  : 'addr' and/or 'len' is not divisible by 256
* DRAM_PARITY_ERR: Parity error
*
********************************************************************************
*/

uint8_t  dram_write(uint32_t  addr, uint8_t*  buffer, uint16_t  len) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[DRAM] Write ";
   static const char  string1[] PROGMEM = "Bytes at address 0x";
#ifndef NO_DATA_MESSAGE
   static const char  string2[] PROGMEM = "[DRAM] Write data: 0x";
#endif
#ifndef NO_ADDR_MESSAGE
   static const char  string3[] PROGMEM = "[DRAM] Module address: 0x";
   static const char  string4[] PROGMEM = "Row address: 0x";
   static const char  string5[] PROGMEM = "Column address: 0x";
#endif
   char  sbuf2[8];                      /* Enough for %d, %06X, + \n + \0 */
   uint16_t  buf2;                      /* Temporary buffer */
#endif  /* DEBUGMASK */
   uint8_t  abw;                        /* Address bus width */
   uint16_t  index = 0;                 /* Current byte */
   register uint8_t  cal  asm("r6");    /* Address buffers */
   register uint8_t  cah  asm("r7");
   register uint8_t  ral  asm("r8");
   register uint8_t  rah  asm("r9");
   register uint8_t  cas  asm("r10");
#ifdef PAGE_MODE
   uint8_t  i;                          /* Pseudo-page index */
#endif
#ifdef FAST_ADDR_SPLIT
   register uint32_t  tmp  asm("r2");   /* Temporary buffer */
#endif
   uint8_t  buf;                        /* Temporary buffer */

#ifdef DEBUGMASK
   strcpy_P(sbuf, string0);
   sprintf(sbuf2, "%d", len);
   strcat(sbuf, sbuf2);
   strcat_P(sbuf, string1);
   sprintf(sbuf2, "%06lX\n", addr);
   strcat(sbuf, sbuf2);
   debug(5, sbuf);
#endif

   /* Configure memory module size (address bus width) */
   if (memsize == 4) abw = 10;     /* 1MiByte Modules */
   else abw = 11;                  /* 4MiByte Modules */

   /* Ensure that access starts on max. pseudo-page (256) boundary */
   if ((uint8_t) (addr & 0xFF)) return(DRAM_PAGE_ERR);

   /* Ensure that length is a multiple of max. pseudo-page (256) size */
   if ((uint8_t) (len & 0xFF)) return(DRAM_PAGE_ERR);

   /* Switch memory data bus to output mode */
   D_MDB = 0xFF;

   /* Write data */
   while (index != len) {
      /* Pre-calculate address parts to reduce interrupt latency */
#ifndef FAST_ADDR_SPLIT
      /* Universal address splitting for arbitrary address bus width */
      /* This can be really slow if the optimizer is lame */
      /* Column address */
      cal = (uint8_t) (addr & 0xFF);
      cah = (uint8_t) ((addr >> 8) & 0xFF);
      /* Row address */
      ral = (uint8_t) ((addr >> abw) & 0xFF);
      rah = (uint8_t) ((addr >> (abw + 8)) & 0xFF);
      /* Module address and /CAS bitmask */
      switch ((uint8_t) (addr >> (2 * abw))) {
         case 0:
            cas = (1 << CAS0);
            break;
         case 1:
            cas = (1 << CAS1);
            break;
         case 2:
            cas = (1 << CAS2);
            break;
         case 3:
            cas = (1 << CAS3);
            break;
         default:
            /* Address out of range */
            cas = 0;               /* This prevents uninitialized warning */
            fatal(4);
      }
#else
      /* Assembler address splitting
       * Works only for:
       * -> 10Bit and 11Bit address bus width
       * -> CAS0 == 4, CAS1 == 5, CAS2 == 6, CAS3 == 7 */
      tmp = addr;
      /* Get Column address */
      asm(
         "mov  %1, %A3  \n\t"      /* Get low column address 'cal' */
         "mov  %2, %B3  \n\t"      /* Get high column address 'cah' */
         "lsr  %C0      \n\t"
         "ror  %B0      \n\t"
         "lsr  %C0      \n\t"
         "ror  %B0      \n\t"
         : "=r" (tmp), "=r" (cal), "=r" (cah)
         : "0" (tmp)
      );
      /* Get row and module address */
      if (abw == 10) {
         /* 10Bit address bus width */
         asm(
            "mov  %1, %B3   \n\t"  /* Get low row address 'ral' */
            "mov  %2, %C3   \n\t"  /* Get high row address 'rah' */
            "lsr  %C0       \n\t"
            "lsr  %C0       \n\t"
            "mov  %A0, %C3  \n\t"  /* Get module address */
            : "=r" (tmp), "=r" (ral), "=r" (rah)
            : "0" (tmp)
         );
      }
      else {
         /* 11Bit address bus width */
         asm(
            "lsr  %C0       \n\t"
            "ror  %B0       \n\t"
            "mov  %1, %B3   \n\t"  /* Get low row address 'ral' */
            "mov  %2, %C3   \n\t"  /* Get high row address 'rah' */
            "lsr  %C0       \n\t"
            "lsr  %C0       \n\t"
            "lsr  %C0       \n\t"
            "mov  %A0, %C3  \n\t"  /* Get module address */
            : "=r" (tmp), "=r" (ral), "=r" (rah)
            : "0" (tmp)
         );
      }
      /* Convert module address to /CAS bitmask */
      asm(
         "mov  %0, __zero_reg__  \n\t"  /* Load 0x10 to 'cas' */
         "inc  %1                \n\t"
         "swap  %1               \n\t"
         "sbrc  %A2, 0           \n\t"  /* Shift 'cas' left  */
         "lsl  %1                \n\t"
         "sbrc  %A2, 1           \n\t"
         "lsl  %1                \n\t"
         "sbrc  %A2, 1           \n\t"
         "lsl  %1                \n\t"
         : "=r" (cas)
         : "0" (cas), "r" (tmp)
      );
#endif
#ifndef NO_ADDR_MESSAGE
#ifdef DEBUGMASK
      if (!index) {
         /* Print address parts */
         strcpy_P(sbuf, string3);
         switch (cas) {
            case 0x10: buf = 0x0; break;
            case 0x20: buf = 0x1; break;
            case 0x40: buf = 0x2; break;
            case 0x80: buf = 0x3; break;
            default: buf = 0xF;    /* Error */
         }
         sprintf(sbuf2, "%01X, ", buf);
         strcat(sbuf, sbuf2);
         debug(5, sbuf);
         strcpy_P(sbuf, string4);
         buf2 = ((uint16_t) rah << 8) | ral;
         if (abw == 10) buf2 &= 0x03FF; else buf2 &= 0x07FF;
         sprintf(sbuf2, "%03X, ", buf2);
         strcat(sbuf, sbuf2);
         debug(5, sbuf);
         strcpy_P(sbuf, string5);
         buf2 = ((uint16_t) cah << 8) | cal;
         if (abw == 10) buf2 &= 0x03FF; else buf2 &= 0x07FF;
         sprintf(sbuf2, "%03X\n", buf2);
         strcat(sbuf, sbuf2);
         debug(5, sbuf);
      }
#endif
#endif  /* NO_ADDR_MESSAGE */
      /* Shift high address bits A8, A9 and A10 left 5Bits (Hardware V1.x) */
      buf = (uint8_t) (MABH & 0x1F);
      rah = (uint8_t) (rah << 5) | buf;
      cah = (uint8_t) (cah << 5) | buf;
      /* -------------------------------------------------------------------- */
      /* First access (atomic) */
#ifndef NO_DATA_MESSAGE
#ifdef DEBUGMASK
      /* Print write data */
      strcpy_P(sbuf, string2);
      sprintf(sbuf2, "%02X\n", buffer[index]);
      strcat(sbuf, sbuf2);
      debug(5, sbuf);
#endif
#endif  /* NO_DATA_MESSAGE */
      /* Disable interrupts */
      cli();
      /* Put row address on memory address bus */
      MABL = ral;
      MABH = rah;
      /* Row address setup time (0ns) */
      /* => Always expired */
      /* Assert /RAS strobe line */
      MAUX &= (uint8_t) ~(1 << RAS);
      /* Assert /WR line (write command) */
      MAUX &= (uint8_t) ~(1 << WR);
      /* Row address hold time (10ns) */
      /* /RAS to column address delay (15ns) */
      /* => Always expired */
      /* Put column address on memory address bus */
      MABL = cal;
      MABH = cah;
      /* Put byte on memory data bus */
      MDB = buffer[index];
      /* /RAS to /CAS delay (20ns) */
      /* Column address setup time (0ns) */
      /* Write command (/WR to /CAS) setup time (0ns) */
      /* Data setup time (0ns) */
      /* => Always expired */
      /* Assert /CAS strobe line on corresponding memory module */
      MCAS &= (uint8_t) ~cas;
      /* /RAS hold time (20ns) */
      /* Column address to /RAS lead time (35ns) */
      N50SLEEP;
      /* Deassert /RAS strobe line */
      MAUX |= (1 << RAS);
      /* /CAS hold time (70ns) */
      /* Write command to /CAS lead time (20ns) */
      /* /CAS minimum pulse width (20ns) */
      /* => Always expired */
      /* Deassert all /CAS strobe lines */
      MCAS |= (uint8_t) ((1 << CAS0) | (1 << CAS1) | (1 << CAS2) | (1 << CAS3));
      /* Write command minimum pulse width (15ns) */
      /* Write command hold time (15ns) */
      /* => Always expired */
      /* Deassert /WR line */
      MAUX |= (1 << WR);
      /* /CAS to /RAS precharge time (5ns) */
      /* /RAS precharge time (50ns) */
      /* => Will always expire in time */
      /* Enable interrupts */
      sei();
      /* -------------------------------------------------------------------- */
      index++;
      addr++;
      /* All interrupt handlers got the chance to be executed now */
#ifdef PAGE_MODE
      /* -------------------------------------------------------------------- */
      /* Page mode access (atomic, speed optimized) */
#ifndef NO_DATA_MESSAGE
#ifdef DEBUGMASK
      /* Print write data */
      strcpy_P(sbuf, string2);
      sprintf(sbuf2, "%02X\n", buffer[index]);
      strcat(sbuf, sbuf2);
      debug(5, sbuf);
      strcpy_P(sbuf, string2);
      sprintf(sbuf2, "%02X\n", buffer[index + 1]);
      strcat(sbuf, sbuf2);
      debug(5, sbuf);
      strcpy_P(sbuf, string2);
      sprintf(sbuf2, "%02X\n", buffer[index + 2]);
      strcat(sbuf, sbuf2);
      debug(5, sbuf);
#endif
#endif  /* NO_DATA_MESSAGE */
      /* Disable interrupts */
      cli();
      /* Put row address on memory address bus */
      MABL = ral;
      MABH = rah;
      /* Row address setup time (0ns) */
      /* => Always expired */
      /* Assert /RAS strobe line */
      MAUX &= (uint8_t) ~(1 << RAS);
      /* Row address hold time (10ns) */
      /* /RAS to column address delay (15ns) */
      /* => Always expired */
      /* /WR setup time (0ns) */
      /* => Always expired */
      /* Assert /WR line (write command) */
      MAUX &= (uint8_t) ~(1 << WR);
      /* Put column address on memory address bus */
      MABH = cah;
      /* /RAS to /CAS delay (20ns) */
      /* => Will always expire in time */
      for (i = 0; i < PP_SIZE - 1; i ++) {
         /* Put column address on memory address bus */
         MABL = ++cal;
         /* Put byte on memory data bus */
         MDB = buffer[index++];
         /* Column address setup time (0ns) */
         /* Data setup time (0ns) */
         /* => Always expired */
         /* Assert /CAS strobe line on corresponding memory module */
         MCAS &= (uint8_t) ~cas;
         /* Write command to /CAS lead time (20ns) */
         /* /CAS minimum pulse width (20ns) */
         /* /CAS hold time (70ns) */
         N50SLEEP;
         /* Deassert all /CAS strobe lines */
         MCAS |= (uint8_t)
          ((1 << CAS0) | (1 << CAS1) | (1 << CAS2) | (1 << CAS3));
         /* /CAS precharge time (10ns) */
         /* => Will always expire in time */
      }
      /* Deassert /RAS strobe line */
      MAUX |= (1 << RAS);
      /* Write command minimum pulse width (15ns) */
      /* Write command hold time (15ns) */
      /* => Always expired */
      /* Deassert /WR line */
      MAUX |= (1 << WR);
      /* Enable interrupts */
      sei();
      /* -------------------------------------------------------------------- */
      addr += PP_SIZE - 1;
#endif  /* PAGE_MODE */
      /* /CAS to /RAS precharge time (5ns) */
      /* /RAS precharge time (50ns) */
      /* => Will always expire in time */
   }

   /* Switch memory data bus to input mode and enable pull-ups */
   MDB = 0xFF;
   D_MDB = 0x00;
   return(0);
}


/*
********************************************************************************
*
* Determine the DRAM size
*
* Attention:
* Checks only the first DRAM module. It is expected that 4 modules of the same
* type are present and the full memory size of all 4 modules is returned.
* Determining whether the other modules are missing is the job of a separate
* DRAM test routine and _NOT_ done here!
*
* Return value: DRAM size in MiByte (0 if no memory is found)
*
********************************************************************************
*/

uint8_t  dram_get_size(void) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[DRAM] Value from module: 0x";
   char  sbuf2[4];                 /* Enough for %02X, + \n + \0 */
#endif
   uint8_t  rv;
   uint8_t  buffer[256];

   /* Init 'memsize' to let DRAM access routines assume 11Bit address bus */
   memsize = 16;
   /* ----------------------------------------------------------------------- */
   /* Check for first module is present */
   buffer[0] = 0x00;
   /* Write 0x00 to first byte */
   rv = dram_write(0, buffer, 256);
   if (rv) return(0);                   /* Check for write error */
   /* Paranoia: Set buffer to something not expected */
   buffer[0] = 0x55;
   /* Read first byte */
   rv = dram_read(0, buffer, 256);
   if (rv) return(0);                   /* Check for read error */
#ifdef DEBUGMASK
   /* Print data */
   strcpy_P(sbuf, string0);
   sprintf(sbuf2, "%02X\n", buffer[0]);
   strcat(sbuf, sbuf2);
   debug(5, sbuf);
#endif
   /* Pullups force 0xFF if no module is present */
   if (buffer[0] != 0x00) return(0);    
   /* ----------------------------------------------------------------------- */
   /* First module found => Check whether it is a 1 or 4MiByte module */
   /* Write 0x99 on first module using row address 0x000 */
   buffer[0] = 0x99;
   rv = dram_write(0x00000000, buffer, 256);
   if (rv) return(0);                   /* Check for write error */
   /* Write 0xAA on first module using row address 0x200 */
   buffer[0] = 0xAA;
   rv = dram_write(0x00100000, buffer, 256);
   /* Write 0x55 on first module using row address 0x400 */
   buffer[0] = 0x55;
   rv = dram_write(0x00200000, buffer, 256);
   if (rv) return(0);                   /* Check for write error */
   /* Note:
    * A 256KiByte module only have 9 row address bits
    * A 1MiByte module only have 10 row address bits
    * Therefore (check row address mapping!) the value in Row 0 gets overwritten
    * => The value in row 0 & 1 will now be read as 0x55 for a 256KiByte module
    * => The value in row 0 will now be read as 0x55 for a 1MiByte module */
   /* Paranoia: Set buffer to something not expected */
   buffer[0] = 0xFF;
   /* Try to read back the 0xAA using row address 0x200 */
   rv = dram_read(0x00100000, buffer, 256);
   if (rv) return(0);                   /* Check for read error */
#ifdef DEBUGMASK
   /* Print data */
   strcpy_P(sbuf, string0);
   sprintf(sbuf2, "%02X\n", buffer[0]);
   strcat(sbuf, sbuf2);
   debug(5, sbuf);
#endif
   /* If the 0xAA was overwritten, the module size is smaller than 1MiByte */
   /* => Such modules are currently not supported */
   if (buffer[0] != 0xAA) return(0);
   /* Try to read back the 0x99 using row address 0x000 */
   rv = dram_read(0x00000000, buffer, 256);
   if (rv) return(0);                   /* Check for read error */
#ifdef DEBUGMASK
   /* Print data */
   strcpy_P(sbuf, string0);
   sprintf(sbuf2, "%02X\n", buffer[0]);
   strcat(sbuf, sbuf2);
   debug(5, sbuf);
#endif
   /* If the 0x99 was overwritten, the module size is 1MiByte */
   if (buffer[0] != 0x99) return(4);
   /* If the 0x99 is still there we have a 4MiByte module */
   return(16);
}


/* EOF */
