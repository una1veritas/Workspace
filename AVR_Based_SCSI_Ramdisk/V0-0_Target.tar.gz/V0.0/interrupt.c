/*
********************************************************************************
*
* Header
*  
* Project:      SCSI controller
*
* Module:       Target
* File:         interrupt.c
* 		 		 
* Language:     C
* 
* Description:  Interrupt handlers
* 
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler:   gcc (Version 3.3)
*               Platform:   AVR
*               OS:         none
* Tested with:  Compiler:   gcc (Version 3.3)
*               Platform:   SCSI RAM-disk Hardware V1.0.1 (ATmega64)
*               OS:         none
* Do not work:  -
* 
* 
* Changelog:    2004-10-24  Michael Baeuerle
*               Unexpected interrupt handler added
* 
*               2004-11-06  Michael Baeuerle
*               System timer variable 'sys_timer' added
*               Timer1 compare match A interrupt handler added (System timer)
* 
*               2005-05-28  Michael Baeuerle
*               USART0 UDRE interrupt handler added
* 
*               2005-06-25  Michael Baeuerle
*               Timer0 compare match interrupt handler added (DRAM refresh)
*               Variable 'sys_timer' moved to 'time.c'
* 
*               2005-06-30  Michael Baeuerle
*               Timer0 compare match interrupt handler rewritten in assembler
* 
*               2005-07-03  Michael Baeuerle
*               Bugfix: Timer0 compare match interrupt handler cannot use
*                register variable because this will break linked libc code
*                => Use same static global variable as the C code
* 
*               2005-07-06  Michael Baeuerle
*               Moved code from Timer0 compare match interrupt handler to Timer2
*                compare match interrupt handler (higher priority)
*               Bugfix: DRAM refresh: Assembler code register usage fixed
*               DRAM RAS-only refresh assembler code is now 1 cycle faster
* 
*               2005-07-12  Michael Baeuerle
*               Bugfix: DRAM refresh: High address bus was not set correctly
*
* 
* To do:        Implement CBR refresh (will consume less CPU power)
* 
********************************************************************************
*/

/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include "global.h"
#include "debug.h"
#include "time.h"
#include "interrupt.h"


/*
********************************************************************************
*
* Constants
*
********************************************************************************
*/

#define  FAST_RAS_ONLY_REFRESH


/*
********************************************************************************
*
* Variables
*
********************************************************************************
*/

static uint16_t  refresh_counter;


/*
********************************************************************************
*
* Forward declarations
*
********************************************************************************
*/

SIGNAL(__vector_default) __attribute__ ((naked));
#ifdef FAST_RAS_ONLY_REFRESH
/* Strip T0 compare match interrupt handler for GCC assembler hack */
SIGNAL(SIG_OUTPUT_COMPARE2) __attribute__ ((naked));
#endif
extern uint8_t  usart0_tx_buffer_read(char*);  /* => Look at 'debug.c' */


/*
********************************************************************************
*
* Unexpected interrupt handler
*
* 'fatal()' must never return!
*
********************************************************************************
*/

SIGNAL(__vector_default) {
   fatal(0);
}


/*
********************************************************************************
*
* Timer1 compare match A interrupt handler
*
* Increment the system timer every milisecond
*
********************************************************************************
*/

SIGNAL(SIG_OUTPUT_COMPARE1A) {
   sys_timer++;
}


/*
********************************************************************************
*
* Timer2 compare match interrupt handler
*
* Execute DRAM refresh (RAS-only refresh designed for "512rows @8ms")
* The timings are taken from the Siemens HYB511000B datasheet
*
* Note:
* Because this implementation uses the "cycle stealing" technique (constant
* refresh interval), the refresh counter is incremented up to the 16Bit integer
* overflow and the memory address bus is driven with all 11Bits, it should be
* able to refresh memory chips with more than 512 rows if the following timings
* are sufficiant: "1024rows @16ms" or "2048rows @32ms"
* => This may be required for 4MiByte memory modules
*
* This interrupt handler is called every 12.5us for refreshing one row (the rest
* of the time is the security margin)
* => Refresh period of 6.4ms nominal
*
* Maximum allowed interrupt latency: 12us - runtime of this interrupt handler
*                                    => 10us (160 core cycles @16MHz)
*
********************************************************************************
*/

SIGNAL(SIG_OUTPUT_COMPARE2) {
#ifndef FAST_RAS_ONLY_REFRESH
   /* This is portable but will create 45% CPU load @16MHz (using GCC V3.3) */
   /* Put refresh address on memory address bus */
   MABH &= 0x1F;
   MABH |= (uint8_t) ((refresh_counter & 0xFF00) >> 3);
   MABL = (uint8_t) (refresh_counter & 0x00FF);
   /* Address setup time (0ns) */
   /* => Will expire before /RAS access */
   /* Assert /RAS */
   MAUX &= (uint8_t) ~(1 << RAS);
   /* Increment refresh counter (takes >100ns @16MHz) */
   refresh_counter++;
   /* /RAS minimum pulse width (70ns) */
   /* => Already expired */
   /* Deassert /RAS */
   MAUX |= (1 << RAS);
   /* /RAS precharge time (50ns) */
   /* => Will expire while returning from interrupt */
#else
   /* This reduces the CPU load to 23% @16MHz */
   asm volatile(
      /* Save context */
      "push  __tmp_reg__          \n\t"
      "in  __tmp_reg__, __SREG__  \n\t"
      "push  30                   \n\t"
      "push  31                   \n\t"
      : :
   );
   asm volatile(
      /* Put refresh address on memory address bus */
      "lds  31, refresh_counter + 1  \n\t"
      "swap  31                      \n\t"
      "lsl  31                       \n\t"
      "andi  31, 0xE0                \n\t"
      "in   30, %0                   \n\t"
      "andi  30, 0x1F                \n\t"
      "or  31, 30                    \n\t"
      "out  %0, 31                   \n\t"
      "lds  30, refresh_counter      \n\t"
      "out  %1, 30                   \n\t"
      /* Increment refresh counter */
      "lds  31, refresh_counter + 1  \n\t"
      "adiw  30, 1                   \n\t"
      "sts  refresh_counter, 30      \n\t"
      "sts  refresh_counter + 1, 31  \n\t"
      : : "I" (_SFR_IO_ADDR(MABH)), "I" (_SFR_IO_ADDR(MABL))
   );
   asm volatile(
      /* Address setup time (0ns) */
      /* => Always expired */
      /* Assert /RAS */
      "lds  30, %0  \n\t"
      "cbr  30, %1  \n\t"
      "sts  %0, 30  \n\t"
      /* /RAS minimum pulse width (70ns) */
      /* => Will expire in time */
      /* Deassert /RAS */
      "sbr  30, %1  \n\t"
      "sts  %0, 30  \n\t"
      /* /RAS precharge time (50ns) */
      /* => Will expire while returning from interrupt */
      : : "M" (_SFR_MEM_ADDR(MAUX)), "M" (1 << RAS)
   );
   asm volatile(
      /* Restore context and return from interrupt */
      "pop  31                     \n\t"
      "pop  30                     \n\t"
      "out  __SREG__, __tmp_reg__  \n\t"
      "pop  __tmp_reg__            \n\t"
      "reti                        \n\t"
      : :
   );
   /* To prevent 'defined but not used' warning (never executed) */
   refresh_counter = 0;
#endif
}


/*
********************************************************************************
*
* USART0 UDRE interrupt handler
*
* Reads on byte from the data buffer and write it to the USART
*
********************************************************************************
*/

#ifdef DEBUGMASK
SIGNAL(SIG_UART0_DATA) {
   char  buf;
   
   if (usart0_tx_buffer_read(&buf)) {
      /* Buffer empty => Mask USART0 UDRE interrupt */
      UCSR0B &= (uint8_t) ~(1 << UDRIE);
   }
   else {
      /* Copy data byte from buffer to USART0 */
      UDR0 = buf;
   }
}
#endif


/* EOF */
