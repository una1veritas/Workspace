/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         time.c
*
* Language:     C
*
* Description:  General purpose timing routines
*               These routines will only work for 16MHz core clock!
*
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc (Version 3.3)
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
*
* Changelog:    2004-11-06  Michael Baeuerle
*               ANSI compatible 'clock()' routine added
* 
*               2005-06-25  Michael Baeuerle
*               System timer variable 'sys_timer' added
* 
*               2005-07-09  Michael Baeuerle
*               'clock()': Restore previous interrupt status before exit
*
*
* To do:        -
*
********************************************************************************
*/


/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include <avr/interrupt.h>
#include "global.h"
#include "unistd.h"
#include "time.h"


/*
********************************************************************************
*
* Global variables
*
********************************************************************************
*/

volatile clock_t  sys_timer = 0;   /* System timer */


/*
********************************************************************************
*
* Get CPU time for process
*
* This simply returns the current system timer value and therefore only works
* for singletasking systems
*
* Attention: Interrupts are enabled on return!
*
********************************************************************************
*/

inline clock_t  clock(void) {
   clock_t  st;
   uint8_t  sreg;
   
   /* Store interrupt status */
   sreg = SREG;
   /* Disable interrupts to make system timer access atomic */
   cli();
   st = sys_timer;
   /* Restore interrupt status */
   SREG = sreg;
   return(st);
}


/*
********************************************************************************
*
* Microsecond delay routine (interruptable)
*
* For general purpose low accuracy timing
* Very inaccurate (too long) for small values because call, return and loop
* setup times are not taken into account
*
* Parameter:
* 'usecs': Time in microseconds
*
********************************************************************************
*/

void  usleep(unsigned long  usecs) {
   uint32_t  i;
   
   /* The loop itself takes 10 cycles */
   for (i = 0; i < usecs; i ++) {
      N100SLEEP;
      N100SLEEP;
      N100SLEEP;
   }
   return;
}


/*
********************************************************************************
*
* Check for timeout
*
* System timer resolution must be 1ms or better
* 'clock_t' must be unsigned and at least 32Bit
*
* Parameters:
* 'start'  : The time from which the timeout should be calculated
*            Use 'clock()' to get this value
* 'timeout': The timeout in miliseconds
*
* Return values:
* 0: Time still running
* 1: Timeout
*
********************************************************************************
*/

uint8_t  timeout(clock_t  start, uint16_t  timeout) {
   clock_t  ref = start;
   clock_t  now = clock();
   clock_t  x = 0;
   
   /* Check for system timer overflow */
   if (now < ref) {
      /* Shift values so that timer boundary is not crossed */
      x = ~x;                      /* This gives the timer boundary */
      now += x - ref;
      ref = 0;
   }
   /* Check for timeout */
   if ((now - ref) > ((uint32_t) timeout * (CLOCKS_PER_SEC / 1000)))
      return(1); else return(0);
}


/*
********************************************************************************
*
* Second delay routine (interruptable)
*
* System timer based
*
* Parameter:
* 'secs': Time in seconds (Attention: 'secs' * 1000 must fit in 'uint16_t'!)
*
* Returns always zero
*
********************************************************************************
*/

uint16_t  sleep(uint16_t  secs) {
   clock_t  start;
   
   start = clock();
   while (!timeout(start, secs * 1000));
   return(0);
}


/* EOF */
