/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         inquiry.h
*
* Language:     C
*
* Description:  INQUIRY data
*
* Copyright:    (C) 2005 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
* Changelog:    2005-06-12  Michael Baeuerle
*               Inquiry data for LUN 0 added
*               Inquiry data for nonexistent LUNs added
*
*
* To do:        -
*
********************************************************************************
*/

#ifndef _INQUIRY_H
#define _INQUIRY_H  1


/*
********************************************************************************
*
* Constants
*
********************************************************************************
*/

const  uint8_t  lun0_inquiry[] PROGMEM = {
   0x00,  /* LUN exist, device class = "Direct-access" */
   0x00,  /* Medium not removable */
   0x03,  /* SCSI3 (ANSI X3.301:1997) */
   0x02,  /* No normal ACA, SCSI2/SCSI3 compliant response data format */
   0x1F,  /* 31 Bytes following */
   0x00,  /* Reserved */
   0x00,  /* No Enclosure service, no Multiport, no Medium changer */
   0x00,  /* No Wide, Sync, Link and TCQ support */
   'S',   /* Vendor sting */
   'e',
   'l',
   'f',
   'm',
   'a',
   'd',
   'e',
   'R',   /* Product string */
   'A',
   'M',
   '-',
   'D',
   'i',
   's',
   'k',
   ' ',
   ' ',
   ' ',
   ' ',
   ' ',
   ' ',
   ' ',
   ' ',
   'V',   /* Revision string */
   '1',
   '.',
   '0'
};

const  uint8_t  lunx_inquiry[] PROGMEM = {
   0x7F,  /* LUN does not exist, device class = "Unknown device" */
   0x00,  /* Medium not removable */
   0x00,  /* No standard */
   0x00,  /* No normal ACA, no standard response data */
   0x00   /* 0 Bytes following */
};


#endif
/* EOF */
