/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         debug.h
*
* Language:     C
*
* Description:  Debug subsystem header file
*
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
* Changelog:    2004-11-06  Michael Baeuerle
*               Prototype for 'debug()' added
*               Macro 'DEBUG()' added
*
*               2005-05-26  Michael Baeuerle
*               Constant 'ADD_CR' added
*
*               2005-06-05  Michael Baeuerle
*               Macro 'STRCPY_P()' added
*
*               2005-06-05  Michael Baeuerle
*               Variable 'sbuf' added
*
*               2005-06-25  Michael Baeuerle
*               Constant 'DEBUGMASK' added
*
* To do:        -
*
********************************************************************************
*/

#ifndef _DEBUG_H
#define _DEBUG_H  1


/*
********************************************************************************
*
* Global constants
*
********************************************************************************
*/

/* Print debugging messages on USART0 */
/*
DEBUGMASK (You can set one or more bits to enable the messages of the
appropriate debug levels):
--------------------------------------------------------------------------------
Undef: Debbuging disabled (code removed)
0x00 : Level 0: No debug info (but code present)
--------------------------------------------------------------------------------
1    : Level 1: POST (Power on self test) and configuration
                Note: Recommended
2    : Level 2: PIA driver (Parallel interface agent driver)
4    : Level 3: Taskrouter (SIP protocol handler)
                Note: Nexus, status and message information, recommended
8    : Level 4: LUN 0 (Logical unit 0 taskmanager and deviceserver)
                Note: This includes information for tasks of nonexisting LUNs
16   : Level 5: DRAM access
32   : Level 6: Logical block transfer
64   : Unused
128  : Unused
--------------------------------------------------------------------------------
*/
#define DEBUGMASK  0x2D            /* This is a good starting point */
#undef DEBUGMASK                   /* Remove this to enable debug system */

/* Define this if your terminal want to see CRs */
#define ADD_CR                     /* Add carriage return after linefeed */


/*
********************************************************************************
*
* Global variables
*
********************************************************************************
*/

#ifdef DEBUGMASK
extern char  sbuf[80];             /* Buffer for debug messages */
#endif


/*
********************************************************************************
*
* Macros
*
* These macros should reduce the occurrence of '#ifdef' in the source
*
********************************************************************************
*/

#ifdef DEBUGMASK
#   define DEBUG(level, string)  debug(level, string)
#else
#   define DEBUG(level, string)
#endif

#ifdef DEBUGMASK
#   define STRCPY_P(target, source)  strcpy_P(target, source)
#else
#   define STRCPY_P(target, source)
#endif


/*
********************************************************************************
*
* Forward declarations
*
********************************************************************************
*/

#ifdef DEBUGMASK
extern void  debug(int, char*);
#endif


#endif
/* EOF */
