/*
********************************************************************************
*
* Header
*  
* Project:      SCSI controller
*
* Module:       Target
* File:         interrupt.h
* 
* Language:     C
* 
* Description:  Interrupt handler specific header file
* 
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Platform:   AVR
*               OS:         none
* Tested with:  Compiler:   gcc (Version 3.3)
*               Platform:   ATmega64
*               OS:         none
* Do not work:  -
* 
* 
* Changelog:    2004-11-06  Michael Baeuerle
*               Variable 'sys_timer' added
*               Constant 'TPS' added
*               Macro 'N100SLEEP' added
* 
*               2005-05-26  Michael Baeuerle
*               Type definition for 'clock_t' added
*               Macro 'N100SLEEP' moved to 'time.h'
*
*               2005-06-25  Michael Baeuerle
*               Variable 'sys_timer' moved to 'time.h'
* 
* To do:        -
* 
********************************************************************************
*/

#ifndef _ISR_H
#define _ISR_H  1


/*
********************************************************************************
*
* Type definitions
*
********************************************************************************
*/

typedef uint32_t  clock_t;


/*
********************************************************************************
*
* Global constants
*
********************************************************************************
*/

#define TPS  1000                  /* System timer ticks per second */


#endif
/* EOF */

