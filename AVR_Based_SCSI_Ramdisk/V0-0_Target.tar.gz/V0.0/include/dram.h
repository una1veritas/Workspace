/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         dram.h
*
* Language:     C
*
* Description:  DRAM access header file
*
* Copyright:    (C) 2005 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
* Changelog:    2005-07-01  Michael Baeuerle
*               Prototype for 'dram_read()' added
*               Prototype for 'dram_write()' added
*
*               2005-07-08  Michael Baeuerle
*               Constants 'DRAM_PAGE_ERR' and 'DRAM_PARITY_ERR' added
*
*               2005-07-09  Michael Baeuerle
*               Prototype for 'dram_get_size()' added
*
*
* To do:        -
*
********************************************************************************
*/

#ifndef _DRAM_H
#define _DRAM_H  1


/*
********************************************************************************
*
* Constants
*
********************************************************************************
*/

#define DRAM_PAGE_ERR    1
#define DRAM_PARITY_ERR  2


/*
********************************************************************************
*
* Forward declarations
*
********************************************************************************
*/

extern uint8_t  dram_get_size(void);
extern uint8_t  dram_read(uint32_t, uint8_t*, uint16_t);
extern uint8_t  dram_write(uint32_t, uint8_t*, uint16_t);


#endif
/* EOF */
