/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         unistd.h
*
* Language:     C
*
* Description:  Standard header file
*
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
* Changelog:    2004-11-06  Michael Baeuerle
*               Constant '_POSIX_VERSION' added
*               Prototype for 'sleep()' added
*               Prototype for 'usleep()' added
*
*
* To do:        -
*
********************************************************************************
*/

#ifndef _UNISTD_H
#define _UNISTD_H  1


/*
********************************************************************************
*
* Constants
*
********************************************************************************
*/

#define _POSIX_VERSION  198808L


/*
********************************************************************************
*
* Type definitions
*
********************************************************************************
*/

typedef unsigned long  useconds_t;


/*
********************************************************************************
*
* Forward declarations
*
********************************************************************************
*/

extern unsigned int  sleep(unsigned int);

/* SUS2 compatible */
extern void  usleep(useconds_t);


#endif
/* EOF */
