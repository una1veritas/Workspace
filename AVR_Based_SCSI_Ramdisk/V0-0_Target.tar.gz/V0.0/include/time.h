/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         time.h
*
* Language:     C
*
* Description:  Standard header file for POSIX processor time
*               Provides macros and prototypes for timing routines
*
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
* Changelog:    2004-11-06  Michael Baeuerle
*               Constant 'CLOCKS_PER_SEC' added
*               Prototype for 'clock()' added
*
*               2005-05-27  Michael Baeuerle
*               Macro 'N100SLEEP' added
*
*               2005-06-25  Michael Baeuerle
*               Variable 'sys_timer' added
*
*               2005-07-02  Michael Baeuerle
*               Macro 'N50SLEEP' added
*
*
* To do:        -
*
********************************************************************************
*/

#ifndef _TIME_H
#define _TIME_H  1


/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include "interrupt.h"


/*
********************************************************************************
*
* Constants
*
********************************************************************************
*/

#define CLOCKS_PER_SEC  TPS        /* Clock ticks per second */


/*
********************************************************************************
*
* Global variables
*
********************************************************************************
*/

extern volatile clock_t  sys_timer;


/*
********************************************************************************
*
* Macros
*
********************************************************************************
*/

/* Nominal 50ns inline delay (62.5ns) */
#define N50SLEEP  asm volatile("nop\n\t" : :)
/* Nominal 100ns inline delay (125ns) */
#define N100SLEEP  asm volatile("nop\n\t" : :); asm volatile("nop\n\t" : :)


/*
********************************************************************************
*
* Forward declarations
*
********************************************************************************
*/

extern clock_t  clock(void);
extern void  usleep(unsigned long);
extern uint16_t  sleep(uint16_t);
extern uint8_t  timeout(clock_t, uint16_t);


#endif
/* EOF */
