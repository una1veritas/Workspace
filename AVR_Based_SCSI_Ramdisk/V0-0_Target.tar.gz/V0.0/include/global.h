/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         global.h
*
* Language:     C
*
* Description:  Global definitions
*               The port and pin names of the PIA connection should only be
*               used by the PIA driver, so 'pia.h' would be the right place to
*               define them. I have done it here to have all port and pin
*               definitions at one place.
*
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
* Changelog:    2004-11-06  Michael Baeuerle
*               Constant 'DEBUGMASK' added
*               MCU port and pin names added
*               Shotcuts for EEPROM memory section added
*               Constant 'FREQUENCY' added
*
*               2005-05-27  Michael Baeuerle
*               Global variables 'my_id' and 'memsize' added
*
*               2005-06-25  Michael Baeuerle
*               Constant 'DEBUGMASK' moved to 'debug.h'
*               Global variables 'unit_attention' added
*
*
* To do:        -
*
********************************************************************************
*/

#ifndef _GLOBAL_H
#define _GLOBAL_H  1


/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include <inttypes.h>


/*
********************************************************************************
*
* Global constants
*
********************************************************************************
*/

/* Core frequency (Hz) */
/* Maximum: 16MHz */
#define FREQUENCY  (uint32_t) 16000000


/* AVR memory section definitions */
#ifndef EEPROM
#  define EEPROM  __attribute__((section (".eeprom")))
#endif


/* Port names */
#define PDB     PORTF              /* PIA data bus */
#define D_PDB   DDRF
#define R_PDB   PINF

#define PCB     PORTE              /* PIA control bus */
#define D_PCB   DDRE
#define R_PCB   PINE

#define MDB     PORTA              /* Memory data bus */
#define D_MDB   DDRA
#define R_MDB   PINA

#define MABL    PORTC              /* Memory address bus (Low)  */
#define D_MABL  DDRC
#define R_MABL  PINC

#define MABH    PORTD              /* Memory address bus (High)  */
#define D_MABH  DDRD
#define R_MABH  PIND

#define MCAS    PORTB              /* Memory /CAS lines  */
#define D_MCAS  DDRB
#define R_MCAS  PINB

#define MAUX    PORTG              /* Memory misc. lines (/RAS, /W, P)  */
#define D_MAUX  DDRG
#define R_MAUX  PING

#define ID      PINB               /* SCSI ID Jumperblock */


/* Pin names */
#define CAS3     7                 /* Memory /CAS lines */
#define CAS2     6
#define CAS1     5
#define CAS0     4

#define A2       3                 /* Binary SCSI ID */
#define A1       1
#define A0       0

#define PIA_A0   2                 /* PIA control bus pin names */
#define PIA_WR   4
#define PIA_RD   5
#define PIA_ACK  6
#define PIA_IRQ  7

#define RAS      2                 /* Memory misc. lines */
#define P        1
#define WR       0


/*
********************************************************************************
*
* Global variables
*
********************************************************************************
*/

extern uint8_t  my_id;
extern uint8_t  memsize;
/* Every bit indicates pending UNIT ATTENTION for the corresponding initiator */
extern uint8_t  unit_attention;


/*
********************************************************************************
*
* Forward declarations
*
********************************************************************************
*/

void  soft_reset(void);
void  fatal(int);


#endif
/* EOF */
