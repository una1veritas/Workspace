/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         debug.c
*
* Language:     C
*
* Description:  Debug subsystem
*               If you have a terminal (38400Bit/s 8N1) connected to USART0 of
*               the Target controller you can read debug messages when
*               'DEBUGMASK' is set to a value >0 => look at 'debug.h' for
*               details
*
*               You must connect a voltage level converter like MAX232 to the
*               ISP connector like this to get a RS-232 port:
*               Pin 2 : +5V (Supply for the level converter)               
*               Pin 9 : RXD (DTEs view, Data output of Target controller)
*               Pin 10: GND
*               
*               Attention:
*               Reducing the buffersize may result in delayed 'debug()' calls
*               (because they must wait until there is enough space for the
*               messages in the buffer). This can lead to PIA Selection Abort
*               Timeouts! => Check PIA documentation for timeout value
*
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc (Version 3.3)
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
*
* Changelog:    2004-11-06  Michael Baeuerle
*               Routine 'debug()' added
*
*               2005-05-26  Michael Baeuerle
*               Send carriage-return after every linefeed if 'ADD_CR' is
*                defined
*
*               2005-05-28  Michael Baeuerle
*               Store messages in a ring buffer and let the UDRE interrupt
*                handler push them into the USART (this reduce the delays
*                created by debug messages radically)
*
*               2005-06-25  Michael Baeuerle
*               'debug()': Now starts at Bit 0 with Level 1
*
*
* To do:        -
*
********************************************************************************
*/


/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include <avr/io.h>
#include <string.h>
#include "global.h"
#include "debug.h"

#ifdef DEBUGMASK


/*
********************************************************************************
*
* Global constants
*
********************************************************************************
*/

#define BUFFERSIZE  768            /* USART0 TX ring buffer size */
                                   /* (Limit: 16KiByte - 1) */


/*
********************************************************************************
*
* Global variables
*
********************************************************************************
*/

static volatile char  usart0_tx_buffer[BUFFERSIZE];  /* Ring buffer */
static volatile uint16_t  usart0_tx_readp = 0;    /* Read pointer */
static volatile uint16_t  usart0_tx_writep = 0;   /* Write pointer */
static volatile uint8_t  usart0_tx_emptyf = 1;    /* Buffer empty flag */
static volatile uint8_t  usart0_tx_fullf = 0;     /* Buffer full flag */

char  sbuf[80];                    /* Debug message buffer */


/*
********************************************************************************
*
* Debug message ring buffer access routines
*
* Return value:
* 0: Success
* 1: Buffer full/empty
*
********************************************************************************
*/

/* Must be atomic! (Mask UDRIE interrupt while accessing buffer) */
static uint8_t  usart0_tx_buffer_write(char*  data) {
   /* Check for buffer full */
   if (usart0_tx_fullf) return(1);
   /* Mask USART0 UDRE interrupt */
   UCSR0B &= (uint8_t) ~(1 << UDRIE);
   /* Verify write pointer */
   if (usart0_tx_writep >= BUFFERSIZE) usart0_tx_writep = 0;
   /* Write byte to buffer */
   usart0_tx_buffer[usart0_tx_writep] = *data;
   /* Update write pointer */
   usart0_tx_writep++;
   if (usart0_tx_writep >= BUFFERSIZE) usart0_tx_writep = 0;
   /* Update flags */
   usart0_tx_emptyf = 0;
   if (usart0_tx_writep == usart0_tx_readp) usart0_tx_fullf = 1;
   /* Unmask USART0 UDRE interrupt */
   UCSR0B |= (1 << UDRIE);
   return(0);
}


/* Always atomic (Used by UDRE interrupt handler with cleared I flag only) */
/* Attention:
 * This routine runs with disabled interrupts and must not time out the
 * DRAM refresh!!! (=> Look at 'interrupt.c' for interrupt latency) */
uint8_t  usart0_tx_buffer_read(char*  data) {
   /* Check for buffer empty */
   if (usart0_tx_emptyf) return(1);
   /* Verify read pointer */
   if (usart0_tx_readp >= BUFFERSIZE) usart0_tx_readp = 0;
   /* Read byte from buffer */
   *data = usart0_tx_buffer[usart0_tx_readp];
   /* Update pointer */
   usart0_tx_readp++;
   if (usart0_tx_readp >= BUFFERSIZE) usart0_tx_readp = 0;
   /* Update flags */
   usart0_tx_fullf = 0;
   if (usart0_tx_readp == usart0_tx_writep) usart0_tx_emptyf = 1;
   return(0);
}


/*
********************************************************************************
*
* Send debug message via USART0
*
* 'message' is printed when 'DEBUGMASK' is defined and the appropriate bit for
* 'level' is set to 1 in 'DEBUGMASK'
*
* Message must be <255 characters long!
*
********************************************************************************
*/

inline void  debug(int  level, char*  message) {
   uint8_t  rv;
   uint8_t  i;
   char  buf;

   if ((1 << (level - 1)) & DEBUGMASK) {
      /* Truncate oversized messages */
      if (strlen(message) > 254) message[254] = 0x00;
      /* Print message on terminal */
      for (i = 0; i < strlen(message); i++) {
         /* Write byte to USART0 TX ring buffer */
         do {
            rv = usart0_tx_buffer_write(&message[i]);
         } while (rv);
#ifdef ADD_CR
         /* Add carriage return after every linefeed */
         if (message[i] == '\n') {
            /* Write byte to USART0 TX ring buffer */
            buf = '\r';
            do {
               rv = usart0_tx_buffer_write(&buf);
            } while (rv);
         }
#endif
      }
   }
   return;
}


#endif  /* DEBUGMASK */


/* EOF */
