/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         pia.c
*
* Language:     C
*
* Description:  PIA (Parallel Interface Agent) driver
*               The target communicate with the PIA using this driver
*
*               The PIA is our SDS (Service Delivery Subsystem)
*
*               This driver exports the following routines:
*               - 'pia_get_status()': Read PIA status register
*               - 'pia_init()': Bring the SCSI interface online
*               - 'pia_abort()': Abort currently running PIA action
*               - 'pia_recover()': Recover after error (get ready again)
*               - 'pia_busfree()': Release SCSI bus
*               - 'pia_accept_selection()': Accept selection from initator
*               - 'pia_get_message()': Receive message from initator
*               - 'pia_put_message()': Send message to initator
*               - 'pia_put_message_again()': Send last message to initator again
*               - 'pia_get_command()': Receive command from initator
*               - 'pia_put_status()': Send status to initator
*               - 'pia_get_data()': Receive data from initator
*               - 'pia_put_data()': Send data to initator
*
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc (Version 3.3)
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : SCSI RAM-disk Hardware V1.0.1 (ATmega64)
*               OS       : none
* Do not work:  -
*
*
* Changelog:    2004-11-06  Michael Baeuerle
*               Routine 'pia_init()' added
*
*               2004-11-07  Michael Baeuerle
*               Function 'pia_read_register()' added
*               Function 'pia_write_register()' added
*
*               2005-05-26  Michael Baeuerle
*               Function 'pia_wait_for_ready()' added
*               Function 'pia_wait_for_ack()' added
*               Routine 'pia_get_status()' added
*
*               2005-05-26  Michael Baeuerle
*               Function 'pia_wait_for_irq()' added
*
*               2005-05-27  Michael Baeuerle
*               Constants for command and errors added
*               'pia_write_register()': 100ns data setup time added
*               Function 'pia_check_state()' added
*               Function 'pia_accept_selection()' added
*
*               2005-05-27  Michael Baeuerle
*               PIA command & error codes added
*               Function 'pia_abort()' added
*               Function 'pia_recover()' added
*
*               2005-06-04  Michael Baeuerle
*               Function 'pia_get_message()' added
*               Function 'pia_put_message()' added
*               Function 'pia_put_message_again()' added
*
*               2005-06-05  Michael Baeuerle
*               Move most of debug strings to program memory
*               Constant 'PIA_MAX_MESSAGE_SIZE' added
*
*               2005-06-11  Michael Baeuerle
*               Function 'pia_get_command()' added
*               Function 'pia_put_status()' added
*
*               2005-06-12  Michael Baeuerle
*               Function 'pia_put_data()' added
*               Bugfix: 'pia_busfree()': Don't access PIA if it is not enabled
*
*               2005-07-09  Michael Baeuerle
*               Function 'pia_get_data()' added
*               Bugfix: 'pia_put_data()': FLOW2 and COMPLETE flag handling fixed
*               'pia_wait_for_irq()': Timeout increased to 1s
*
*               2006-05-01  Michael Baeuerle
*               Bugfix: 'pia_accept_selection()': Wait for IRQ before verifying
*                that command has completed
*               Bugfix: 'pia_get_message()': Wait for command completion before
*                checking status at exit
*               Bugfix: 'pia_get_command()': Wait for command completion before
*                checking status at exit
*
*
* To do:        -
*
********************************************************************************
*/

/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include <avr/pgmspace.h>
#include <avr/io.h>
#include <stdio.h>
#include <string.h>
#include "global.h"
#include "debug.h"
#include "time.h"
#include "pia.h"


/*
********************************************************************************
*
* Global constants
*
********************************************************************************
*/

/* PIA register addresses (relative to base address) */
#define PIA_REG_STATUS   0         /* Status and control register share the */
#define PIA_REG_CONTROL  0         /* same addess location */
#define PIA_REG_DATA     1

/* PIA command codes */
#define  PIA_CMD_ABORT        0x00
#define  PIA_CMD_CONFIGURE    0x01
#define  PIA_CMD_RECOVER      0x02
#define  PIA_CMD_ACCEPT_SEL   0x03
#define  PIA_CMD_GET_MESSAGE  0x04
#define  PIA_CMD_PUT_MESSAGE  0x05
#define  PIA_CMD_GET_COMMAND  0x06
#define  PIA_CMD_PUT_STATUS   0x07
#define  PIA_CMD_GET_DATA     0x08
#define  PIA_CMD_PUT_DATA     0x09
#define  PIA_CMD_BUSFREE      0x0A

/* PIA error codes */
#define PIA_EC_ABORTED      0x00
#define PIA_EC_INVALID      0x01
#define PIA_EC_SEQUENCE     0x02
#define PIA_EC_PARITY       0x03
#define PIA_EC_PROTOCOL     0x04
#define PIA_EC_DATA_LENGTH  0x05

/* This is the maximum size of SCSI messages that this driver can handle */
/* (Define the size of the largest message used to save memory) */
#define PIA_MAX_MESSAGE_SIZE  7    /* Up to 255 is supported */


/*
********************************************************************************
*
* Global variables
*
********************************************************************************
*/

static uint8_t  last_message[PIA_MAX_MESSAGE_SIZE];
static uint8_t  last_messagesize;


/*
********************************************************************************
*
* Check whether PIA is ready
*
* Timeout is 1ms
*
* 0              : Success
* PIA_ERR_TIMEOUT: Timeout
*
********************************************************************************
*/

static uint8_t  pia_wait_for_ready(void) {
   clock_t  start;

   /* Ensure that strobe lines are deasserted */
   PCB |= (1 << PIA_RD) | (1 << PIA_WR);

   /* Wait for PIA to deassert /PIA_ACK */
   start = clock();
   while (!(R_PCB & (1 << PIA_ACK))) {
      /* Timeout after 1ms */
      if (timeout(start, 1)) return(PIA_ERR_TIMEOUT);
   }
   return(0);
}


/*
********************************************************************************
*
* Wait for PIA to acknoledge access
*
* Timeout is 1ms
*
* 0              : Success
* PIA_ERR_TIMEOUT: Timeout
*
********************************************************************************
*/

static uint8_t  pia_wait_for_ack(void) {
   clock_t  start;

   /* Wait for PIA to assert /PIA_ACK */
   start = clock();
   while (R_PCB & (1 << PIA_ACK)) {
      /* Timeout after 1ms */
      if (timeout(start, 1)) return(PIA_ERR_TIMEOUT);
   }
   return(0);
}


/*
********************************************************************************
*
* Wait for PIA IRQ
*
* Timeout is 500ms
*
* Return values:
* 0              : Success
* PIA_ERR_TIMEOUT: Timeout
*
********************************************************************************
*/

static uint8_t  pia_wait_for_irq(void) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[PIA] Wait for IRQ ... ";
   static const char  string1[] PROGMEM = "Timeout\n";
   static const char  string2[] PROGMEM = "Got it\n";
#endif
   clock_t  start;

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   /* Poll for PIA to assert /PIA_IRQ */
   start = clock();
   while (R_PCB & (1 << PIA_IRQ)) {
      /* Timeout after 1s */
      if (timeout(start, 1000)) {
         STRCPY_P(sbuf, string1);
         DEBUG(2, sbuf);
         return(PIA_ERR_TIMEOUT);
      }
   }

   STRCPY_P(sbuf, string2);
   DEBUG(2, sbuf);
   return(0);
}


/*
********************************************************************************
*
* PIA read access
*
* Return values:
* 0              : Success
* PIA_ERR_TIMEOUT: Timeout
* PIA_ERR_STATUS : Invalid register
*
********************************************************************************
*/

static uint8_t  pia_read_register(uint8_t  reg, uint8_t*  data) {
#ifdef DEBUGMASK
   char  sbuf2[8];
#endif

   DEBUG(2, "[PIA] Read ");

   /* Wait for PIA to become ready */
   if (pia_wait_for_ready()) {
      DEBUG(2, "timeout (Not ready)\n");
      return(PIA_ERR_TIMEOUT);
   }

   /* Set address */
   switch (reg) {
      case PIA_REG_STATUS:
         DEBUG(2, "STATUS register: ");
         PCB &= ~(1 << PIA_A0);
         break;
      case PIA_REG_DATA:
         DEBUG(2, "DATA register: ");
         PCB |= (1 << PIA_A0);
         break;
      default:
         DEBUG(2, "invalid register\n");
         return(PIA_ERR_STATUS);
   }

   /* Release PIA data bus */
   PDB = 0xFF;
   D_PDB = 0x00;
   
   /* Assert read strobe */
   PCB &= ~(1 << PIA_RD);

   /* Wait for acknoledge */
   if (pia_wait_for_ack()) {
      DEBUG(2, "Timeout (No ACK)\n");
      return(PIA_ERR_TIMEOUT);
   }

   /* Read data */
   *data = R_PDB;
#ifdef DEBUGMASK
   sprintf(sbuf2, "(0x%02X) ", *data);
   DEBUG(2, sbuf2);
#endif
   
   /* Deassert read strobe */
   PCB |= (1 << PIA_RD);

   DEBUG(2, "OK\n");
   return(0);
}


/*
********************************************************************************
*
* PIA write access
*
* Return values:
* 0              : Success
* PIA_ERR_TIMEOUT: Timeout
* PIA_ERR_STATUS : Invalid register
*
********************************************************************************
*/

static uint8_t  pia_write_register(uint8_t  reg, uint8_t*  data) {
#ifdef DEBUGMASK
   char  sbuf2[8];
#endif

   DEBUG(2, "[PIA] Write ");

   /* Wait for PIA to become ready */
   if (pia_wait_for_ready()) {
      DEBUG(2, "timeout (Not ready)\n");
      return(PIA_ERR_TIMEOUT);
   }

   /* Set address */
   switch (reg) {
      case PIA_REG_STATUS:
         DEBUG(2, "CONTROL register: ");
         PCB &= ~(1 << PIA_A0);
         break;
      case PIA_REG_DATA:
         DEBUG(2, "DATA register: ");
         PCB |= (1 << PIA_A0);
         break;
      default:
         DEBUG(2, "invalid register\n");
         return(PIA_ERR_STATUS);
   }

   /* Drive PIA data bus with data */
#ifdef DEBUGMASK
   sprintf(sbuf2, "(0x%02X) ", *data);
   DEBUG(2, sbuf2);
#endif
   PDB = *data;
   D_PDB = 0xFF;

   /* Data setup time (100ns) */
   N100SLEEP;
   
   /* Assert write strobe */
   PCB &= ~(1 << PIA_WR);

   /* Wait for acknoledge */
   if (pia_wait_for_ack()) {
      DEBUG(2, "Timeout (No ACK)\n");
      return(PIA_ERR_TIMEOUT);
   }
   
   /* Release PIA data bus */
   PDB = 0xFF;
   D_PDB = 0x00;

   /* Deassert write strobe */
   PCB |= (1 << PIA_WR);

   DEBUG(2, "OK\n");
   return(0);
}


/*
********************************************************************************
*
* Ensure that PIA is ready
*
* Parameters:
* 'error_code': PIA error code if PIA_ERR_FAILED is returned
*
* Return values:
* 0          : Ready
* PIA_ERR_xxx: Not ready/Error
*
********************************************************************************
*/

static uint8_t  pia_check_state(uint8_t*  error_code) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[PIA] Check status: ";
   static const char  string1[] PROGMEM = "Disabled\n";
   static const char  string2[] PROGMEM = "Busy\n";
   static const char  string3[] PROGMEM = "Error\n";
   static const char  string4[] PROGMEM = "[PIA] Read error code ...\n";
   static const char  string5[] PROGMEM = "[PIA] Timeout\n";
   static const char  string6[] PROGMEM = "[PIA] Command aborted\n";
   static const char  string7[] PROGMEM = "[PIA] Invalid command\n";
   static const char  string8[] PROGMEM
    = "[PIA] SCSI bus phase sequence error\n";
   static const char  string9[] PROGMEM = "[PIA] SCSI parity error\n";
   static const char  string10[] PROGMEM = "[PIA] SCSI protocol error\n";
   static const char  string11[] PROGMEM = "[PIA] Data length error\n";
   static const char  string12[] PROGMEM = "[PIA] Unknown error\n";
   static const char  string13[] PROGMEM = "Ready and enabled\n";
#endif
   uint8_t  rv;
   uint8_t  buf;

   *error_code = 0xFF;
   rv = pia_get_status(&buf);
   if (rv) return(rv);
   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);
   if (!(buf & (1 << PIA_ENABLE))) {
      /* Disabled */
      STRCPY_P(sbuf, string1);
      DEBUG(2, sbuf);
      return(PIA_ERR_STATUS);
   }
   if (!(buf & (1 << PIA_COMPLETE))) {
      /* Busy */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_STATUS);
   }
   if (buf & (1 << PIA_ERROR)) {
      /* Error */
      STRCPY_P(sbuf, string3);
      DEBUG(2, sbuf);
      /* Read error code */
      STRCPY_P(sbuf, string4);
      DEBUG(2, sbuf);
      rv = pia_read_register(PIA_REG_DATA, &buf);
      if (rv) {
         /* Timeout */
         STRCPY_P(sbuf, string5);
         DEBUG(2, sbuf);
         return(PIA_ERR_TIMEOUT);
      }
      *error_code = buf;
      switch (buf) {
          case PIA_EC_ABORTED:
             STRCPY_P(sbuf, string6);
             DEBUG(2, sbuf);
             break;
          case PIA_EC_INVALID:
             STRCPY_P(sbuf, string7);
             DEBUG(2, sbuf);
             break;
          case PIA_EC_SEQUENCE:
             STRCPY_P(sbuf, string8);
             DEBUG(2, sbuf);
             break;
          case PIA_EC_PARITY:
             STRCPY_P(sbuf, string9);
             DEBUG(2, sbuf);
             break;
          case PIA_EC_PROTOCOL:
             STRCPY_P(sbuf, string10);
             DEBUG(2, sbuf);
             break;
          case PIA_EC_DATA_LENGTH:
             STRCPY_P(sbuf, string11);
             DEBUG(2, sbuf);
             break;
          default:
             STRCPY_P(sbuf, string12);
             DEBUG(2, sbuf);
      }
      return(PIA_ERR_FAILED);
   }
   else {
      /* Ready and enabled */
      STRCPY_P(sbuf, string13);
      DEBUG(2, sbuf);
   }
   return(0);
}


/*
********************************************************************************
*
* Get PIA status
*
* Parameters:
* 'status': Pointer to result
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_get_status(uint8_t*  status) {
   static uint8_t  pia_status = 0x00;   /* Last known PIAs status */

   /* Read actual status from PIA */
   DEBUG(2, "[PIA] Get status ...\n");
   if (pia_read_register(PIA_REG_STATUS, status)) {
      return(PIA_ERR_TIMEOUT);
   }
   /* Update current status */
   pia_status = *status;
   return(0);
}


/*
********************************************************************************
*
* Abort PIA command
*
* If no PIA command is pending this routine do nothing and report success
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_abort(void) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[PIA] Try to abort command\n";
   static const char  string1[] PROGMEM
    = "[PIA] Send ABORT command to PIA ...\n";
   static const char  string2[] PROGMEM = "[PIA] Timeout\n";
   static const char  string3[] PROGMEM = "[PIA] Check status: ";
   static const char  string4[] PROGMEM = "Busy (ABORT command failed)\n";
   static const char  string5[] PROGMEM = "Error\n";
   static const char  string6[] PROGMEM = "[PIA] Read error code ...\n";
   static const char  string7[] PROGMEM = "[PIA] ABORT command was ignored\n";
   static const char  string8[] PROGMEM = "[PIA] ABORT command successful\n";
   static const char  string9[] PROGMEM = "Ready (ABORT command was ignored)\n";
#endif
   uint8_t  rv;
   uint8_t  buf;
   clock_t  start;

   /* Get PIA status */
   rv = pia_get_status(&buf);        
   if (rv) return(rv);
   
   /* Abort active command */
   if (!(buf & (1 << PIA_COMPLETE))) {
      /* Try to abort command */
      STRCPY_P(sbuf, string0);
      DEBUG(2, sbuf);
      /* Send ABORT command to PIA */
      STRCPY_P(sbuf, string1);
      DEBUG(2, sbuf);
      buf = PIA_CMD_ABORT;
      rv = pia_write_register(PIA_REG_CONTROL, &buf);   
      if (rv) { 
         /* Timeout */
         STRCPY_P(sbuf, string2);
         DEBUG(2, sbuf);
         return(PIA_ERR_TIMEOUT);
      }

      /* Wait for command complete (Timeout: 500ms) */
      start = clock();
      do {
         if (timeout(start, 500)) {
            /* Timeout */
            STRCPY_P(sbuf, string2);
            DEBUG(2, sbuf);
            return(PIA_ERR_TIMEOUT);
         }
         rv = pia_wait_for_irq();
         if (rv) return(rv);
         rv = pia_get_status(&buf);
         if (rv) return(rv);
      } while (!(buf & (1 << PIA_COMPLETE)));

      /* Check status and handle errors */
      STRCPY_P(sbuf, string3);
      DEBUG(2, sbuf);
      if (!(buf & (1 << PIA_COMPLETE))) {
         /* Busy */
         STRCPY_P(sbuf, string4);
         DEBUG(2, sbuf);
         return(PIA_ERR_FAILED);
      }
      if (buf & (1 << PIA_ERROR)) {
         /* Ready & Error => Get error code */
         STRCPY_P(sbuf, string5);
         DEBUG(2, sbuf);
         STRCPY_P(sbuf, string6);
         DEBUG(2, sbuf);
         rv = pia_read_register(PIA_REG_DATA, &buf);
         if (rv) {
            /* Timeout */
            STRCPY_P(sbuf, string2);
            DEBUG(2, sbuf);
            return(PIA_ERR_TIMEOUT);
         }
         if (buf != PIA_EC_ABORTED) {
            /* ABORT command was ignored */
            STRCPY_P(sbuf, string7);
            DEBUG(2, sbuf);
         }
         else {
            /* ABORT command successful */
            STRCPY_P(sbuf, string8);
            DEBUG(2, sbuf);
         }
      }
      else {
         /* Ready (ABORT command was ignored) */
         STRCPY_P(sbuf, string9);
         DEBUG(2, sbuf);
      }
   }
   return(0);
}


/*
********************************************************************************
*
* Recover from PIA error
*
* If no PIA error is present this routine do nothing and report success
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_recover(void) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[PIA] Recover from error\n";
   static const char  string1[] PROGMEM
    = "[PIA] Send RECOVER command to PIA ...\n";
   static const char  string2[] PROGMEM = "[PIA] Timeout\n";
   static const char  string3[] PROGMEM = "[PIA] Check status: ";
   static const char  string4[] PROGMEM = "Busy\n";
   static const char  string5[] PROGMEM = "Error (RECOVER command failed)\n";
   static const char  string6[] PROGMEM = "Ready and enabled\n";
#endif
   uint8_t  rv;
   uint8_t  buf;
   clock_t  start;

   /* Get PIA status */
   rv = pia_get_status(&buf);
   if (rv) return(rv);
   
   /* Recover from error if necessary */
   if (buf & (1 << PIA_ERROR)) {
      /* Recover from error */
      STRCPY_P(sbuf, string0);
      DEBUG(2, sbuf);
      /* Send RECOVER command to PIA */
      STRCPY_P(sbuf, string1);
      DEBUG(2, sbuf);
      buf = PIA_CMD_RECOVER;
      rv = pia_write_register(PIA_REG_CONTROL, &buf);   
      if (rv) {
         /* Timeout */
         STRCPY_P(sbuf, string2);
         DEBUG(2, sbuf);
         return(PIA_ERR_TIMEOUT);
      }

      /* Wait for command complete (Timeout: 500ms) */
      start = clock();
      do {
         if (timeout(start, 500)) {
            /* Timeout */
            STRCPY_P(sbuf, string2);
            DEBUG(2, sbuf);
            return(PIA_ERR_TIMEOUT);
         }
         rv = pia_wait_for_irq();
         if (rv) return(rv);
         rv = pia_get_status(&buf);
         if (rv) return(rv);
      } while (!(buf & (1 << PIA_COMPLETE)));

      /* Check PIA status */
      STRCPY_P(sbuf, string3);
      DEBUG(2, sbuf);
      if (!(buf & (1 << PIA_COMPLETE))) {
         /* Busy */
         STRCPY_P(sbuf, string4);
         DEBUG(2, sbuf);
         return(PIA_ERR_FAILED);
      }
      if (buf & (1 << PIA_ERROR)) {
         /* Error (RECOVER command failed) */
         STRCPY_P(sbuf, string5);
         DEBUG(2, sbuf);
         return(PIA_ERR_FAILED);
      }
      /* Ready and enabled */
      STRCPY_P(sbuf, string6);
      DEBUG(2, sbuf);
   }
   return(0);
}


/*
********************************************************************************
*
* Init PIA
*
* Parameters:
* 'id'    : Our SCSI ID
* 'config': PIA configuration byte
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_init(uint8_t  id, uint8_t  config) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[PIA] Init PIA\n";
   static const char  string1[] PROGMEM = "[PIA] Check status: ";
   static const char  string2[] PROGMEM = "Busy\n";
   static const char  string3[] PROGMEM = "Error\n";
   static const char  string4[] PROGMEM = "Ready\n";
   static const char  string5[] PROGMEM
    = "[PIA] Send CONFIGURE command to PIA ...\n";
   static const char  string6[] PROGMEM = "[PIA] Timeout\n";
   static const char  string7[] PROGMEM = "[PIA] Init was successful\n";
#endif
   uint8_t  rv;
   uint8_t  buf;

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   /* Get PIA status (2 retries if error) */
   buf = 0;
   do {
      rv = pia_get_status(&buf);
      buf++;
   } while (rv && (buf <= 3));
   if (rv) return(rv);
   STRCPY_P(sbuf, string1);
   DEBUG(2, sbuf);
   
   /* Abort active command */
   if (!(buf & (1 << PIA_COMPLETE))) {
      /* Busy */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      rv = pia_abort();
      if (rv) return(rv);
      rv = pia_recover();
      if (rv) return(rv);
   }
   else {
      /* Recover from error if necessary */
      if (buf & (1 << PIA_ERROR)) {
         /* Error */
         STRCPY_P(sbuf, string3);
         DEBUG(2, sbuf);
         rv = pia_recover();
         if (rv) return(rv);
      }
      else {
         /* Ready */
         STRCPY_P(sbuf, string4);
         DEBUG(2, sbuf);
      }
   }

   /* Send CONFIGURE command */
   STRCPY_P(sbuf, string5);
   DEBUG(2, sbuf);
   buf = PIA_CMD_CONFIGURE;
   rv = pia_write_register(PIA_REG_CONTROL, &buf);   
   if (rv) { 
      /* Timeout */
      STRCPY_P(sbuf, string6);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }
   buf = id;
   rv = pia_write_register(PIA_REG_DATA, &buf);
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string6);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }
   buf = config;
   rv = pia_write_register(PIA_REG_DATA, &buf);
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string6);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }

   /* Wait for IRQ */
   rv = pia_wait_for_irq();
   if (rv) return(rv);

   /* Check PIA status */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   STRCPY_P(sbuf, string7);
   DEBUG(2, sbuf);
   return(0);
}


/*
********************************************************************************
*
* Release the SCSI bus
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_busfree(void) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[PIA] Release SCSI bus ...\n";
   static const char  string1[] PROGMEM = "[PIA] Check status: ";
   static const char  string2[] PROGMEM = "Busy\n";
   static const char  string3[] PROGMEM = "Error\n";
   static const char  string4[] PROGMEM = "Ready\n";
   static const char  string5[] PROGMEM = "Ready and enabled\n";
   static const char  string6[] PROGMEM
    = "[PIA] Send BUSFREE command to PIA ...\n";
   static const char  string7[] PROGMEM = "[PIA] Timeout\n";
   static const char  string8[] PROGMEM = "[PIA] SCSI bus released\n";
#endif
   uint8_t  rv;
   uint8_t  buf;

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   /* Get PIA status */
   rv = pia_get_status(&buf);
   if (rv) return(rv);
   STRCPY_P(sbuf, string1);
   DEBUG(2, sbuf);
   
   /* Abort active command */
   if (!(buf & (1 << PIA_COMPLETE))) {
      /* Busy */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      rv = pia_abort();
      if (rv) return(rv);
      rv = pia_recover();
      if (rv) return(rv);
   }
   else {
      /* Recover from error if necessary */
      if (buf & (1 << PIA_ERROR)) {
         /* Error */
         STRCPY_P(sbuf, string3);
         DEBUG(2, sbuf);
         rv = pia_recover();
         if (rv) return(rv);
      }
      else if (!(buf & (1 << PIA_ENABLE))) {
         /* Ready */
         STRCPY_P(sbuf, string4);
         DEBUG(2, sbuf);
         /* Disabled */
         return (PIA_ERR_STATUS);
      }
      else {
         /* Ready and enabled */
         STRCPY_P(sbuf, string5);
         DEBUG(2, sbuf);
      }
   }

   /* Send BUSFREE command */
   STRCPY_P(sbuf, string6);
   DEBUG(2, sbuf);
   buf = PIA_CMD_BUSFREE;
   rv = pia_write_register(PIA_REG_CONTROL, &buf);   
   if (rv) { 
      /* Timeout */
      STRCPY_P(sbuf, string7);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }

   /* Wait for IRQ */
   rv = pia_wait_for_irq();
   if (rv) return(rv);

   /* Check PIA status */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   STRCPY_P(sbuf, string8);
   DEBUG(2, sbuf);
   return(0);
}


/*
********************************************************************************
*
* Accept selection from initiator
*
* Parameters:
* 'initiator': SCSI ID of initiator (PIA error code if command failed)
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_accept_selection(uint8_t*  initiator) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[PIA] Accept selection from initiator\n";
   static const char  string1[] PROGMEM 
    = "[PIA] Send ACCEPT_SELECTION command to PIA ...\n";
   static const char  string2[] PROGMEM = "[PIA] Timeout\n";
   static const char  string3[] PROGMEM = "[PIA] Check status: ";
   static const char  string4[] PROGMEM = "Data available\n";
   static const char  string5[] PROGMEM = "No data\n";
   static const char  string6[] PROGMEM
    = "[PIA] PIA has taken control over SCSI bus\n";
#endif
   uint8_t  rv;
   uint8_t  buf;

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   /* Ensure that PIA is ready */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   /* Send ACCEPT SELECTION command */
   STRCPY_P(sbuf, string1);
   DEBUG(2, sbuf);
   buf = PIA_CMD_ACCEPT_SEL;
   rv = pia_write_register(PIA_REG_CONTROL, &buf);   
   if (rv) { 
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }

   /* Wait for IRQ */
   rv = pia_wait_for_irq();
   if (rv) return(rv);

   /* Check PIA status */
   rv = pia_get_status(&buf);
   if (rv) return(rv);
   STRCPY_P(sbuf, string3);
   DEBUG(2, sbuf);

   /* Read initiator ID */
   if ((!(buf & (1 << PIA_COMPLETE))) && (buf & (1 << PIA_FLOW))) {
      /* Data available */
      STRCPY_P(sbuf, string4);
      DEBUG(2, sbuf);
      rv = pia_read_register(PIA_REG_DATA, &buf);
      if (rv) { 
         /* Timeout */
         STRCPY_P(sbuf, string2);
         DEBUG(2, sbuf);
         return(PIA_ERR_TIMEOUT);
      }
      *initiator = buf;
   }
   else {
      /* No data */
      STRCPY_P(sbuf, string5);
      DEBUG(2, sbuf);
      if (!(buf & (1 << PIA_ERROR))) return(PIA_ERR_FAILED);
   }

   /* Wait for IRQ */
   rv = pia_wait_for_irq();
   if (rv) return(rv);

   /* Check PIA status */
   rv = pia_check_state(&buf);
   if (rv) {
      *initiator = buf;
      return(rv);
   }

   STRCPY_P(sbuf, string6);
   DEBUG(2, sbuf);
   return(0);
}


/*
********************************************************************************
*
* Get message from initiator
*
* Parameters:
* 'buffer'    : Pointer to message buffer
* 'buffersize': Message buffer size (This routine never stores more bytes)
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_get_message(uint8_t*  buffer, uint8_t  buffersize) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[PIA] Receive message from initiator\n";
   static const char  string1[] PROGMEM
    = "[PIA] Send GET_MESSAGE command to PIA ...\n";
   static const char  string2[] PROGMEM = "[PIA] Timeout\n";
   static const char  string3[] PROGMEM = "[PIA] Check status: ";
   static const char  string4[] PROGMEM = "Data available\n";
   static const char  string5[] PROGMEM = "[PIA] Byte ";
   static const char  string6[] PROGMEM = "No data available\n";
   static const char  string7[] PROGMEM = "Data available\n";
   static const char  string8[] PROGMEM = "[PIA] Kick rest of message\n";
   static const char  string9[] PROGMEM = "Not busy\n";
   static const char  string10[] PROGMEM
    = "[PIA] Message received successfully\n";
   char  sbuf2[11];
#endif
   uint8_t  rv;
   uint8_t  buf;
   uint16_t  i;

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   /* Ensure that PIA is ready */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   /* Send GET_MESSAGE command */
   STRCPY_P(sbuf, string1);
   DEBUG(2, sbuf);
   buf = PIA_CMD_GET_MESSAGE;
   rv = pia_write_register(PIA_REG_CONTROL, &buf);   
   if (rv) { 
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }

   /* Wait for IRQ */
   rv = pia_wait_for_irq();
   if (rv) return(rv);

   /* Check PIA status */
   rv = pia_get_status(&buf);
   if (rv) return(rv);
   STRCPY_P(sbuf, string3);
   DEBUG(2, sbuf);
   if (!(buf & (1 << PIA_COMPLETE))) {
      /* Read message */
      for (i = 0; i < buffersize; i++) {
         if ((!(buf & (1 << PIA_COMPLETE))) && (buf & (1 << PIA_FLOW))) {
            /* Data available */
            STRCPY_P(sbuf, string4);
            DEBUG(2, sbuf);
            rv = pia_read_register(PIA_REG_DATA, &buf);
            if (rv) { 
               /* Timeout */
               STRCPY_P(sbuf, string2);
               DEBUG(2, sbuf);
               return(PIA_ERR_TIMEOUT);
            }
            buffer[i] = buf;
#ifdef DEBUGMASK
            strcpy_P(sbuf, string5);
            sprintf(sbuf2, "%u: 0x%02X\n", i, buffer[i]);
            strcat(sbuf, sbuf2);
            debug(2, sbuf);
#endif
            /* Check status */
            rv = pia_get_status(&buf);
            if (rv) return(rv);
            STRCPY_P(sbuf, string3);
            DEBUG(2, sbuf);
         }
         else {
            /* No data available (Message completely read) */
            STRCPY_P(sbuf, string6);
            DEBUG(2, sbuf);
            break;
         }
      }

      if (i >= buffersize) {
         /* Data available */
         STRCPY_P(sbuf, string7);
         DEBUG(2, sbuf);
         /* Buffer limit, drain rest of message to /dev/null */
         STRCPY_P(sbuf, string8);
         DEBUG(2, sbuf);
         while (1) {
            rv = pia_get_status(&buf);
            if (rv) return(rv);
            if ((!(buf & (1 << PIA_COMPLETE))) && (buf & (1 << PIA_FLOW))) {
               rv = pia_read_register(PIA_REG_DATA, &buf);
               if (rv) { 
                  /* Timeout */
                  STRCPY_P(sbuf, string2);
                  DEBUG(2, sbuf);
                  return(PIA_ERR_TIMEOUT);
               }
            }
            else break;
         }
      }
   }
   else {
      /* Not busy */
      STRCPY_P(sbuf, string9);
      DEBUG(2, sbuf);
   }

   /* Wait for command complete */
   /* Attention: 'buf' must be up-to-date here! */
   if (!(buf & (1 << PIA_COMPLETE))) {
      rv = pia_wait_for_irq();
      if (rv) return(rv);
   }

   /* Check PIA status */
   rv = pia_check_state(&buf);
   if (rv) {
      if (buf == PIA_EC_PARITY) {
         return(PIA_ERR_PARITY);
      }
      return(rv);
   }

   STRCPY_P(sbuf, string10);
   DEBUG(2, sbuf);
   return(0);
}


/*
********************************************************************************
*
* Send message to initiator
*
* Parameters:
* 'buffer'     : Pointer to message buffer
* 'messagesize': Message size
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_put_message(uint8_t*  buffer, uint8_t  messagesize) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[PIA] Send message to initiator\n";
   static const char  string1[] PROGMEM
    = "[PIA] Send PUT_MESSAGE command to PIA ...\n";
   static const char  string2[] PROGMEM = "[PIA] Timeout\n";
   static const char  string3[] PROGMEM = "[PIA] Byte ";
   static const char  string4[] PROGMEM = "[PIA] Message successfully sent\n";
   char  sbuf2[11];
#endif
   uint8_t  rv;
   uint8_t  buf;
   uint16_t  i;

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   /* Ensure that PIA is ready */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   /* Send PUT_MESSAGE command */
   STRCPY_P(sbuf, string1);
   DEBUG(2, sbuf);
   buf = PIA_CMD_PUT_MESSAGE;
   rv = pia_write_register(PIA_REG_CONTROL, &buf);   
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }

   /* Send message */
   if (messagesize > PIA_MAX_MESSAGE_SIZE) return(PIA_ERR_FAILED);
   last_messagesize = messagesize;
   for (i = 0; i < messagesize; i++) {
#ifdef DEBUGMASK
      strcpy_P(sbuf, string3);
      sprintf(sbuf2, "%u: 0x%02X\n", i, buffer[i]);
      strcat(sbuf, sbuf2);
      debug(2, sbuf);
#endif
      rv = pia_write_register(PIA_REG_DATA, &buffer[i]);
      if (rv) { 
         /* Timeout */
         STRCPY_P(sbuf, string2);
         DEBUG(2, sbuf);
         return(PIA_ERR_TIMEOUT);
      }
      last_message[i] = buffer[i];
   }

   /* Wait for IRQ */
   rv = pia_wait_for_irq();
   if (rv) return(rv);

   /* Check PIA status */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   STRCPY_P(sbuf, string4);
   DEBUG(2, sbuf);
   return(0);
}


/*
********************************************************************************
*
* Resend last message to initiator
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_put_message_again(void) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM 
    = "[PIA] Send last message to initiator again\n";
#endif
   uint8_t  rv;

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   rv = pia_put_message(last_message, last_messagesize);
   return(rv);
}


/*
********************************************************************************
*
* Get command from initiator
*
* Parameters:
* 'buffer'    : Pointer to command buffer
* 'buffersize': Command buffer size (This routine never stores more bytes)
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_get_command(uint8_t*  buffer, uint8_t  buffersize) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[PIA] Receive command from initiator\n";
   static const char  string1[] PROGMEM
    = "[PIA] Send GET_COMMAND command to PIA ...\n";
   static const char  string2[] PROGMEM = "[PIA] Timeout\n";
   static const char  string3[] PROGMEM = "[PIA] Check status: ";
   static const char  string4[] PROGMEM = "Data available\n";
   static const char  string5[] PROGMEM = "[PIA] Byte ";
   static const char  string6[] PROGMEM = "No data available\n";
   static const char  string7[] PROGMEM = "Data available\n";
   static const char  string8[] PROGMEM = "[PIA] Kick rest of command\n";
   static const char  string9[] PROGMEM = "Not busy\n";
   static const char  string10[] PROGMEM
    = "[PIA] Command received successfully\n";
   char  sbuf2[11];
#endif
   uint8_t  rv;
   uint8_t  buf;
   uint16_t  i;

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   /* Ensure that PIA is ready */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   /* Send GET_COMMAND command */
   STRCPY_P(sbuf, string1);
   DEBUG(2, sbuf);
   buf = PIA_CMD_GET_COMMAND;
   rv = pia_write_register(PIA_REG_CONTROL, &buf);   
   if (rv) { 
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }

   /* Wait for IRQ */
   rv = pia_wait_for_irq();
   if (rv) return(rv);

   /* Check PIA status */
   rv = pia_get_status(&buf);
   if (rv) return(rv);
   STRCPY_P(sbuf, string3);
   DEBUG(2, sbuf);
   if (!(buf & (1 << PIA_COMPLETE))) {
      /* Read command */
      for (i = 0; i < buffersize; i++) {
         if ((!(buf & (1 << PIA_COMPLETE))) && (buf & (1 << PIA_FLOW))) {
            /* Data available */
            STRCPY_P(sbuf, string4);
            DEBUG(2, sbuf);
            rv = pia_read_register(PIA_REG_DATA, &buf);
            if (rv) { 
               /* Timeout */
               STRCPY_P(sbuf, string2);
               DEBUG(2, sbuf);
               return(PIA_ERR_TIMEOUT);
            }
            buffer[i] = buf;
#ifdef DEBUGMASK
            strcpy_P(sbuf, string5);
            sprintf(sbuf2, "%u: 0x%02X\n", i, buffer[i]);
            strcat(sbuf, sbuf2);
            debug(2, sbuf);
#endif
            /* Check status */
            rv = pia_get_status(&buf);
            if (rv) return(rv);
            STRCPY_P(sbuf, string3);
            DEBUG(2, sbuf);
         }
         else {
            /* No data available (Command completely read) */
            STRCPY_P(sbuf, string6);
            DEBUG(2, sbuf);
            break;
         }
      }

      if (i >= buffersize) {
         /* Data available */
         STRCPY_P(sbuf, string7);
         DEBUG(2, sbuf);
         /* Buffer limit, drain rest of command to /dev/null */
         STRCPY_P(sbuf, string8);
         DEBUG(2, sbuf);
         while (1) {
            rv = pia_get_status(&buf);
            if (rv) return(rv);
            if ((!(buf & (1 << PIA_COMPLETE))) && (buf & (1 << PIA_FLOW))) {
               rv = pia_read_register(PIA_REG_DATA, &buf);
               if (rv) { 
                  /* Timeout */
                  STRCPY_P(sbuf, string2);
                  DEBUG(2, sbuf);
                  return(PIA_ERR_TIMEOUT);
               }
            }
            else break;
         }
      }
   }
   else {
      /* Not busy */
      STRCPY_P(sbuf, string9);
      DEBUG(2, sbuf);
   }

   /* Wait for command complete */
   /* Attention: 'buf' must be up-to-date here! */
   if (!(buf & (1 << PIA_COMPLETE))) {
      rv = pia_wait_for_irq();
      if (rv) return(rv);
   }

   /* Check PIA status */
   rv = pia_check_state(&buf);
   if (rv) {
      if (buf == PIA_EC_PARITY) {
         return(PIA_ERR_PARITY);
      }
      return(rv);
   }

   STRCPY_P(sbuf, string10);
   DEBUG(2, sbuf);
   return(0);
}


/*
********************************************************************************
*
* Send status to initiator
*
* Parameters:
* 'status': Status byte
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_put_status(uint8_t  status) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[PIA] Send status to initiator\n";
   static const char  string1[] PROGMEM
    = "[PIA] Send PUT_STATUS command to PIA ...\n";
   static const char  string2[] PROGMEM = "[PIA] Timeout\n";
   static const char  string3[] PROGMEM = "[PIA] Status successfully sent\n";
   static const char  string4[] PROGMEM = "[PIA] Status: ";
   char  sbuf2[6];
#endif
   uint8_t  rv;
   uint8_t  buf;

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   /* Ensure that PIA is ready */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   /* Send PUT_STATUS command */
   STRCPY_P(sbuf, string1);
   DEBUG(2, sbuf);
   buf = PIA_CMD_PUT_STATUS;
   rv = pia_write_register(PIA_REG_CONTROL, &buf);   
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }
#ifdef DEBUGMASK
   strcpy_P(sbuf, string4);
   sprintf(sbuf2, "0x%02X\n", status);
   strcat(sbuf, sbuf2);
   debug(2, sbuf);
#endif
   buf = status;
   rv = pia_write_register(PIA_REG_DATA, &buf);
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }

   /* Wait for IRQ */
   rv = pia_wait_for_irq();
   if (rv) return(rv);

   /* Check PIA status */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   STRCPY_P(sbuf, string3);
   DEBUG(2, sbuf);
   return(0);
}


/*
********************************************************************************
*
* Receive data from initiator
*
* If 0 Bytes are requested to transfer, nothing is done and success is reported
*
* Parameters:
* 'buffer': Data buffer
* 'length': Number of bytes to receive
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_get_data(uint8_t*  buffer, uint16_t  length) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[PIA] Receive data from initiator\n";
   static const char  string1[] PROGMEM
    = "[PIA] Send GET_DATA command to PIA ...\n";
   static const char  string2[] PROGMEM = "[PIA] Timeout\n";
   static const char  string3[] PROGMEM = "[PIA] ";
   static const char  string4[] PROGMEM = "Bytes successfully received\n";
   char  sbuf2[8];
#endif
   uint8_t  rv;
   uint8_t  buf;
   uint8_t  i;
   uint16_t  ii;
   uint8_t  flow2;

   if (!length) return(0);

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   /* Ensure that PIA is ready */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   /* Send GET_DATA command */
   STRCPY_P(sbuf, string1);
   DEBUG(2, sbuf);
   buf = PIA_CMD_GET_DATA;
   rv = pia_write_register(PIA_REG_CONTROL, &buf);   
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }
   buf = (uint8_t) (length >> 8);
   rv = pia_write_register(PIA_REG_DATA, &buf);
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }
   buf = (uint8_t) (length & 0x00FF);
   rv = pia_write_register(PIA_REG_DATA, &buf);
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }

   /* Wait for data */
   do {
      /* Wait for IRQ */
      rv = pia_wait_for_irq();
      if (rv) return(rv);
      /* Get status */
      rv = pia_get_status(&buf);
      if (rv) return(rv);
   } while ( !(buf & (1 << PIA_FLOW)) || !(buf & (1 << PIA_FLOW2)) );
   /* Save state of FLOW2 flag */
   flow2 = buf & (1 << PIA_FLOW2);

   /* Receive data in 512 Byte chunks */
   for (i = 0; i < (uint8_t) (length / 512); i++) {
      for (ii = 0; ii < 512; ii++) {
         rv = pia_read_register(PIA_REG_DATA, &buf);
         if (rv) {
            /* Timeout */
            STRCPY_P(sbuf, string2);
            DEBUG(2, sbuf);
            return(PIA_ERR_TIMEOUT);
         }
         buffer[i * 512 + ii] = buf;
      }
      /* Wait for FLOW2 to toggle or command complete */
      rv = pia_get_status(&buf);
      if (rv) return(rv);
      while ( !(buf & (1 << PIA_COMPLETE))
       && !((buf & (1 << PIA_FLOW2)) ^ flow2) ) {
         /* Wait for IRQ */
         rv = pia_wait_for_irq();
         if (rv) return(rv);
         /* Check status */
         rv = pia_get_status(&buf);
         if (rv) return(rv);
      }
      /* Store new state of FLOW2 */
      flow2 = buf & (1 << PIA_FLOW2);
   }
   if (!(buf & (1 << PIA_COMPLETE))) {
      /* Receive rest of data */
      for (ii = 0; ii < length % 512; ii++) {
         rv = pia_read_register(PIA_REG_DATA, &buf);
         if (rv) {
            /* Timeout */
            STRCPY_P(sbuf, string2);
            DEBUG(2, sbuf);
            return(PIA_ERR_TIMEOUT);
         }
         buffer[(length / 512) * 512 + ii] = buf;
      }
   }

   /* Wait for command to complete */
   rv = pia_get_status(&buf);
   if (rv) return(rv);
   if (!(buf & (1 << PIA_COMPLETE))) {
      /* Wait for IRQ */
      rv = pia_wait_for_irq();
      if (rv) return(rv);
      /* Check status */
      rv = pia_get_status(&buf);
      if (rv) return(rv);
   }

   /* Check PIA status */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

#ifdef DEBUGMASK
   strcpy_P(sbuf, string3);
   sprintf(sbuf2, "0x%04X ", length);
   strcat(sbuf, sbuf2);
   strcat_P(sbuf, string4);
   debug(2, sbuf);
#endif
   return(0);
}


/*
********************************************************************************
*
* Send data to initiator
*
* If 0 Bytes are requested to transfer, nothing is done and success is reported
*
* Parameters:
* 'buffer': Data buffer
* 'length': Number of bytes to send
*
* Return value:
* 0          : Success
* PIA_ERR_xxx: Error
*
********************************************************************************
*/

uint8_t  pia_put_data(uint8_t*  buffer, uint16_t  length) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "[PIA] Send data to initiator\n";
   static const char  string1[] PROGMEM
    = "[PIA] Send PUT_DATA command to PIA ...\n";
   static const char  string2[] PROGMEM = "[PIA] Timeout\n";
   static const char  string3[] PROGMEM = "[PIA] ";
   static const char  string4[] PROGMEM = "Bytes successfully sent\n";
   static const char  string5[] PROGMEM
    = "[PIA] Buffer not ready (FLOW not set)\n";
   char  sbuf2[8];
#endif
   uint8_t  rv;
   uint8_t  buf;
   uint8_t  i;
   uint16_t  ii;
   uint8_t  flow2;

   if (!length) return(0);

   STRCPY_P(sbuf, string0);
   DEBUG(2, sbuf);

   /* Ensure that PIA is ready */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

   /* Send PUT_DATA command */
   STRCPY_P(sbuf, string1);
   DEBUG(2, sbuf);
   buf = PIA_CMD_PUT_DATA;
   rv = pia_write_register(PIA_REG_CONTROL, &buf);   
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }
   buf = (uint8_t) (length >> 8);
   rv = pia_write_register(PIA_REG_DATA, &buf);
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }
   buf = (uint8_t) (length & 0x00FF);
   rv = pia_write_register(PIA_REG_DATA, &buf);
   if (rv) {
      /* Timeout */
      STRCPY_P(sbuf, string2);
      DEBUG(2, sbuf);
      return(PIA_ERR_TIMEOUT);
   }

   /* Wait for IRQ */
   rv = pia_wait_for_irq();
   if (rv) return(rv);
   /* Save FLOW2 flag */
   rv = pia_get_status(&buf);
   if (rv) return(rv);
   if (!(buf & (1 << PIA_FLOW))) {
      /* Buffer flow control error (FLOW flag not set) */
      STRCPY_P(sbuf, string5);
      DEBUG(2, sbuf);
      return(PIA_ERR_STATUS);
   }
   flow2 = buf & (1 << PIA_FLOW2);

   /* Send data in 512 Byte chunks */
   for (i = 0; i < (uint8_t) (length / 512); i++) {
      for (ii = 0; ii < 512; ii++) {
         buf = buffer[i * 512 + ii];
         rv = pia_write_register(PIA_REG_DATA, &buf);
         if (rv) {
            /* Timeout */
            STRCPY_P(sbuf, string2);
            DEBUG(2, sbuf);
            return(PIA_ERR_TIMEOUT);
         }
      }
      /* Wait for FLOW2 to toggle or command complete */
      do {
         /* Wait for IRQ */
         rv = pia_wait_for_irq();
         if (rv) return(rv);
         rv = pia_get_status(&buf);
         if (rv) return(rv);
      } while ( !(buf & (1 << PIA_COMPLETE))
       && !((buf & (1 << PIA_FLOW2)) ^ flow2) );
      /* Store new state of FLOW2 */
      flow2 = buf & (1 << PIA_FLOW2);
   }
   if (!(buf & (1 << PIA_COMPLETE))) {
      /* Send rest of data */
      for (ii = 0; ii < length % 512; ii++) {
         buf = buffer[(length / 512) * 512 + ii];
         rv = pia_write_register(PIA_REG_DATA, &buf);
         if (rv) {
            /* Timeout */
            STRCPY_P(sbuf, string2);
            DEBUG(2, sbuf);
            return(PIA_ERR_TIMEOUT);
         }
      }
   }

   /* Wait for command to complete */
   rv = pia_get_status(&buf);
   if (rv) return(rv);
   if (!(buf & (1 << PIA_COMPLETE))) {
      /* Wait for IRQ */
      rv = pia_wait_for_irq();
      if (rv) return(rv);
      rv = pia_get_status(&buf);
      if (rv) return(rv);
   }

   /* Check PIA status */
   rv = pia_check_state(&buf);
   if (rv) return(rv);

#ifdef DEBUGMASK
   strcpy_P(sbuf, string3);
   sprintf(sbuf2, "0x%04X ", length);
   strcat(sbuf, sbuf2);
   strcat_P(sbuf, string4);
   debug(2, sbuf);
#endif
   return(0);
}


/* EOF */
