
SCSI RAM-Disk Target firmware V0.1
==================================
This is the firmware for the selfmade SCSI RAM-Disk. It controls the "Target"
and "Logical unit" modules which (logically) communicate with the initiator via
the SDS (Service Delivery Subsystem) provided by the "PIA" module. Normally the
initiator is a hostadapter.


Hardware requirements
---------------------
- RAM-Disk hardware V1.x (V1.0.1 or higher)
  Atmel ATmega64-16 processor
  PIA with firmware V0.x
- 4MiByte or 16MiByte asynchronous DRAM (size is detected automatically)
  30Pin Modules, 1MiByte (1Mix8) or 4MiByte (4Mix8), 70ns, Fast pagemode capable
  (Timings are designed for Siemens HYB511000B-70 chips. The datasheet can be
  found in the './doc' directory)
  Note: 9Bit modules (1Mix9 or 4Mix9) will also work but parity is not used


Build requirements
------------------
- UNIX compatible host system (I have used GNU/Linux 2.2.26)
- GNU compiler collection ("GCC") V3.3
- GNU binutils V2.14
- avr-libc V1.0
- HEXtoGEN V0.3 file format converter for Atmel GENERIC format (optional)

Type 'make all' (or 'make hex' if 'HEXtoGEN' is not installed) to build the
firmware and check './bin/README.txt' for the image file names.

The GCC list files can be found in the './bin' directory. To examine the
relocated/linked code you can use the command:
   avr-objdump -d --disassemble-zeroes ./bin/target.elf | less


Compatibility
-------------
This firmware was developed to comply with the SCSI3 standard ANSI X3.301:1997.

It should be compatible with all hostadapters that comply to the SCSI2 standard
ANSI X3.131:1994 as long as they do not reject devices reporting compliance to
newer standards. The optional explicit backward compatibility feature using the
'CHANGE DEFINITION' command is not implemented.

This firmware should also work with most hostadapters that are compliant to the
SCSI1 standard ANSI X3.131:1986. Problems may occur with the addressing of the
logical units:
Inline addressing (specifying the LUN in the CDB) is not supported because SCSI3
do no longer allow it. Instead an 'IDENTIFY' message must be used to establish
an I_T_L nexus. To be tolerant, the firmware can also work with an I_T nexus:
If there is no 'IDENTIFY' message, the command is routed to LUN 0.


Debugging
---------
The target can print debug messages on a RS-232 terminal connected to USART0 (I
have used 'minicom' on a GNU/Linux machine). A level converter (e.g. MAX232)
must be externally connected to the ISP connector to get a RS-232 compatible
Port. To enable the debug system the constant 'DEBUGMASK' (=> Look at
'./include/debug.h') must be defined and set to a nonzero value. Messages are
sent with 38400Bit/s and 8N1 frame format.

Note:
If the debug system is enabled, it may be necessary to increase the selection
abort time in the PIA firmware because the target cannot accept selections
within the prescribed 200us any more (=> Check PIA firmware documentation).


More info can be found in the './doc' directory.


2006-07-01  Michael Baeuerle <micha@hilfe-fuer-linux.de>


EOF
