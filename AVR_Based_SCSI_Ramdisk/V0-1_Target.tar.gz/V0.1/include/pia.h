/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         pia.h
*
* Language:     C
*
* Description:  PIA driver API
*
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
* Changelog:    2004-11-06  Michael Baeuerle
*               Prototype for 'pia_init()' added
*
*               2004-11-07  Michael Baeuerle
*               Constants 'PIA_ERR_TIMEOUT' and 'PIA_ERR_STATUS' added
*               Constants 'PIA_REG_DATA', 'PIA_REG_STATUS' and 'PIA_REG_COMMAND'
*               added (normally hidden)
*               Constants for PIA status and config bits added
*               Prototype for 'pia_get_status()' added
*
*               2005-05-27  Michael Baeuerle
*               Prototype for 'pia_accept_selection()' added
*
*               2005-05-28  Michael Baeuerle
*               Prototype for 'pia_abort()' added
*               Prototype for 'pia_recover()' added
*               Prototype for 'pia_busfree()' added
*
*               2005-06-04  Michael Baeuerle
*               Prototype for 'pia_get_message()' added
*               Prototype for 'pia_put_message()' added
*               Prototype for 'pia_put_message_again()' added
*
*               2005-06-11  Michael Baeuerle
*               Prototype for 'pia_get_command()' added
*               Prototype for 'pia_put_status()' added
*
*               2005-06-12  Michael Baeuerle
*               Prototype for 'pia_get_data()' added
*               Prototype for 'pia_put_data()' added
*
*
* To do:        -
*
********************************************************************************
*/

#ifndef _PIA_H
#define _PIA_H  1


/*
********************************************************************************
*
* Constants
*
********************************************************************************
*/

/* PIA config bits */
#define PIA_TARGET     0

/* PIA status bits */
#define PIA_ENABLE     0
#define PIA_ERROR      1
#define PIA_COMPLETE   2
#undef PIA_RESET                   /* Not supported by hardware V1.0 */
#define PIA_ATTENTION  4
#define PIA_SELECT     5
#define PIA_FLOW       6
#define PIA_FLOW2      7

/* PIA errors used for return values of function calls */
#define  PIA_ERR_TIMEOUT  1        /* PIA communication timeout */
#define  PIA_ERR_STATUS   2        /* PIA not in expected state */
#define  PIA_ERR_FAILED   3        /* PIA command failed */
#define  PIA_ERR_PARITY   4        /* PIA detected parity error */


/*
********************************************************************************
*
* Forward declarations
*
********************************************************************************
*/

extern uint8_t  pia_get_status(uint8_t*);
extern uint8_t  pia_init(uint8_t, uint8_t);
extern uint8_t  pia_abort(void);
extern uint8_t  pia_recover(void);
extern uint8_t  pia_busfree(void);
extern uint8_t  pia_accept_selection(uint8_t*);
extern uint8_t  pia_get_message(uint8_t*, uint8_t);
extern uint8_t  pia_put_message(uint8_t*, uint8_t);
extern uint8_t  pia_put_message_again(void);
extern uint8_t  pia_get_command(uint8_t*, uint8_t);
extern uint8_t  pia_put_status(uint8_t);
extern uint8_t  pia_get_data(uint8_t*, uint16_t);
extern uint8_t  pia_put_data(uint8_t*, uint16_t);


#endif
/* EOF */
