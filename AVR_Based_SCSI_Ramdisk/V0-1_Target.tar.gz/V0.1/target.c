/*
********************************************************************************
*
* Header
*  
* Project:      SCSI controller
*
* Module:       Target
* File:         target.c
* Version:      V0.1
*
* Language:     C
*
* Description:  This is the firmware for the target module (handling the
*               SIP protocol and the logical unit 0 function). It implements a
*               Type 0 "direct access" device.
* 
* Copyright:    (C) 2004 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler:   gcc (Version 3.3)
*               Platform:   AVR
*               OS:         none
* Tested with:  Compiler:   gcc (Version 3.3)
*                           avr-libc (Version 1.0.2)
*               Platform:   SCSI RAM-disk Hardware V1.0.1 (ATmega64)
*               OS:         none
* Do not work:  -
* 
* 
* Changelog:
* V0.0          Implement debug and timing services
*
*               2004-10-24  Michael Baeuerle
*               Makefile and directory structure created
*
*               2004-11-06  Michael Baeuerle
*               Routine 'main()' added
*               EEPROM constant 'MAGIC' added
*               EEPROM constant 'FW_VERSION' added
*               Function 'fatal()' added
*               PROGMEM constant 'HW_VERSION' added
*               Functions 'test_sram()' and 'test_dram()' added
*               POST added
*               Global variables 'my_id', 'ini_id' and 'pia_status' added
*               PIA configuration added
*
*               2004-11-06  Michael Baeuerle
*               Variable 'pia_status' moved to 'pia.c'
*
*               2005-05-27  Michael Baeuerle
*               PIA configuration works now
*               Call task router after boot
*
*               2005-05-27  Michael Baeuerle
*               Routine 'soft_reset()' added
*               Forward declaration for 'main()' added
*
*               2005-06-05  Michael Baeuerle
*               Move all debug strings to program memory
*
*               2005-06-12  Michael Baeuerle
*               Global variable 'unit_attention' added
*
*               2005-06-24  Michael Baeuerle
*               'soft_reset()': Re-init stack pointer and call 'main()'
*               Forward declaration for 'main()' removed
*               'main()': Skip POST for soft reset
*               'main()': Use 'exit()' instead of 'return()'
*               'fatal()': Debug message buffer drain timeout increased to 5s
*
*               2005-07-01  Michael Baeuerle
*               'fatal()': Code 4 "DRAM address out of range" added
*
*               2005-07-06  Michael Baeuerle
*               'fatal()': Code 5 "Out of memory" added
*               'fatal()': Code 6 "DRAM access error" added
*               POST implemented
*
*               2005-07-09  Michael Baeuerle
*               'test_dram()' renamed to 'full_test_dram()'
*               Function 'fast_test_dram()' added
*
*               2005-07-11  Michael Baeuerle
*               'main()': Now determines real DRAM size
*
* 
* To do:        -
* 
********************************************************************************
*/


/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include <avr/pgmspace.h>
#include <avr/io.h>
#include <avr/sfr_defs.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "global.h"
#include "debug.h"
#include "time.h"
#include "pia.h"
#include "dram.h"
#include "taskrouter.h"


/*
********************************************************************************
*
* Global constants
*
********************************************************************************
*/

/* Compile date (created from Makefile) */
#include "ctime.h"                  

/* Used to check whether EEPROM content is present */
const uint8_t  MAGIC EEPROM = 0xAA;      

/* Attention: Do not change length of these strings! */
/* Hardware version (Format: Vx.y[y].z[z][pren]\0) */
const char  HW_VERSION[] EEPROM = "V1.0.1\0\0\0\0\0\0\0";
/* Firmware version (Format: Vx.y[y][pren]\0) */
const char  FW_VERSION[] PROGMEM = "V0.1\0\0\0\0\0\0";


/*
********************************************************************************
*
* Global variables
*
* Attention:
* If initialized global variables should be used, they must be re-initialized
* by 'soft_reset()'!
*
********************************************************************************
*/

uint8_t  my_id;                    /* Own SCSI address */
uint8_t  memsize;                  /* DRAM size in MiByte */
uint8_t  unit_attention;           /* UNIT ATTENTION condition flags */


/*
********************************************************************************
*
* SRAM pattern test
*
* Because the program is still running, we can only check the heap memory
*
* Attention:
* - The heap must be empty (will be overwritten)!
* - Must be called with interrupts disabled (otherwise the interrupts will push
*   the stack down into our test window and corrupt it)
*
* Paramter:
* 'address': Contains the address on which the test failed (only valid on error)
*
* Return value:
* 0: Success
* 1: Error
*
********************************************************************************
*/

static uint8_t  test_sram(unsigned long*  address) {
   uint8_t  i;
   uint16_t  ii;
   uint8_t  pattern[] = {0x55, 0xAA, 0x00, 0xFF};

   for (i = 0; i < 4; i++) {
      /* Write pattern */
      for (ii = (uint16_t) __malloc_heap_start; ii < SP; ii++) {
         *((uint8_t*) ii) = pattern[i];
      }
      /* Read and compare pattern */
      for (ii = (uint16_t) __malloc_heap_start; ii < SP; ii++) {
         if (*((uint8_t*) ii) != pattern[i]) {
            /* Compare failed */
            *address = (unsigned long) ii;
            return(1);
         }
      }
   }
   /* Success */
   return(0);
}


/*
********************************************************************************
*
* Full DRAM pattern test (takes several minutes)
*
* The pattern is inverted for odd adresses so the memory chips must drive the
* data bus lines to inverse levels after every access for read & compare
*
* Paramter:
* 'address': Contains the address on which the test failed (only valid on error)
*
* Return value:
* 0: Success
* 1: Error
*
********************************************************************************
*/

#if 0  /* Currently not used */
static int  full_test_dram(unsigned long*  address) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "\n[DRAM] Test: ";
   static const char  string1[] PROGMEM = "[DRAM] Test: Pattern 0x";
   static const char  string2[] PROGMEM = "[DRAM] Test: Write error\n";
   static const char  string3[] PROGMEM = "[DRAM] Test: Read error\n";
   static const char  string4[] PROGMEM
    = "Compare error (value: 0x";
   static const char  string5[] PROGMEM = ", expected: 0x";
   static const char  string6[] PROGMEM = ")\n";
   static const char  string7[] PROGMEM = " blocks available\n";
   char  sbuf2[7];            /* Enough for %d, %02X + \n + \0 */
#endif
   uint8_t  rv;
   uint8_t  i;                     /* Pattern index */
   uint16_t  ii;                   /* Block index */
   uint16_t  iii;                  /* Buffer index */
   uint8_t  pattern[] = {0x55, 0xAA, 0x00, 0xFF};
   uint8_t  buffer[512];
   uint16_t  blocks;

   if (!memsize) return(0);
   blocks = memsize * 2048;        /* (memsize * 1Mi / 512) */
#ifdef DEBUGMASK
   strcpy_P(sbuf, string0);
   sprintf(sbuf2, "%d", blocks);
   strcat(sbuf, sbuf2);
   strcat_P(sbuf, string7);
   debug(5, sbuf);
#endif
   for (i = 0; i < 4; i++) {
#ifdef DEBUGMASK
      strcpy_P(sbuf, string1);
      sprintf(sbuf2, "%02X\n", pattern[i]);
      strcat(sbuf, sbuf2);
      debug(5, sbuf);
#endif
      /* Fill buffer with pattern */
      for (iii = 0; iii < 512; iii++) {
         if (iii & 0x0001) {
            /* Invert pattern for odd addresses */
            buffer[iii] = (uint8_t) ~pattern[i];
         }
         else buffer[iii] = pattern[i];
      }
      /* Write pattern to block */
      for (ii = 0; ii < blocks; ii++) {
         rv = dram_write((uint32_t) ii * 512, buffer, 512);
         if (rv) {
            /* Write error */
            STRCPY_P(sbuf, string2);
            DEBUG(1, sbuf);
            *address = (unsigned long) ii * 512;
            return(1);
         }
      }
      /* Read and compare pattern */
      for (ii = 0; ii < blocks; ii++) {
         /* Clear buffer */
         for (iii = 0; iii < 512; iii++) buffer[iii] = 0;
         /* Read pattern from block */
         rv = dram_read((uint32_t) ii * 512, buffer, 512);
         if (rv) {
            /* Read error */
            STRCPY_P(sbuf, string3);
            DEBUG(1, sbuf);
            *address = (unsigned long) ii * 512;
            return(1);
         }
         /* Compare pattern in block with expected value */
         for (iii = 0; iii < 512; iii++) {
            if ( (!(iii & 0x0001) && (buffer[iii] != pattern[i]))
            || ((iii & 0x0001) && (buffer[iii] != (uint8_t) ~pattern[i])) ) {
               /* Compare error */
#ifdef DEBUGMASK
               strcpy_P(sbuf, string4);
               sprintf(sbuf2, "%02X", buffer[iii]);
               strcat(sbuf, sbuf2);
               strcat_P(sbuf, string5);
               if (iii & 0x0001) sprintf(sbuf2, "%02X", (uint8_t) ~pattern[i]);
               else sprintf(sbuf2, "%02X", pattern[i]);
               strcat(sbuf, sbuf2);
               strcat_P(sbuf, string6);
               debug(1, sbuf);
#endif
               *address = (unsigned long) ii * 512 + iii;
               return(1);
            }
         }
      }
   }
   /* Success */
   return(0);
}
#endif


/*
********************************************************************************
*
* Fast DRAM pattern test (for POST)
*
* Only the first 2KiBytes of every module are checked => This should at least
* detect modules with incompatible timings
*
* The pattern is inverted for odd adresses so the memory chips must drive the
* data bus lines to inverse levels after every access for read & compare
*
* Paramter:
* 'address': Contains the address on which the test failed (only valid on error)
*
* Return value:
* 0: Success
* 1: Error
*
********************************************************************************
*/

static int  fast_test_dram(unsigned long*  address) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "\n[DRAM] Test: ";
   static const char  string1[] PROGMEM = "[DRAM] Test: Pattern 0x";
   static const char  string2[] PROGMEM = "[DRAM] Test: Write error\n";
   static const char  string3[] PROGMEM = "[DRAM] Test: Read error\n";
   static const char  string4[] PROGMEM
    = "Compare error (value: 0x";
   static const char  string5[] PROGMEM = ", expected: 0x";
   static const char  string6[] PROGMEM = ")\n";
   static const char  string7[] PROGMEM
    = " blocks will be tested on each module\n";
   char  sbuf2[7];            /* Enough for %d, %02X + \n + \0 */
#endif
   uint8_t  rv;
   uint8_t  i;                     /* Pattern index */
   uint16_t  ii;                   /* Block index */
   uint16_t  iii;                  /* Buffer index */
   uint8_t  pattern[] = {0x55, 0xAA, 0x00, 0xFF};
   uint8_t  buffer[512];
   uint8_t  blocks = 4;            /* 2KiByte (512Byte blocks) */
   uint8_t  module;                /* Currently tested module */
   uint32_t  offset;               /* Address offset for that module */

   if (!memsize) return(0);
#ifdef DEBUGMASK
   strcpy_P(sbuf, string0);
   sprintf(sbuf2, "%d", blocks);
   strcat(sbuf, sbuf2);
   strcat_P(sbuf, string7);
   debug(5, sbuf);
#endif
   for (i = 0; i < 4; i++) {
#ifdef DEBUGMASK
      strcpy_P(sbuf, string1);
      sprintf(sbuf2, "%02X\n", pattern[i]);
      strcat(sbuf, sbuf2);
      debug(5, sbuf);
#endif
      for (module = 0; module < 4; module++) {
         offset = (uint32_t) module * (memsize / 4) * 1024 * 1024;
         /* Fill buffer with pattern */
         for (iii = 0; iii < 512; iii++) {
            if (iii & 0x0001) {
               /* Invert pattern for odd addresses */
               buffer[iii] = (uint8_t) ~pattern[i];
            }
            else buffer[iii] = pattern[i];
         }
         /* Write pattern to block */
         for (ii = 0; ii < blocks; ii++) {
            rv = dram_write((uint32_t) ii * 512 + offset, buffer, 512);
            if (rv) {
               /* Write error */
               STRCPY_P(sbuf, string2);
               DEBUG(1, sbuf);
               *address = (unsigned long) ii * 512;
               return(1);
            }
         }
         /* Read and compare pattern */
         for (ii = 0; ii < blocks; ii++) {
            /* Clear buffer */
            for (iii = 0; iii < 512; iii++) buffer[iii] = 0;
            /* Read pattern from block */
            rv = dram_read((uint32_t) ii * 512 + offset, buffer, 512);
            if (rv) {
               /* Read error */
               STRCPY_P(sbuf, string3);
               DEBUG(1, sbuf);
               *address = (unsigned long) ii * 512;
               return(1);
            }
            /* Compare pattern in block with expected value */
            for (iii = 0; iii < 512; iii++) {
               if ( (!(iii & 0x0001) && (buffer[iii] != pattern[i]))
               || ((iii & 0x0001) && (buffer[iii] != (uint8_t) ~pattern[i])) ) {
                  /* Compare error */
#ifdef DEBUGMASK
                  strcpy_P(sbuf, string4);
                  sprintf(sbuf2, "%02X", buffer[iii]);
                  strcat(sbuf, sbuf2);
                  strcat_P(sbuf, string5);
                  if (iii & 0x0001) sprintf(sbuf2, "%02X",
                   (uint8_t) ~pattern[i]);
                  else sprintf(sbuf2, "%02X", pattern[i]);
                  strcat(sbuf, sbuf2);
                  strcat_P(sbuf, string6);
                  debug(1, sbuf);
#endif
                  *address = (unsigned long) ii * 512 + offset + iii;
                  return(1);
               }
            }
         }
      }
   }
   /* Success */
   return(0);
}


/*
********************************************************************************
*
* Fatal error
*
* Error codes:
* 0 : Unexpected interrupt
* 1 : EEPROM invalid
* 2 : POST failed
* 3 : PIA communicaton error
* 3 : PIA failure
* 4 : DRAM address out of range
* 5 : Out of memory ('malloc()' failed)
* 6 : DRAM acess error
*
********************************************************************************
*/

void  fatal(int  error) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "Fatal error (E";
   static const char  string1[] PROGMEM = "): Unexpected interrupt\n";
   static const char  string2[] PROGMEM = "): EEPROM content invalid\n";
   static const char  string3[] PROGMEM = "): POST failed\n";
   static const char  string4[] PROGMEM = "): PIA failure\n";
   static const char  string5[] PROGMEM = "): Unknown\n";
   static const char  string6[] PROGMEM = "\nI will die now :-(\n";
   static const char  string7[] PROGMEM = "): DRAM address out of range\n";
   static const char  string8[] PROGMEM = "): Out of memory\n";
   static const char  string9[] PROGMEM = "): DRAM access error\n";
   char  sbuf2[6];            /* Enough for %d + \0 */
   clock_t  start;

   /* Print error to debug port */
   strcpy_P(sbuf, string0);
   switch (error) {
      case 0:
         sprintf(sbuf2, "%d", error);
         strcat(sbuf, sbuf2);
         strcat_P(sbuf, string1);
         break;
      case 1:
         sprintf(sbuf2, "%d", error);
         strcat(sbuf, sbuf2);
         strcat_P(sbuf, string2);
         break;
      case 2:
         sprintf(sbuf2, "%d", error);
         strcat(sbuf, sbuf2);
         strcat_P(sbuf, string3);
         break;
      case 3:
         sprintf(sbuf2, "%d", error);
         strcat(sbuf, sbuf2);
         strcat_P(sbuf, string4);
         break;
      case 4:
         sprintf(sbuf2, "%d", error);
         strcat(sbuf, sbuf2);
         strcat_P(sbuf, string7);
         break;
      case 5:
         sprintf(sbuf2, "%d", error);
         strcat(sbuf, sbuf2);
         strcat_P(sbuf, string8);
         break;
      case 6:
         sprintf(sbuf2, "%d", error);
         strcat(sbuf, sbuf2);
         strcat_P(sbuf, string9);
         break;
      default:
         sprintf(sbuf2, "%d", error);
         strcat(sbuf, sbuf2);
         strcat_P(sbuf, string5);
   }
   debug(0xFF, sbuf);
   strcpy_P(sbuf, string6);
   debug(0xFF, sbuf);

   /* Wait until debug message buffer has drained (Timeout: 5s) */
   start = clock();
   while (UCSR0B & (1 << UDRIE)) {
      if (timeout(start, 5000)) break;
   }
#endif

   /* Disable interrupts */
   cli();

   /* Freeze */
   while (1);
}


/*
********************************************************************************
*
* Main routine
*
********************************************************************************
*/

int  main(int  argc, char**  argv) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM = "\033[2J\033[H";
   static const char  string1[] PROGMEM = "\nSCSI RAM-disk debug system\n";
   static const char  string2[] PROGMEM = "==========================\n\n";
   static const char  string3[] PROGMEM = "EEPROM magic number: 0x";
   static const char  string4[] PROGMEM = " (expected: 0xAA)\n\n";
   static const char  string5[] PROGMEM = "Hardware: ";
   static const char  string6[] PROGMEM = ", Firmware: ";
   static const char  string7[] PROGMEM = " (Build: ";
   static const char  string8[] PROGMEM = ")\n";
   static const char  string9[] PROGMEM = "\nInit target:\n";
   static const char  string10[] PROGMEM = "Enable interrupts ... OK\n";
   static const char  string11[] PROGMEM = "Enable DRAM refresh ... ";
   static const char  string12[] PROGMEM = "\nTarget POST:\n";
   static const char  string13[] PROGMEM = "SRAM test ... ";
   static const char  string14[] PROGMEM = "Failed at address 0x";
   static const char  string15[] PROGMEM = "OK\n";
   static const char  string16[] PROGMEM = "DRAM size ... ";
   static const char  string17[] PROGMEM = "DRAM test ... ";
   static const char  string18[] PROGMEM = "POST complete\n";
   static const char  string19[] PROGMEM = "\nInit PIA:\n";
   static const char  string20[] PROGMEM
    = "Read our SCSI ID from jumper block ... ";
   static const char  string21[] PROGMEM
    = "Configure PIA for target mode ...\n";
   static const char  string22[] PROGMEM = "Cannot configure PIA\n";
   static const char  string23[] PROGMEM
    = "PIA has enabled the SCSI interface\n";
   static const char  string24[] PROGMEM = "\nBoot complete\n";
   static const char  string25[] PROGMEM = "\nStarting taskrouter\n";
   static const char  string26[] PROGMEM = "MiByte\n";
   /* static const char  string27[] PROGMEM = "Skipped\n"; */
   static const char  string28[] PROGMEM
    = "Activate UNIT ATTENTION condition\n";
   static const char  string29[] PROGMEM = "\nSoft reset\n";
   static const char  string30[] PROGMEM = "Skip POST for soft reset\n";
   static const char  string31[] PROGMEM = "Init DRAM ... ";
   static const char  string32[] PROGMEM = "Failed\n";
   char  sbuf2[8];            /* Enough for %d, %02X, %04X, %06lX + \n + \0 */
   int  i, j;
#endif
   unsigned long  address;
   uint8_t  buf;
   uint8_t*  memp;

   /* Check for soft reset */
   if ((argc > 1) && !strcmp(argv[1], "SoftReset")) {
      /* Soft reset */
      STRCPY_P(sbuf, string29);
      DEBUG(1, sbuf);
   }
   else {
      /* Hard reset */
      /* Clear screen and put home cursor of the terminal (VT100 compatible) */
      STRCPY_P(sbuf, string0);
      DEBUG(1, sbuf);

      /* Print banner */
      STRCPY_P(sbuf, string1);
      DEBUG(1, sbuf);
      STRCPY_P(sbuf, string2);
      DEBUG(1, sbuf);
   }

   /* Check for EEPROM content to be valid */
   buf = eeprom_rb((unsigned int) &MAGIC);
   if (buf != 0xAA) {
#ifdef DEBUGMASK
      strcpy_P(sbuf, string3);
      sprintf(sbuf2, "%02X", buf);
      strcat(sbuf, sbuf2);
      strcat_P(sbuf, string4);
      debug(1, sbuf);
#endif
      fatal(1);
   }

   /* Print hardware and firmware version */
#ifdef DEBUGMASK
   strcpy_P(sbuf, string5);
   i = strlen(sbuf);
   j = 0;
   do {
      sbuf[i++] = (uint8_t) eeprom_rb((unsigned int) &HW_VERSION + j++);
   } while (sbuf[i - 1] && (j <= 13));
   if (j > 13) fatal(1);
   strcat_P(sbuf, string6);
   strcat_P(sbuf, FW_VERSION);
   strcat_P(sbuf, string7);
   strcat_P(sbuf, CTIME);
   strcat_P(sbuf, string8);
   DEBUG(1, sbuf);
#endif

   /* Init target */
   STRCPY_P(sbuf, string9);
   DEBUG(1, sbuf);
   /* Set UNIT ATTENTION condition for all initiators */
   STRCPY_P(sbuf, string28);
   DEBUG(1, sbuf);
   unit_attention = 0xFF;
   /* Enable interrupts */
   STRCPY_P(sbuf, string10);
   DEBUG(1, sbuf);
   sei();
   /* Check for soft reset */
   if ((argc > 1) && !strcmp(argv[1], "SoftReset")) {
      /* Soft reset => Skip POST to preserve DRAM data */
      STRCPY_P(sbuf, string30);
      DEBUG(1, sbuf);
      goto soft_reset;
   }
   /* Enable DRAM refresh */
   STRCPY_P(sbuf, string11);
   DEBUG(1, sbuf);
   usleep(200);                    /* Wait 200us as postulated */
   TIMSK |= (1 << OCIE2);          /* Unmask refresh interrupt */
   STRCPY_P(sbuf, string15);
   DEBUG(1, sbuf);
   /* Init DRAM */
   STRCPY_P(sbuf, string31);
   DEBUG(1, sbuf);
#if DEBUGMASK & 0x10               /* LF if DRAM messages are enabled */
   debug(1, "\n");
#endif
   memp = malloc(256);
   if (memp == NULL) {
      /* Out of memory */
      STRCPY_P(sbuf, string32);
      DEBUG(1, sbuf);
      fatal(5);
   }
   memsize = 16;                   /* This will also work for 4MiByte */
                                   /* Write access to prevent parity error */
   buf = dram_write(0, memp, 256);  /* >10 memory cycles as postulated */
   free(memp);
   if (buf) {
      /* DRAM access error */
      STRCPY_P(sbuf, string32);
      DEBUG(1, sbuf);
      fatal(6);
   }
   STRCPY_P(sbuf, string15);
   DEBUG(1, sbuf);

   /* Target POST */
   STRCPY_P(sbuf, string12);
   DEBUG(1, sbuf);
   /* SRAM test */
   STRCPY_P(sbuf, string13);
   DEBUG(1, sbuf);
   cli();                          /* Allowed to timeout DRAM refresh here */
   if (test_sram(&address)) {
      /* Failed */
      sei();
#ifdef DEBUGMASK
      strcpy_P(sbuf, string14);
      sprintf(sbuf2, "%04lX\n", address);
      strcat(sbuf, sbuf2);
      debug(1, sbuf);
#endif
      fatal(2);   
   }
   sei();
   STRCPY_P(sbuf, string15);
   DEBUG(1, sbuf);
   /* Check DRAM size */
   STRCPY_P(sbuf, string16);
   DEBUG(1, sbuf);
#if DEBUGMASK & 0x10               /* LF if DRAM messages are enabled */
   debug(1, "\n");
#endif
   memsize = dram_get_size();
#ifdef DEBUGMASK
   sprintf(sbuf, "%d", memsize);
   strcat_P(sbuf, string26);
   debug(1, sbuf);
#endif
   /* DRAM test */
   STRCPY_P(sbuf, string17);
   DEBUG(1, sbuf);
   /* Use fast test, full test would take several minutes */
   if (fast_test_dram(&address)) {
      /* Failed */
#ifdef DEBUGMASK
      strcpy_P(sbuf, string14);
      sprintf(sbuf2, "%06lX\n", address);
      strcat(sbuf, sbuf2);
      debug(1, sbuf);
#endif
      /* Set memsize to 0 => "Medium not present" */
      memsize = 0;
   }
   else {
      STRCPY_P(sbuf, string15);
      DEBUG(1, sbuf);
   }
   /* POST complete */
   STRCPY_P(sbuf, string18);
   DEBUG(1, sbuf);

soft_reset:

   /* Configure PIA */
   STRCPY_P(sbuf, string19);
   DEBUG(1, sbuf);
   STRCPY_P(sbuf, string20);
   DEBUG(1, sbuf);
   buf = ID & 0x0D;
   if (buf & 0x01)  buf |= 0x02;
   my_id = ~(buf >> 1) & 0x07;
#ifdef DEBUGMASK
   sprintf(sbuf, "%d\n", my_id);
   debug(1, sbuf);
#endif
   STRCPY_P(sbuf, string21);
   DEBUG(1, sbuf);
   if (pia_init(my_id, (1 << PIA_TARGET))) {
      STRCPY_P(sbuf, string22);
      DEBUG(1, sbuf);
      fatal(3);
   }
   STRCPY_P(sbuf, string23);
   DEBUG(1, sbuf);

   /* Boot complete */
   STRCPY_P(sbuf, string24);
   DEBUG(1, sbuf);

   /* Start taskrouter */
   STRCPY_P(sbuf, string25);
   DEBUG(1, sbuf);
   sip_taskrouter();

   /* This should never happen (compiler should freeze the system) */
   /* Do not use 'return()' because there is no address on the stack! */
   exit(-1);
}


/*
********************************************************************************
*
* Soft reset
*
* Restart target but preserve DRAM data
*
* Attention: Heap can not be recovered if memory is still 'malloc'ed!
*
********************************************************************************
*/

void  soft_reset(void) {
   char*  argv[2] = {"", "SoftReset"};

   /* Init stack */
   SP = RAMEND;

   /* Re-init global variables here if necessary */

   /* Restart (but preserve DRAM data) */
   main(2, argv);
}


/* EOF */
