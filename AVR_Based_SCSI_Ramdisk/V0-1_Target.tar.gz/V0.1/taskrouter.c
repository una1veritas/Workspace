/*
********************************************************************************
*
* Header
*
* Project:      SCSI controller
*
* Module:       Target
* File:         taskrouter.c
*
* Language:     C
*
* Description:  Task router
*               This is the implementation of the SIP (SCSI Interlock Protocol).
*               It uses the PIA (Parallel Interface Agent) as SDS (Service
*               Delivery Subsystem)
*
*               The task router receives commands from initiators and create the
*               corresponding tasks in the tasksets of the local LUNs (logical
*               units)
*
*               This task router can handle tasks using 'I_T' and 'I_T_L' nexus.
*               If no 'I_T_L' nexus is established by the initiator (this means
*               the 'IDENTIFY' message is missing), the task is routed to LUN0
*               (this should tolerate old SCSI1 initiators without arbitration
*               and LUN support which are not compliant to the SCSI3 SIP)
*
* Copyright:    (C) 2005 by Michael Baeuerle <micha@hilfe-fuer-linux.de>
* License:      This program is free software; you can redistribute it and/or
*               modify it under the terms of the GNU General Public License
*               as published by the Free Software Foundation; either version 2
*               of the License, or (at your option) any later version.
* 
*               This program is distributed in the hope that it will be
*               useful, but WITHOUT ANY WARRANTY; without even the implied
*               warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
*               PURPOSE.
*               See the GNU General Public License for more details.
* 
*               You should have received a copy of the GNU General Public
*               License along with this program; if not, write to:
*               Free Software Foundation Inc.
*               59 Temple Place, Suite 330
*               Boston MA  02111-1307  USA
*
* Written for:  Compiler : gcc (Version 3.3)
*               Platform : AVR
*               OS       : none
* Tested:       Compiler : gcc (Version 3.3)
*               Platform : ATmega64
*               OS       : none
* Do not work:  -
*
*
* Changelog:    2005-05-27  Michael Baeuerle
*               Function 'sip_task_router()' added
*               Function 'sip_init()' added
*
*               2005-06-04  Michael Baeuerle
*               Function 'sip_handle_message()' added
*               Message codes added
*               Task flags 'task_flags' added
*
*               2005-06-05  Michael Baeuerle
*               Move all debug strings to program memory
*
*               2005-06-06  Michael Baeuerle
*               'sip_handle_message()': Use 'pia_recover()' after parity error
*
*               2005-06-11  Michael Baeuerle
*               Function 'sip_get_command()' added
*               Function 'sip_put_status()' added
*
*               2005-06-17  Michael Baeuerle
*               Reservation handling added
*
*               2005-06-21  Michael Baeuerle
*               'sip_taskrouter()': Check for pending selection before idle
*
*               2005-06-24  Michael Baeuerle
*               'sip_put_status()': Drain debug message buffer before releasing
*                the SCSI bus
*
*
* To do:        -
*
********************************************************************************
*/


/*
********************************************************************************
*
* Include files
*
********************************************************************************
*/

#include <avr/pgmspace.h>
#include <avr/io.h>
#include <stdio.h>
#include <string.h>
#include "global.h"
#include "debug.h"
#include "time.h"
#include "pia.h"
#include "lun0.h"
#include "taskrouter.h"


/*
********************************************************************************
*
* Global constants
*
********************************************************************************
*/

/* LLC message codes */
#define TASK_COMPLETE            0x00
#define RESTORE_POINTERS         0x03
#define INITATOR_DETECTED_ERROR  0x05
#define MESSAGE_REJECT           0x07
#define NO_OPERATION             0x08
#define MESSAGE_PARITY_ERROR     0x09
#define IDENTIFY                 0x80
/* Task management message codes */
#define ABORT_TASK_SET           0x06 
#define TARGET_RESET             0x0C

/* Status codes */
#define GOOD                     0x00
#define CHECK_CONDITION          0x02
#define BUSY                     0x08
#define RESERVATION_CONFLICT     0x18

/* Task flags */
#define TF_SEL      0         /* First message after selection */
#define TF_PR       1         /* Pointers restored */
#define TF_ABORT    7         /* Task aborted by initator */


/*
********************************************************************************
*
* Global variables
*
********************************************************************************
*/

static uint8_t  ini_id;            /* Initiators SCSI ID */
static uint8_t  lun;               /* Logical unit number */


/*
********************************************************************************
*
* Init routine
*
* Ensure that PIA is in sane state
*
********************************************************************************
*/

static uint8_t  sip_init(void) {
   uint8_t  rv;
   uint8_t  pia_status;

   /* Ensure that PIA is ready */
   rv = pia_get_status(&pia_status);
   if (rv) fatal(3);
   if (!(pia_status & (1 << PIA_ENABLE))) {
      /* Soft reset if PIA is not enabled */
      soft_reset();
   }
   if (!(pia_status & (1 << PIA_COMPLETE))) {
      /* Abort command if PIA is busy */
      rv = pia_abort();
      if (rv) fatal(3);
      rv = pia_recover();
      if (rv) fatal(3);
   }
   if (pia_status & (1 << PIA_ERROR)) {
      /* Abort if PIA error */
      rv = pia_recover();
      if (rv) fatal(3);
   }
   return(pia_status);
}


/*
********************************************************************************
*
* Get SIP command from initator
*
* The CDB buffer must be able to store at least 16 bytes!
*
* Return value:
* 0: Success
* 1: Protocol error, bus release requested
*
********************************************************************************
*/

static uint8_t  sip_get_command(uint8_t*  cdb) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[Task router] Receive command from initiator\n";
   static const char  string1[] PROGMEM
    = "[Task router] Parity error detected\n";
   static const char  string2[] PROGMEM
    = "[Task router] Send RESTORE POINTERS message\n";
   static const char  string3[] PROGMEM
    = "[Task router] Command transmission error\n";
#endif
   uint8_t  rv;
   uint8_t  rv2 = 0;
   uint8_t  buf;

   /* Receive command from initator */
   STRCPY_P(sbuf, string0);
   DEBUG(3, sbuf);
   do {
      rv = rv2 = pia_get_command(cdb, 16);   /* Get 16 Bytes maximum */
      if (rv) {
         /* Handle command transfer errors */
         switch (rv) {
            case PIA_ERR_PARITY:
               STRCPY_P(sbuf, string1);
               DEBUG(3, sbuf);
               STRCPY_P(sbuf, string2);
               DEBUG(3, sbuf);
               rv = pia_recover();
               if (rv) return(1);
               buf = RESTORE_POINTERS;
               rv = pia_put_message(&buf, 1);
               if (rv) return(1);
               break;
            default:
               STRCPY_P(sbuf, string3);
               DEBUG(3, sbuf);
               return(1);
         }
      }
   } while (rv2);
   return(0);
}


/*
********************************************************************************
*
* Send SIP status to initator
*
* After the status a TASK COMPLETE message is send and the SCSI bus is released
*
* Return value:
* 0: Success
* 1: Protocol error, bus release requested
*
********************************************************************************
*/

static uint8_t  sip_put_status(uint8_t*  task_flags, uint8_t  status) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[Task router] Status transmission error\n";
   static const char  string1[] PROGMEM
    = "[Task router] Send TASK COMPLETE message\n";
   static const char  string2[] PROGMEM = "[Task router] Release SCSI bus\n";
   clock_t  start;
#endif
   uint8_t  rv;
   uint8_t  buf;
   uint8_t  pia_status;

   /* Clear 'Pointers restored' flag */
   *task_flags &= (uint8_t) ~(1 << TF_PR);
   do {
      /* Send status */
      rv = pia_put_status(status);
      if (rv) {
         /* Status transmission error */
         STRCPY_P(sbuf, string0);
         DEBUG(3, sbuf);
         return(1);
      }
      /* Check for ATTENTION condition */
      rv = pia_get_status(&pia_status);
      if (rv) return(1);
      if (pia_status & (1 << PIA_ATTENTION)) {
         /* ATTENTION condition detected */
         rv = sip_handle_message(task_flags);
         if (rv) return(1);
      }
      if (*task_flags & TF_ABORT) return(1);
   } while (*task_flags & TF_PR);       /* Try again if necessary */

   /* Send TASK_COMPLETE message */
   STRCPY_P(sbuf, string1);
   DEBUG(3, sbuf);
   buf = TASK_COMPLETE;
   rv = pia_put_message(&buf, 1);
   if (rv) return(1);

#ifdef DEBUGMASK
   /* Wait until debug message buffer has drained (Timeout: 5s) */
   /* Otherwise the next selection may time out because we are too slow */
   start = clock();
   while (UCSR0B & (1 << UDRIE)) {
      if (timeout(start, 5000)) break;
   }
#endif

   /* Release SCSI bus (regular) */
   STRCPY_P(sbuf, string2);
   DEBUG(3, sbuf);
   rv = pia_busfree();
   if (rv) return(1);
   return(0);
}


/*
********************************************************************************
*
* Handle SIP messages from initator
*
* Return value:
* 0: Success
* 1: Protocol error, bus release requested
*
********************************************************************************
*/

uint8_t  sip_handle_message(uint8_t*  task_flags) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[Task router] Receive message from initiator\n";
   static const char  string1[] PROGMEM
    = "[Task router] Parity error detected\n";
   static const char  string2[] PROGMEM
    = "[Task router] Send RESTORE POINTERS message\n";
   static const char  string3[] PROGMEM
    = "[Task router] Message transmission error\n";
   static const char  string4[] PROGMEM
    = "[Task router] IDENTIFY message received\n";
   static const char  string5[] PROGMEM = "[Task router] LUN ";
   static const char  string6[] PROGMEM = " selected\n";
   static const char  string7[] PROGMEM
    = "[Task router] I_T_L nexus established\n";
   static const char  string8[] PROGMEM
    = "[Task router] INITIATOR DETECTED ERROR message received\n";
   static const char  string9[] PROGMEM = "[Task router] SIP protocol error\n";
   static const char  string10[] PROGMEM
    = "[Task router] Send RESTORE POINTERS message\n";
   static const char  string11[] PROGMEM
    = "[Task router] ABORT TASK message received\n";
   static const char  string12[] PROGMEM
    = "[Task router] MESSAGE_REJECT message received\n";
   static const char  string13[] PROGMEM = "[Task router] SIP protocol error\n";
   static const char  string14[] PROGMEM
    = "[Task router] NO OPERATION message received\n";
   static const char  string15[] PROGMEM = "[Task router] SIP protocol error\n";
   static const char  string16[] PROGMEM
    = "[Task router] MESSAGE PARITY ERROR message received\n";
   static const char  string17[] PROGMEM = "[Task router] SIP protocol error\n";
   static const char  string18[] PROGMEM
    = "[Task router] TARGET RESET message received\n";
   static const char  string19[] PROGMEM = "[Task router] Message: ";
   static const char  string20[] PROGMEM
    = "[Task router] Unknown message received\n";
   static const char  string21[] PROGMEM
    = "[Task router] Send MESSAGE REJECT message\n";
   static const char  string22[] PROGMEM
    = "[Task router] Message transmission error\n";
   char  sbuf2[7];            /* Enough for %d, %02X + \n + \0 */
   uint16_t  i;
#endif
#define MAX_MESSAGE  3             /* Maximum message size */
   uint8_t  rv;
   uint8_t  buf[MAX_MESSAGE];      /* Message buffer */

   /* Receive message from initator */
   STRCPY_P(sbuf, string0);
   DEBUG(3, sbuf);
   rv = pia_get_message(buf, MAX_MESSAGE);
   if (rv) {
      /* Handle message transfer errors */
      switch (rv) {
         case PIA_ERR_PARITY:
            STRCPY_P(sbuf, string1);
            DEBUG(3, sbuf);
            STRCPY_P(sbuf, string2);
            DEBUG(3, sbuf);
            rv = pia_recover();
            if (rv) return(1);
            buf[0] = RESTORE_POINTERS;
            rv = pia_put_message(buf, 1);
            if (rv) return(1);
            /* Pointers restored */
            *task_flags |= (1 << TF_PR);
            return(0);
         default:
            STRCPY_P(sbuf, string3);
            DEBUG(3, sbuf);
            return(1);
      }
   }

#ifdef DEBUGMASK
   /* Print message */
   strcpy_P(sbuf, string19);
   if (buf[0] == 0x01) {
      rv = buf[1] + 2;
      if (rv > MAX_MESSAGE) rv = MAX_MESSAGE;
   }
   else if ((buf[0] < 0x20) || (buf[0] >= 0x80)) rv = 1;
   else if (buf[0] < 0x30) rv = 2;
   for (i = 0; i < rv; i++) {
      sprintf(sbuf2, "%02X ", buf[i]);
      strcat(sbuf, sbuf2);
   }
   strcat(sbuf, "\n");
   debug(3, sbuf);
#endif

   /* Analyze message */
   if (buf[0] >= IDENTIFY) {
      STRCPY_P(sbuf, string4);
      DEBUG(3, sbuf);
      /* Establish I_T_L nexus */
      lun = buf[0] & 0x1F;
#ifdef DEBUGMASK
      strcpy_P(sbuf, string5);
      sprintf(sbuf2, "%d", lun);
      strcat(sbuf, sbuf2);
      strcat_P(sbuf, string6);
      debug(3, sbuf);
#endif
      STRCPY_P(sbuf, string7);
      DEBUG(3, sbuf);
   }
   else {
      switch (buf[0]) {
         case INITATOR_DETECTED_ERROR:
            STRCPY_P(sbuf, string8);
            DEBUG(3, sbuf);
            if (*task_flags & (1 << TF_SEL)) {
               STRCPY_P(sbuf, string9);
               DEBUG(3, sbuf);
               return(1);
            }
            /* Send RESTORE POINTERS message */
            STRCPY_P(sbuf, string10);
            DEBUG(3, sbuf);
            buf[0] = RESTORE_POINTERS;
            rv = pia_put_message(buf, 1);
            if (rv) return(1);
            /* Pointers restored */
            *task_flags |= (1 << TF_PR);
            break;
         case ABORT_TASK_SET:
            STRCPY_P(sbuf, string11);
            DEBUG(3, sbuf);
            /* Set 'Abort' flag */
            *task_flags |= (1 << TF_ABORT);
            break;
         case MESSAGE_REJECT:
            STRCPY_P(sbuf, string12);
            DEBUG(3, sbuf);
            if (*task_flags & (1 << TF_SEL)) {
               STRCPY_P(sbuf, string13);
               DEBUG(3, sbuf);
               return(1);
            }
            /* Do nothing */
            break;
         case NO_OPERATION:
            STRCPY_P(sbuf, string14);
            DEBUG(3, sbuf);
            if (*task_flags & (1 << TF_SEL)) {
               STRCPY_P(sbuf, string15);
               DEBUG(3, sbuf);
              return(1);
            }
            /* Do nothing */
            break;
         case MESSAGE_PARITY_ERROR:
            STRCPY_P(sbuf, string16);
            DEBUG(3, sbuf);
            if (*task_flags & (1 << TF_SEL)) {
               STRCPY_P(sbuf, string17);
               DEBUG(3, sbuf);
               return(1);
            }
            /* Send last message again */
            rv = pia_put_message_again();
            if (rv) return(1);
            break;
         case TARGET_RESET:
            STRCPY_P(sbuf, string18);
            DEBUG(3, sbuf);
            /* Execute soft reset */
            soft_reset();
         default:
            STRCPY_P(sbuf, string20);
            DEBUG(3, sbuf);
            /* Reject message */
            STRCPY_P(sbuf, string21);
            DEBUG(3, sbuf);
            buf[0] = MESSAGE_REJECT;
            rv = pia_put_message(buf, 1);
            if (rv) {
               STRCPY_P(sbuf, string22);
               DEBUG(3, sbuf);
               return(1);
            }
      }
   }
   return(0);
}


/*
********************************************************************************
*
* Task router
*
* It handles the SIP protcol (the communication with initiators)
* It creates the tasks into the logical units tasksets
*
********************************************************************************
*/

void  sip_taskrouter(void) {
#ifdef DEBUGMASK
   static const char  string0[] PROGMEM
    = "[Task router] Prepare for next task\n";
   static const char  string1[] PROGMEM = "[Task router] Idle\n";
   static const char  string2[] PROGMEM
    = "[Task router] Selection Abort Timeout!\n";
   static const char  string3[] PROGMEM
    = "[Task router] Selection error, release SCSI bus\n";
   static const char  string4[] PROGMEM
    = "[Task router] Connected to initiator with SCSI ID ";
   static const char  string5[] PROGMEM
    = "[Task router] I_T nexus established\n";
   static const char  string6[] PROGMEM
    = "[Task router] ATTENTION condition detected\n";
   static const char  string7[] PROGMEM = "[Task router] Release SCSI bus\n";
   static const char  string8[] PROGMEM
    = "[Task router] Create task for LUN ";
   static const char  string9[] PROGMEM
    = "[Task router] Cannot create task, report status BUSY\n";
   static const char  string10[] PROGMEM
    = "[Task router] Error, report status CHECK CONDITION\n";
   static const char  string11[] PROGMEM
    = "[Task router] Success, report status GOOD\n";
   static const char  string12[] PROGMEM
    = "[Task router] Error, report status RESERVATION CONFLICT\n";
   static const char  string13[] PROGMEM
    = "[Task router] Check for reservation conflict\n";
   char  sbuf2[7];            /* Enough for %d + \n + \0 */
#endif
   uint8_t  rv;
   uint8_t  idle_flag = 0;
   uint8_t  pia_status;
   uint8_t  task_flags;
   uint8_t  sip_error;
   uint8_t  cdb[16];          /* CDB (Command descriptor block) */

   while (1) {
      /* Check for PIA is ready - recover from error if necessary */
      STRCPY_P(sbuf, string0);
      DEBUG(3, sbuf);
      task_flags = 0x00;
      pia_status = sip_init();

      /* Wait for next task */
      if (!(pia_status & (1 << PIA_SELECT))) {
         /* No selection pending, wait for IRQ */
         while (R_PCB & (1 << PIA_IRQ)) {
            if (!idle_flag) {
               STRCPY_P(sbuf, string1);
               DEBUG(3, sbuf);
            }
            idle_flag = 1;
         }
         idle_flag = 0;            /* Got IRQ from PIA */
      }

      /* Accept selection and take over SCSI bus control */
      /* Copy debug message from RAM to save time */
      DEBUG(3, "[Task router] An initiator selects us\n");
      rv = pia_get_status(&pia_status);
      if (rv) {
         /* Error, release SCSI bus */
         STRCPY_P(sbuf, string3);
         DEBUG(3, sbuf);
         rv = pia_busfree();
         if (rv) fatal(3);
      }
      if (!(pia_status & (1 << PIA_SELECT))) {
         /* Selection Abort Timeout */
         STRCPY_P(sbuf, string2);
         DEBUG(3, sbuf);
         continue;
      }
      else {
         /* Accept selection */
         rv = pia_accept_selection(&ini_id);
         if (rv) {
            /* Selection error, release SCSI bus */
            STRCPY_P(sbuf, string3);
            DEBUG(3, sbuf);
            rv = pia_busfree();    /* This is important to reset the PIA! */
            if (rv) fatal(3);
            continue;
         }
      }
      /* I_T nexus established */
#ifdef DEBUGMASK
      strcpy_P(sbuf, string4);
      sprintf(sbuf2, "%d\n", ini_id);
      strcat(sbuf, sbuf2);
      debug(3, sbuf);
#endif
      STRCPY_P(sbuf, string5);
      DEBUG(3, sbuf);
      /* Prepare pseudo I_T_L nexus for LUN0 if there is no IDENTIFY message */
      lun = 0;

      /* Set 'Selection' flag */
      task_flags |= (1 << TF_SEL);

      /* Receive messages if ATTENTION condition is detected */
      rv = pia_get_status(&pia_status);
      if (rv) {
         /* Error, release SCSI bus */
         STRCPY_P(sbuf, string3);
         DEBUG(3, sbuf);
         rv = pia_busfree();
         if (rv) fatal(3);
      }
      sip_error = 0;
      while (pia_status & (1 << PIA_ATTENTION)) {
         /* ATTENTION condition detected */
         STRCPY_P(sbuf, string6);
         DEBUG(3, sbuf);
         rv = sip_handle_message(&task_flags);
         if (rv) {
            /* Message handling error, release SCSI bus */
            STRCPY_P(sbuf, string7);
            DEBUG(3, sbuf);
            rv = pia_busfree();
            if (rv) fatal(3);
            sip_error = 1;
            break;
         }
         else {
            /* Clear 'Selection' flag */
            task_flags &= (uint8_t) ~(1 << TF_SEL);
         }
         rv = pia_get_status(&pia_status);
         if (rv) {
            /* Error, release SCSI bus */
            STRCPY_P(sbuf, string3);
            DEBUG(3, sbuf);
            rv = pia_busfree();
            if (rv) fatal(3);
         }
      }
      if (sip_error) continue;

      /* Check for ABORT TASK SET message was received */
      if (task_flags & TF_ABORT) {
         /* Abort all tasks */
         /* Note:
          * Currently we do not support disconnection so there cannot be an
          * active task at this point!
          */
         /* Release SCSI bus */
         STRCPY_P(sbuf, string7);
         DEBUG(3, sbuf);
         rv = pia_busfree();
         if (rv) fatal(3);
         continue;
      }

      /* Receive CDB (Command Descriptor Block) */
      rv = sip_get_command(cdb);
      if (rv) {
         /* CDB transmission error, release SCSI bus */
         STRCPY_P(sbuf, string7);
         DEBUG(3, sbuf);
         rv = pia_busfree();
         if (rv) fatal(3);
         continue;
      }

      /* Check for reservation conflict on LUN0 */
      if (lun == 0) {
         STRCPY_P(sbuf, string13);
         DEBUG(3, sbuf);
         rv = lun0_tm_check_reservation(ini_id, cdb);
         if (rv) {
            /* Reservation conflict */
            STRCPY_P(sbuf, string12);
            DEBUG(3, sbuf);
            rv = sip_put_status(&task_flags, RESERVATION_CONFLICT);
            if (rv) {
               /* Cannot send status, release SCSI bus */
               STRCPY_P(sbuf, string7);
               DEBUG(3, sbuf);
               rv = pia_busfree();
               if (rv) fatal(3);
            }
            /* Bus already released */
            continue;
         }
      }

      /* Create task in logical units taskset */
#ifdef DEBUGMASK
      strcpy_P(sbuf, string8);
      sprintf(sbuf2, "%d\n", lun);
      strcat(sbuf, sbuf2);
      debug(3, sbuf);
#endif
      switch (lun) {
         case 0:                   /* LUN 0 */
            rv = lun0_tm_create(ini_id, cdb);
            break;
         default:                  /* All other LUNs */
            rv = lunx_tm_create(ini_id, cdb);
      }
      if (rv) {
         /* Cannot create task, LUN busy */
         STRCPY_P(sbuf, string9);
         DEBUG(3, sbuf);
         rv = sip_put_status(&task_flags, BUSY);
         if (rv) {
            /* Cannot send status, release SCSI bus */
            STRCPY_P(sbuf, string7);
            DEBUG(3, sbuf);
            rv = pia_busfree();
            if (rv) fatal(3);
         }
         /* Bus already released */
         continue;
      }

      /* Execute the task */
      switch (lun) {
         case 0:                   /* LUN 0 */
            rv = lun0_ds_execute();
            break;
         default:                  /* All other LUNs */
            rv = lunx_ds_execute();
      }
      if (rv) {
         /* Error, report status CHECK CONDITION */
         STRCPY_P(sbuf, string10);
         DEBUG(3, sbuf);
         rv = sip_put_status(&task_flags, CHECK_CONDITION);
         if (rv) {
            /* Cannot send status, release SCSI bus */
            STRCPY_P(sbuf, string7);
            DEBUG(3, sbuf);
            rv = pia_busfree();
            if (rv) fatal(3);
         }
      }
      else {
         /* Success, report status GOOD */
         STRCPY_P(sbuf, string11);
         DEBUG(3, sbuf);
         rv = sip_put_status(&task_flags, GOOD);
         if (rv) {
            /* Cannot send status, release SCSI bus */
            STRCPY_P(sbuf, string7);
            DEBUG(3, sbuf);
            rv = pia_busfree();
            if (rv) fatal(3);
         }
      }
      /* Bus already released */
   }
}


/* EOF */
